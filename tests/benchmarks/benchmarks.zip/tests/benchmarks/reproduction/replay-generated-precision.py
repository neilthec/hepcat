#!/usr/bin/env python3
"""Replay frozen generated graphs at the same binary64 points in 53/64-bit arithmetic.

This is a conditional numerical-precision diagnostic, not a new 100000-point
MadGraph validation. Saved independent rates and the original FAIL are retained.
"""

# HEPCAT - High Energy Physics Constructive Amplitude Tool
#
# Copyright (C) 2026 Neil Christensen
#
# This file is part of HEPCAT.
#
# HEPCAT is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# HEPCAT is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with HEPCAT.  If not, see <https://www.gnu.org/licenses/>.

import argparse
import csv
import gzip
from decimal import Decimal, localcontext
import hashlib
import importlib.util
import io
import json
import math
import os
import platform
from pathlib import Path, PurePosixPath
import stat
import struct
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
REPOSITORY = HERE.parents[2]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load_fixture(path):
    """Verify every archive member before using or extracting any source."""
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), 'Duplicate evidence archive member')
        manifest = json.loads(archive.read('MANIFEST.json'))
        require(manifest['Format'] == 'HEPCATGeneratedGraphPrecisionFixture-1',
                'Unsupported evidence format')
        declared = {row['Path'] for row in manifest['Files']}
        require(len(declared) == len(manifest['Files']) and
                set(names) == declared | {'MANIFEST.json'}, 'Evidence inventory mismatch')
        files = {}
        for row in manifest['Files']:
            name = row['Path']
            require(not PurePosixPath(name).is_absolute() and
                    not any(x in ('', '.', '..') for x in name.split('/')) and
                    '\\' not in name and ':' not in name, 'Unsafe evidence path')
            info = archive.getinfo(name)
            require(not info.is_dir() and
                    stat.S_IFMT(info.external_attr >>16) in (0, stat.S_IFREG),
                    'Unsupported evidence member type')
            data = archive.read(name)
            require(len(data) == row['Bytes'] and digest(data) == row['SHA256'],
                    'Evidence size/hash mismatch: ' + name)
            files[name] = data
    points = csv_rows(files['inputs/points.csv'])
    legs = manifest['LegCount']
    by_point = {}
    for row in points:
        point, leg = int(row['point']), int(row['leg'])
        require(1 <= leg <= legs and leg not in by_point.setdefault(point, {}),
                'Duplicate/invalid momentum leg')
        values = [float.fromhex(row[k]) if '0x' in row[k].lower() else float(row[k])
                  for k in ('E', 'px', 'py', 'pz')]
        require(all(math.isfinite(x) for x in values), 'Nonfinite momentum')
        by_point[point][leg] = [struct.pack('>d', x).hex() for x in values]
    require(len(by_point) == manifest['SelectedPoints'] and
            all(set(v) == set(range(1, legs+1)) for v in by_point.values()),
            'Incomplete selected momentum inventory')
    rates = {int(row['point']): Decimal(row['madgraph_squared'])
             for row in csv_rows(files['inputs/madgraph-rates.csv'])}
    require(set(rates) == set(by_point) and all(x.is_finite() and x>=0 for x in rates.values()),
            'Incomplete or invalid saved reference rates')
    failed = manifest['FailedPointIndices']
    require(len(failed) == 16 and len(set(failed)) == 16 and set(failed) <= set(by_point),
            'Original failure inventory mismatch')
    original = json.loads(files['original-100k.json'])
    require(len(original['Calls']) == 4, 'Original call inventory mismatch')
    for call, mismatches in zip(original['Calls'], (0, 0, 0, 16)):
        require(len(call['Rows']) == 1, 'Unexpected original helicity inventory')
        row = call['Rows'][0]
        require(row['RequestedPoints'] == row['GeneratedPoints'] ==
                row['ComparedPoints'] == 100000 and row['EvaluationErrors'] == 0 and
                row['Mismatches'] == mismatches, 'Original validation scope changed')
    require(original['Calls'][-1]['Rows'][0]['Status'] == 'FAIL',
            'The original failure must be preserved')
    provenance = json.loads(files['report-provenance.json'])
    require(len(provenance['Reports']) == manifest['CompleteOriginalReports'] == 4,
            'Complete original report inventory mismatch')
    for row in provenance['Reports']:
        compressed = files[row['Path']]
        raw = gzip.decompress(compressed)
        require(digest(compressed) == row['CompressedSHA256'] and
                digest(raw) == row['UncompressedSHA256'] and
                len(raw) == row['UncompressedBytes'] and
                len(compressed) == row['CompressedBytes'],
                'Complete report decompression/hash mismatch')
    control = json.loads(files['x86-double53-control.json'])
    control_rows = csv_rows(files['x86-double53-control.csv'])
    require(len(control_rows) == len(by_point) and
            {int(row['point']) for row in control_rows} == set(by_point),
            'Same-target control inventory mismatch')
    require(digest(files['x86-double53-control.csv']) == control['RatesSHA256'],
            'Same-target rate hash mismatch')
    expected_bits = {i: [bit for leg in sorted(v) for bit in v[leg]]
                     for i, v in by_point.items()}
    for kind in ('physical', 'spurious'):
        replay = {'ParameterBits': manifest['ExpectedParameterBits'],
                  'NormalizationBits': '3fd0000000000000', 'MantissaBits': 53,
                  'Rates': [{'Point': int(row['point']),
                             'Squared': row[kind+'_squared'],
                             'MomentBits': expected_bits[int(row['point'])]}
                            for row in control_rows]}
        require(all(Decimal(row['madgraph_squared']) == rates[int(row['point'])]
                    for row in control_rows), 'Same-target reference rates changed')
        summary = summarize(replay, rates, expected_bits, manifest['ExpectedParameterBits'],
                            Decimal(manifest['RelativeTolerance']),
                            Decimal(manifest['AbsoluteTolerance']))
        saved = control['Runs'][kind+'-double']
        require(all(summary[key] == saved[key] for key in summary),
                'Same-target control statistics differ from saved rates')
    checks = json.loads(files[manifest['PortableCommandChecks']])['Commands']
    require(len(checks) == 3 and all(row['Status'] == 'COMPLETE' for row in checks) and
            [row['Points'] for row in checks] == [1600, 16, 16],
            'Portable command completion/subset scopes changed')
    return manifest, files, by_point, rates


def csv_rows(data):
    return list(csv.DictReader(io.StringIO(data.decode('utf-8'))))


def stage(files, output):
    inputs = output/'fixture'
    for name, data in files.items():
        target=inputs/name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        if name.startswith('reports/') and name.endswith('.wxf.gz'):
            target.with_suffix('').write_bytes(gzip.decompress(data))
    return inputs


def run(command, log):
    with log.open('a') as stream:
        stream.write(json.dumps([str(x) for x in command])+'\n')
        stream.flush()
        subprocess.run([str(x) for x in command], stdout=stream,
                       stderr=subprocess.STDOUT, check=True)


def verify_replay_inputs(data, moment_bits, parameter_bits):
    require(data['ParameterBits'] == parameter_bits, 'Parameter bits changed')
    require(data['NormalizationBits'] == '3fd0000000000000', 'Normalization changed')
    rows = data['Rates']
    require(len(rows) == len(moment_bits) and
            {row['Point'] for row in rows} == set(moment_bits),
            'Incomplete/duplicate replay rows')
    for row in rows:
        require(row['MomentBits'] == moment_bits[row['Point']], 'Momentum bits changed')
    return rows


def summarize(data, expected, moment_bits, parameter_bits, relative, absolute):
    rows = verify_replay_inputs(data, moment_bits, parameter_bits)
    failures=[]; maximum=Decimal(0); worst=None
    with localcontext() as context:
        context.prec=70
        for row in rows:
            point=row['Point']
            require(row['MomentBits']==moment_bits[point], 'Momentum bits changed')
            value=Decimal(row['Squared']); reference=expected[point]
            require(value.is_finite() and value>=0, 'Nonfinite/negative squared amplitude')
            difference=abs(value-reference); scale=max(abs(value),abs(reference))
            error=difference/scale if scale else Decimal(0)
            if error>maximum:maximum,worst=error,point
            if difference>absolute+relative*scale:failures.append(point)
    return {'Points':len(rows),'MantissaBits':data['MantissaBits'],
            'MismatchesAtOriginalTolerance':len(failures),'FailingIndices':failures,
            'MaximumRelativeDifference':str(maximum),'WorstPoint':worst}


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive',type=Path,default=HERE/'generated-precision-evidence.zip')
    inspection = parser.add_mutually_exclusive_group()
    inspection.add_argument('--verify-only',action='store_true',help='Verify frozen sources/data without compiling or writing output')
    inspection.add_argument('--extract-only',action='store_true',help='Verify/unpack frozen sources and reports; decompress WXF for ordinary Mathematica Import, without compiling')
    parser.add_argument('--spinas',type=Path,help='Compatible SPINAS source checkout; never edited')
    parser.add_argument('--modes',nargs='+',choices=('double','extended'),default=['double','extended'])
    parser.add_argument('--target',choices=('native','x86_64'),default='native')
    parser.add_argument('--selection',choices=('all','failures','first'),default='all')
    parser.add_argument('--project-shells',action='store_true',help='Separate changed-input 16-point form-to-form control; never compare projected points to old MG rates')
    parser.add_argument('--cxx',default=os.environ.get('CXX','c++'))
    parser.add_argument('--output-directory',type=Path,default=REPOSITORY/'tests/results/reproduction/generated-precision')
    args=parser.parse_args(argv)
    manifest,files,points,rates=load_fixture(args.archive)
    if args.verify_only:
        print(json.dumps({'Status':'VERIFIED','Members':len(files),'SelectedPoints':len(points),
                          'Original100kStatus':manifest['Original100kStatus'],
                          'CompleteOriginalReports':manifest['CompleteOriginalReports'],
                          'SameTarget53BitControlPoints':1600,
                          'CompletedPortableCommands':3,
                          'ArchiveSHA256':digest(args.archive.read_bytes())},indent=2))
        return 0
    if args.extract_only:
        require(not args.output_directory.exists() or not any(args.output_directory.iterdir()),
                'Output is not empty; choose a new directory to preserve earlier evidence')
        args.output_directory.mkdir(parents=True, exist_ok=True)
        inputs = stage(files, args.output_directory)
        print(inputs/'reports')
        return 0
    require(args.spinas is not None and (args.spinas/'include').is_dir() and
            (args.spinas/'source').is_dir(), 'Supply --spinas /path/to/compatible/source')
    require(args.target=='native' or sys.platform=='darwin', '--target x86_64 requires Apple compiler/Rosetta; use native on x86 Linux')
    require(not args.project_shells or (args.modes==['extended'] and args.selection=='failures'),
            'Projection control requires --modes extended --selection failures')
    require(not args.output_directory.exists() or not any(args.output_directory.iterdir()),
            'Output is not empty; choose a new directory to preserve earlier evidence')
    selected=set(points) if args.selection=='all' else set(manifest['FailedPointIndices'][:1] if args.selection=='first' else manifest['FailedPointIndices'])
    args.output_directory.mkdir(parents=True,exist_ok=True)
    inputs=stage(files,args.output_directory)
    selected_file=args.output_directory/'selected-points.csv'
    with selected_file.open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=('point','leg','E','px','py','pz'))
        writer.writeheader()
        writer.writerows(r for r in csv_rows(files['inputs/points.csv']) if int(r['point']) in selected)
    bits={i:[v for leg in sorted(points[i]) for v in points[i][leg]] for i in selected}
    expected={i:rates[i] for i in selected}
    specification=importlib.util.spec_from_file_location('hepcat_frozen_precision',HERE/'replay-precision.py')
    builder=importlib.util.module_from_spec(specification);specification.loader.exec_module(builder)
    flags=['-std=c++11','-O3','-DNDEBUG']
    if args.target=='x86_64':flags=['-arch','x86_64',*flags]
    report={'Status':'RUNNING','Scope':manifest['SelectionScope'],
            'Original100kStatus':'FAIL16/100000','NewMadGraphCalculation':False,
            'InputPolicy':'Binary64 first, then promote. No projection unless explicitly requested.',
            'ChangedInputProjection':args.project_shells,'Selection':args.selection,
            'OriginalSeed':manifest['OriginalSeed'],'RelativeTolerance':manifest['RelativeTolerance'],
            'AbsoluteTolerance':manifest['AbsoluteTolerance'],'ArchiveSHA256':digest(args.archive.read_bytes()),
            'DriverSHA256':digest((HERE/'replay-generated-precision.cpp').read_bytes()),
            'Compiler':args.cxx,'Target':args.target,
            'CompilerVersion':subprocess.check_output([args.cxx, '--version'], text=True),
            'HostMachine':platform.machine(),'LibraryFlags':flags,
            'GraphFlags':['-O0','-DWITH_LONG_DOUBLE'],
            'Libraries':{},'Runs':{}}
    destination=args.output_directory/'generated-precision-replay.json'
    def save():destination.write_text(json.dumps(report,indent=2)+'\n')
    save()
    for mode in args.modes:
        print('Building private SPINAS:', mode, args.target, flush=True)
        library=builder.build_library(args.spinas,args.output_directory/'spinas'/mode,mode,args.cxx,flags)
        report['Libraries'][mode]=library;save()
        for kind in manifest['Graphs']:
            print('Compiling and replaying frozen graph:', kind, mode, len(selected), 'points', flush=True)
            graph=inputs/'graphs'/kind
            executable=args.output_directory/(kind+'-'+mode)
            graph_flags=[x for x in flags if x not in ('-O3','-DNDEBUG')]+['-O0','-DWITH_LONG_DOUBLE',
                '-I',graph,'-I',inputs/'support','-I',inputs,
                '-I',args.output_directory/'spinas'/mode/'include']
            if args.project_shells:graph_flags+=['-DHEPCAT_REPLAY_PROJECT']
            log=args.output_directory/(kind+'-'+mode+'.log')
            run([args.cxx,*graph_flags,HERE/'replay-generated-precision.cpp',graph/'process.cpp',
                 library['library'],'-o',executable],log)
            result=args.output_directory/(kind+'-'+mode+'.json')
            run([executable,selected_file,inputs/'inputs/parameters.csv',result],log)
            data=json.loads(result.read_text())
            require(data['MantissaBits']==(53 if mode=='double' else 64),'Wrong replay precision')
            if args.project_shells:
                verify_replay_inputs(data, bits, manifest['ExpectedParameterBits'])
                report['Runs'][kind+'-'+mode]={'Points':len(selected),'MantissaBits':64,
                    'Scope':'Changed momenta; compare the two forms only, no MG result'}
            else:
                report['Runs'][kind+'-'+mode]=summarize(data,expected,bits,manifest['ExpectedParameterBits'],
                    Decimal(manifest['RelativeTolerance']),Decimal(manifest['AbsoluteTolerance']))
            report['Runs'][kind+'-'+mode]['ExecutableSHA256']=digest(executable.read_bytes())
            save()
    if args.project_shells:
        physical=json.loads((args.output_directory/'physical-extended.json').read_text())['Rates']
        spurious=json.loads((args.output_directory/'spurious-extended.json').read_text())['Rates']
        require([r['Point'] for r in physical]==[r['Point'] for r in spurious], 'Projected point sets differ')
        maximum=Decimal(0);worst=None
        with localcontext() as context:
            context.prec=70
            for a,b in zip(physical,spurious):
                require(a['MomentBits']==b['MomentBits'] and a['ProjectedMomenta']==b['ProjectedMomenta'],
                        'The two projected evaluations used different momenta')
                av,bv=Decimal(a['Squared']),Decimal(b['Squared'])
                error=abs(av-bv)/max(abs(av),abs(bv)) if av or bv else Decimal(0)
                if error>maximum:maximum,worst=error,a['Point']
        report['FormToFormControl']={'Points':len(selected),'MaximumRelativeDifference':str(maximum),
                                    'WorstPoint':worst,'ComparedWithMadGraph':False,'InputsChanged':True}
    report['Status']='COMPLETE'
    report['CompletionMeaning']='All selected arithmetic evaluations completed. This is not a replacement PASS for the original100000-point validation.'
    save();print(destination)
    return 0


if __name__=='__main__':
    try:
        sys.exit(main())
    except (OSError,ValueError,KeyError,zipfile.BadZipFile,subprocess.CalledProcessError) as error:
        print('Generated-precision replay: '+str(error),file=sys.stderr)
        sys.exit(1)
