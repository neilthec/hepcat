#include <sstream>
// Direct numerical tests of the two proposed all-N formulas. No constructive
// diagrams, preparation, factorization completion or symbolic expansion runs.
/*
HEPCAT - High Energy Physics Constructive Amplitude Tool

Copyright (C) 2026 Neil Christensen

This file is part of HEPCAT.

HEPCAT is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HEPCAT is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HEPCAT.  If not, see <https://www.gnu.org/licenses/>.
*/

#include "all-positive-formulas.hpp"
#include "madgraph-runtime.hpp"
#include "../checks/spinas-export-reference.hpp"
#include <iomanip>
#include <iostream>

namespace {
struct Options {
  unsigned photons = 7;
  std::size_t points = 100000;
  std::uint64_t seed = hepcat_spinas::detail::validation_seed_from_time();
  ldouble mass = 1, charge = ldouble(1) / 3;
  ldouble minimum_energy = 10, maximum_energy = 100, tolerance = 1e-7L;
  std::string reference, output = "all-positive";
  bool self_test_only = false;
};

std::uint64_t unsigned_value(const std::string& value) {
  if (value.empty() || value.find_first_not_of("0123456789") != std::string::npos)
    throw std::invalid_argument("Expected an unsigned integer: " + value);
  return std::stoull(value);
}

ldouble real_value(const std::string& value) {
  std::size_t used = 0;
  const ldouble result = std::stold(value, &used);
  if (used != value.size() || !std::isfinite(result))
    throw std::invalid_argument("Expected a finite real number: " + value);
  return result;
}

ldouble relative(const cdouble& a, const cdouble& b) {
  if (!hepcat_spinas::finite_complex(a) || !hepcat_spinas::finite_complex(b))
    throw std::runtime_error("A formula returned a nonfinite complex amplitude.");
  const ldouble scale = std::max(std::abs(a), std::abs(b));
  return scale ? std::abs(a - b) / scale : 0;
}

ldouble relative(ldouble a, ldouble b) {
  if (!std::isfinite(a) || !std::isfinite(b))
    throw std::runtime_error("A comparison contains a nonfinite squared amplitude.");
  const ldouble scale = std::max(std::abs(a), std::abs(b));
  return scale ? std::abs(a - b) / scale : 0;
}

template<std::size_t N>
hepcat_spinas::Momenta<N + 2> point(ldouble mass, std::mt19937_64& random,
                                   ldouble minimum, ldouble maximum) {
  std::array<ldouble, N + 2> masses = {};
  masses[0] = masses[1] = mass;
  hepcat_spinas::ValidationOptions options;
  options.minimum_center_of_mass_energy = minimum;
  options.maximum_center_of_mass_energy = maximum;
  return hepcat_spinas::make_random_validation_momenta(
      masses, {{0, 1}}, random, options);
}

// Established small-N formulas are controls for this numerical transcription,
// not answers supplied at either new multiplicity.
template<std::size_t N> cdouble small_oracle(
    const hepcat_spinas::Momenta<N + 2>& p, ldouble m, ldouble e, int s1, int s2);

template<> cdouble small_oracle<2>(const hepcat_spinas::Momenta<4>& p,
    ldouble m, ldouble e, int s1, int s2) {
  std::array<ldouble, 4> masses = {{m, m, 0, 0}};
  auto particles = hepcat_export_reference::particles(p, masses);
  spinas::sproduct a12(ANGLE, &particles[0], &particles[1]);
  spinas::sproduct s34(SQUARE, &particles[2], &particles[3]);
  return 2 * e * e * m * a12.v(s1, s2) * s34.v() * s34.v() /
    hepcat_export_reference::electron_denominator(p, 0, 2, m) /
    hepcat_export_reference::electron_denominator(p, 0, 3, m);
}

template<> cdouble small_oracle<3>(const hepcat_spinas::Momenta<5>& p,
    ldouble m, ldouble e, int s1, int s2) {
  return hepcat_export_reference::five_all_plus(p, {{m, m, 0, 0, 0}}, e, s1, s2);
}

template<> cdouble small_oracle<4>(const hepcat_spinas::Momenta<6>& p,
    ldouble m, ldouble e, int s1, int s2) {
  return hepcat_export_reference::six_all_plus(p, {{m, m, 0, 0, 0, 0}}, e, s1, s2);
}

template<std::size_t N> void small_check(std::mt19937_64& random) {
  ldouble worst = 0;
  for (unsigned sample = 0; sample < 20; ++sample) {
    const ldouble mass = sample % 2 ? ldouble(1.5L) : ldouble(1);
    const ldouble charge = sample % 2 ? ldouble(2) / 7 : ldouble(1) / 3;
    const auto p = point<N>(mass, random, 10, 100);
    hepcat_all_positive::Formulas<N> formulas(p, mass, charge);
    worst = std::max(worst, relative(formulas.spurious_coefficient(),
                                     formulas.spurious_ordered_coefficient()));
    for (int a : {-1, 1}) for (int b : {-1, 1}) {
      const auto result = formulas.amplitudes(a, b);
      const auto expected = small_oracle<N>(p, mass, charge, a, b);
      worst = std::max(worst, relative(result.physical, expected));
      worst = std::max(worst, relative(formulas.collected_physical_amplitude(a, b), expected));
      worst = std::max(worst, relative(result.spurious, expected));
    }
  }
  if (!std::isfinite(worst) || worst > 1e-8L)
    throw std::runtime_error("Small-N formula control failed at N=" + std::to_string(N) +
                             ", relative error=" + std::to_string(worst));
  std::cout << "N=" << N << " small-formula controls PASS; maximum relative error "
            << worst << '\n';
}

int test(const std::string& input_path, const std::string& output_path) {
  constexpr std::size_t N = 8;
  std::ifstream in(input_path);
  std::ofstream values(output_path);
  values << std::setprecision(std::numeric_limits<ldouble>::max_digits10);
  std::string row; std::getline(in,row);
  int count=0;
  while(std::getline(in,row)) {
    std::replace(row.begin(),row.end(),',',' ');
    std::istringstream fields(row); int index; double mg;
    fields>>index>>mg;
    hepcat_spinas::Momenta<N+2> p;
    for(auto& mom:p)for(auto& component:mom){double x;fields>>x;component=x;}
    if(!fields)throw std::runtime_error("incomplete row");
    ++count;
    const ldouble expected=mg;
    hepcat_all_positive::Formulas<N> formulas(p,1.5L,static_cast<ldouble>(double(1)/3));
    ldouble physical = 0, spurious = 0, complex_error = 0;
    ldouble collected = 0, collected_signed = 0;
    // Raw spin sums on both sides, with all outgoing photons fixed at +.
    // No initial averaging or identical-particle phase-space factor is applied.
    for (int a : {-1, 1}) for (int b : {-1, 1}) {
      const auto amplitudes = formulas.amplitudes(a, b);
      const cdouble reduced = formulas.collected_physical_amplitude(a, b);
      collected += std::norm(reduced);
      collected_signed = std::max(collected_signed, relative(amplitudes.physical, reduced));
      physical += std::norm(amplitudes.physical);
      spurious += std::norm(amplitudes.spurious);
      complex_error = std::max(complex_error,
                               relative(amplitudes.physical, amplitudes.spurious));
    }
    const ldouble ordered_error = relative(formulas.spurious_coefficient(),
                                            formulas.spurious_ordered_coefficient());
    const ldouble collected_mg = relative(collected, expected);
    const ldouble errors[] = {relative(physical,expected),relative(spurious,expected),complex_error,ordered_error,collected_mg,collected_signed};
    values << index;
    for (const auto error:errors) values << ',' << error;
    values << '\n';
  }
  std::cout << "count=" << count << " significand=" << std::numeric_limits<ldouble>::digits << '\n';
  return 0;
}
}
int main(int argc,char**argv) { return test(argv[1],argv[2]); }
