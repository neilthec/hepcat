(* Evaluate the six QED notebook cells that invoke scalar collection. *)
qfolder=DirectoryName[ExpandFileName[$InputFileName]];
qroot=Environment["HEPCAT_ROOT"];If[!StringQ[qroot]||qroot==="",qroot=Nest[DirectoryName,qfolder,6]];
Get[FileNameJoin[{qroot,"source","HEPCAT.wl"}]];$HistoryLength=0;
qnb=Get[FileNameJoin[{qroot,"tests","QED-6-point-construction.nb"}]];
qcells=Association[Cases[qnb,Cell[code_String,"Input",CellTags->tag_String,___]:>(tag->code),Infinity]];
factorizationModel=ReadModel[FileNameJoin[{qroot,"models"}],3];
factorizationModelSpurious=ReadModel[FileNameJoin[{qroot,"models"}],4];
ToExpression[qcells["QEDFiniteMixedDefinition"]];ToExpression[qcells["QEDBalancedGaugeDefinition"]];
qspec={
  {"QEDFiniteMixed5AllPhysical", {"qed5PPM","qed5PMM"}},
  {"QEDBalancedPhysicalGauge", {"qed6PPMM"}},
  {"QEDFiniteMixed6AllPhysical", {"qed6PPPM","qed6PMMM"}},
  {"QEDFiniteMixed5AllSpurious", {"qed5PPM","qed5PMM"}},
  {"QEDBalancedSingleBracket", {"qed6PPMM"}},
  {"QEDFiniteMixed6AllSpurious", {"qed6PPPM","qed6PMMM"}}};
qordinary[body_,seconds_:2]:=Block[{ConstructiveDiagrams`Private`preparationSpinSectorCollection},
 ConstructiveDiagrams`Private`preparationSpinSectorCollection[b_,___]:=b;
 CollectAmplitudeFactors[body,Infinity]];
qunbounded[body_,seconds_:2]:=CollectAmplitudeFactors[body,Infinity];
qrun[tag_,collector_,names_]:=(ToExpression[StringReplace[qcells[tag],"CollectAmplitudeFactors["->collector<>"["]];
 ToExpression/@names);
qrows=Flatten[Table[qtag=First[spec]; qnames=Last[spec];
 qold=qrun[qtag,"qordinary",qnames];qnew=qrun[qtag,"qunbounded",qnames];
 qnormal=qrun[qtag,"CollectAmplitudeFactors",qnames];
 Table[<|"cell"->qtag,"amplitude"->qnames[[i]],"ordinary_leaves"->LeafCount[qold[[i]]],
   "new_leaves"->LeafCount[qnew[[i]]],"same_ordinary_and_new"->(qold[[i]]===qnew[[i]]),
   "default_matches_unbounded"->(qnormal[[i]]===qnew[[i]]),
   "exact_ordinary_and_new"->(qold[[i]]===qnew[[i]]||Together[qold[[i]]-qnew[[i]]]===0),
   "default_exact"->(qnormal[[i]]===qnew[[i]]||Together[qnormal[[i]]-qnew[[i]]]===0)|>,
   {i,Length[qnames]}],{spec,qspec}],1];
qout=Environment["HEPCAT_VALIDATION_OUTPUT"];If[StringQ[qout]&&qout=!="",Export[qout,qrows,"RawJSON"]];
Print[qrows];Quit[If[Length[qrows]==10 && AllTrue[qrows,#["same_ordinary_and_new"] && #["default_exact"] &],0,1]];
