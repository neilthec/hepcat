qbase=DirectoryName[ExpandFileName[$InputFileName]];
qroot=Environment["HEPCAT_ROOT"];
If[!StringQ[qroot] || qroot === "", qroot=Nest[DirectoryName,qbase,6]];
Get[FileNameJoin[{qroot,"source","HEPCAT.wl"}]];$HistoryLength=0;
qdata=Import[FileNameJoin[{qroot,"tests","benchmarks","reproduction","100k","catalog","input-expressions.wxf"}],"WXF"];
qden[x_]:=Union[Cases[{x},Power[b_,p_?Negative]/;!NumberQ[b]:>b,Infinity]];
qrows=Table[qinitial=entry["expression"];
 qold=Block[{ConstructiveDiagrams`Private`preparationSpinSectorCollection},
       ConstructiveDiagrams`Private`preparationSpinSectorCollection[body_,___]:=body;
       CollectAmplitudeFactors[qinitial,Infinity]];
 {qsec,qnew}=AbsoluteTiming[CollectAmplitudeFactors[qinitial,Infinity]];
 qchanged=qold=!=qnew; qeq=If[!qchanged,True,
   qatoms=DeleteDuplicates[Cases[{qold,qnew},_SpinorChain|_PropDen|_ModelParameter,Infinity]];
   qtokens=Thread[qatoms->Table[Unique["z"],{Length[qatoms]}]];
   TimeConstrained[Together[(qold-qnew)/.Dispatch[qtokens]]===0,5,False]];
 <|"particles"->entry["particles"],"form"->entry["form"],"original_leaves"->LeafCount[qinitial],
   "existing_collector_leaves"->LeafCount[qold],"new_collector_leaves"->LeafCount[qnew],
   "seconds"->qsec,"changed_from_existing"->qchanged,"exact"->qeq,
   "identical_denominator_bases"->(qden[qinitial]===qden[qnew]),
   "nonincreasing_score"->TrueQ[SpinorExpressionComplexity[qnew]<=SpinorExpressionComplexity[qinitial]]|>,
 {entry,qdata}];
qout=Environment["HEPCAT_VALIDATION_OUTPUT"];
If[StringQ[qout] && qout =!= "",Export[qout,qrows,"RawJSON"]];
Print[{Length[qrows],Count[Lookup[qrows,"changed_from_existing"],True],And@@Lookup[qrows,"exact"],And@@Lookup[qrows,"identical_denominator_bases"],And@@Lookup[qrows,"nonincreasing_score"]}];

Quit[If[Length[qrows]==38 && NoneTrue[qrows,#["changed_from_existing"] &] && AllTrue[qrows,#["exact"] && #["identical_denominator_bases"] && #["nonincreasing_score"] &],0,1]];
