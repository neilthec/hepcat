#include "process.hpp"
#include "one-minus-formulas.hpp"
#include "four-fermion-all-plus-formulas.hpp"
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>

int main() {
    using Process = hepcat_generated::PROCESS;
    const unsigned n = PHOTONS;
    const unsigned fermions = FERMIONS;
    const unsigned settings = fermions == 4 ? 2 : 1;
    const unsigned pointsPerSetting = 100000;
    const double tolerance = fermions == 4 ? 1e-7 : 1e-8;
    unsigned failures = 0;
    hepcat_spinas::ValidationOptions options;
    options.minimum_center_of_mass_energy = 10;
    options.maximum_center_of_mass_energy = 100;
    for (unsigned setting = 0; setting < settings; ++setting) {
        const unsigned seed = (fermions == 4 ? 934871 : 27641) + n + 100 * setting;
        std::mt19937_64 random(seed);
        const ldouble mass = setting ? 1.5L : 1;
        const ldouble charge = setting ? ldouble(2)/7 : ldouble(1)/3;
        Process process(charge, mass);
        std::array<ldouble, n+fermions> masses{};
        std::fill_n(masses.begin(), fermions, mass);
        const unsigned components = 1u << fermions;
        unsigned failed = 0;
        ldouble maximum = 0;
        for (unsigned point = 0; point < pointsPerSetting; ++point) {
            const auto p = hepcat_spinas::make_random_validation_momenta(masses, {{0,1}}, random, options);
            process.set_momenta(p);
#if FERMIONS == 2
            hepcat_one_minus::Formula<n> formula(p, mass, charge);
#else
            hepcat_four_fermion_all_plus::Formula<n> formula(p, mass, charge);
#endif
            typename Process::Spins spins;
            spins.fill(2);
#if FERMIONS == 2
            spins.back() = -2;
#endif
            ldouble scale = 0, difference = 0;
            for (unsigned state = 0; state < components; ++state) {
                for (unsigned leg = 0; leg < fermions; ++leg)
                    spins[leg] = (state & (1u<<leg)) ? +1 : -1;
                const auto expected = process.amp(spins);
#if FERMIONS == 2
                const auto actual = formula.amplitude(spins[0], spins[1]);
#else
                const auto actual = formula.amplitude({{spins[0], spins[1], spins[2], spins[3]}});
#endif
                if (!std::isfinite(std::abs(expected)) || !std::isfinite(std::abs(actual))) {
                    difference = std::numeric_limits<ldouble>::infinity();
                    break;
                }
                scale = std::max({scale, std::abs(expected), std::abs(actual)});
                difference = std::max(difference, std::abs(expected-actual));
            }
            const ldouble error = scale == 0 ? difference : difference / scale;
            maximum = std::max(maximum, error);
            if (!(error <= tolerance)) ++failed;
        }
        std::cout << std::setprecision(17) << "{\"fermions\":" << fermions << ",\"photons\":" << n
                  << ",\"mass\":" << mass << ",\"charge\":" << charge << ",\"seed\":" << seed
                  << ",\"points\":" << pointsPerSetting << ",\"components_per_point\":" << components
                  << ",\"relative_tolerance\":" << tolerance << ",\"failed\":" << failed
                  << ",\"max_scaled_complex_error\":" << maximum << "}\n";
        failures += failed;
    }
    return failures != 0;
}
