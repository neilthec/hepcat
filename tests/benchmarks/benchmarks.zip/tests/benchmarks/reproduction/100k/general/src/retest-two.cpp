// Fixed-photon-helicity tests of the general four-fermion QED currents.
// This driver never calls constructive generation or factorization completion.
/*
HEPCAT - High Energy Physics Constructive Amplitude Tool

Copyright (C) 2026 Neil Christensen

This file is part of HEPCAT.

HEPCAT is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HEPCAT is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HEPCAT.  If not, see <https://www.gnu.org/licenses/>.
*/

#include "four-fermion-all-plus-formulas.hpp"
#include "madgraph-runtime.hpp"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <string>
#include <vector>

namespace {
struct Options {
  unsigned photons = 3;
  std::size_t points = 100000;
  std::uint64_t seed = hepcat_spinas::detail::validation_seed_from_time();
  ldouble mass = 1, charge = ldouble(1)/3, tolerance = 1.e-7L;
  std::string reference, output = "four-fermion-all-plus";
};

Options arguments(int argc, char** argv) {
  Options result;
  for (int i = 1; i < argc; ++i) {
    const std::string flag = argv[i];
    if (flag == "--help") {
      std::cout << "four-fermion-all-plus-validation --photons 0..5 --points 100000 "
                   "--reference /path/to/libhepcat_madgraph.dylib --output prefix "
                   "[--seed INTEGER] [--mass VALUE] [--charge VALUE] "
                   "[--relative-tolerance VALUE]\n"
                   "Physical process: e- e+ -> e- e+ + N positive-helicity photons. "
                   "Match mass, charge and zero widths to the independent reference card.\n";
      std::exit(0);
    }
    if (++i == argc) throw std::invalid_argument("Missing value after " + flag);
    const std::string value = argv[i];
    if (flag == "--photons") result.photons = unsigned(std::stoul(value));
    else if (flag == "--points") result.points = std::stoull(value);
    else if (flag == "--seed") result.seed = std::stoull(value);
    else if (flag == "--mass") result.mass = std::stold(value);
    else if (flag == "--charge") result.charge = std::stold(value);
    else if (flag == "--relative-tolerance") result.tolerance = std::stold(value);
    else if (flag == "--reference") result.reference = value;
    else if (flag == "--output") result.output = value;
    else throw std::invalid_argument("Unknown option: " + flag);
  }
  if (result.photons > 5 || !result.points || result.reference.empty() ||
      !(result.mass > 0) || !(result.charge > 0) || !(result.tolerance > 0) ||
      !std::isfinite(result.mass) || !std::isfinite(result.charge) ||
      !std::isfinite(result.tolerance))
    throw std::invalid_argument("Select 0 through 5 photons, positive points/mass/charge/tolerance, and a reference library.");
  return result;
}

std::string quoted(const std::string& value) {
  std::string result = "\"";
  for (char c : value) {
    if (c == '\\' || c == '"') result += '\\';
    if (c == '\n') result += "\\n";
    else if (c == '\r') result += "\\r";
    else if (c == '\t') result += "\\t";
    else result += c;
  }
  return result + "\"";
}

ldouble relative(ldouble first, ldouble second) {
  if (!std::isfinite(first) || !std::isfinite(second))
    return std::numeric_limits<ldouble>::infinity();
  const ldouble scale = std::max(std::abs(first),std::abs(second));
  return scale ? std::abs(first-second)/scale : 0;
}

template<std::size_t N>
ldouble component_error(hepcat_four_fermion_all_plus::Formula<N>& first,
                        hepcat_four_fermion_all_plus::Formula<N>& second) {
  ldouble scale = 0, difference = 0;
  for (int a : {-1,1}) for (int b : {-1,1})
    for (int c : {-1,1}) for (int d : {-1,1}) {
      const std::array<int,4> spins = {{a,b,c,d}};
      const cdouble x = first.amplitude(spins), y = second.amplitude(spins);
      if (!std::isfinite(std::abs(x)) || !std::isfinite(std::abs(y)))
        return std::numeric_limits<ldouble>::infinity();
      scale = std::max(scale,std::max(std::abs(x),std::abs(y)));
      difference = std::max(difference,std::abs(x-y));
    }
  return scale ? difference/scale : 0;
}

struct Maximum {
  ldouble value = 0;
  std::size_t failures = 0;
  void add(ldouble error, ldouble tolerance) {
    value = std::isfinite(error) ? std::max(value,error)
                                : std::numeric_limits<ldouble>::infinity();
    if (!(error <= tolerance)) ++failures;
  }
};

void number(std::ostream& stream, ldouble value) {
  if (std::isfinite(value)) stream << value;
  else stream << "null";
}

template<std::size_t N>
int validate(const Options& options) {
  using Formula = hepcat_four_fermion_all_plus::Formula<N>;
  using Momenta = typename Formula::Momenta;
  const ldouble mass = options.mass, charge = options.charge;
  std::ifstream input(options.reference);
  if (!input) throw std::runtime_error("cannot read selected momenta");
  std::string header; std::getline(input, header);
  std::ofstream values(options.output+".csv");
  values << std::setprecision(std::numeric_limits<ldouble>::max_digits10);
  int counter = 0;
  const typename Formula::FourMomentum alternate = {{1,0,1,0}};
  Maximum mg, gauge, bose, ward;
  ldouble component_ward_maximum = 0;
  std::size_t failures = 0;
  const auto start = std::chrono::steady_clock::now();
  std::string row;
  while (std::getline(input,row)) {
    std::replace(row.begin(),row.end(),',',' ');
    std::istringstream fields(row);
    int sample; double reference;
    fields >> sample >> reference; Momenta p;
    for(auto& mom:p) for(auto& entry:mom) {double v; fields >> v; entry=v;}
    if(!fields) throw std::runtime_error("incomplete momentum row");
    ++counter;
    Formula formula(p,options.mass,options.charge),
      changed_reference(p,options.mass,options.charge,&alternate);
    Momenta permuted = p;
    std::reverse(permuted.begin()+4,permuted.end());
    Formula changed_permutation(permuted,options.mass,options.charge);
    const ldouble expected=reference;
    const ldouble actual = formula.spin_sum(), mg_error = relative(actual,expected),
      gauge_error = component_error(formula,changed_reference),
      bose_error = component_error(formula,changed_permutation),
      ward_error = formula.ward_relative_error(),
      component_ward_error = formula.component_ward_relative_error();
    component_ward_maximum = std::max(component_ward_maximum,component_ward_error);
    mg.add(mg_error,options.tolerance); gauge.add(gauge_error,options.tolerance);
    bose.add(bose_error,options.tolerance); ward.add(ward_error,options.tolerance);
    const bool passed = mg_error <= options.tolerance && gauge_error <= options.tolerance &&
      bose_error <= options.tolerance && ward_error <= options.tolerance;
    if (!passed) ++failures;
    values << sample << "," << mg_error << "," << gauge_error << "," << bose_error << "," << ward_error << "," << component_ward_error << "\n";
  }
  std::cout<<"count="<<counter<<" significand="<<std::numeric_limits<ldouble>::digits<<"\n";
  return 0;
}
}

int main(int argc,char** argv) {
  try {
    const Options options = arguments(argc,argv);
    switch(options.photons) {
      case 0:return validate<0>(options); case 1:return validate<1>(options);
      case 2:return validate<2>(options); case 3:return validate<3>(options);
      case 4:return validate<4>(options); case 5:return validate<5>(options);
    }
  } catch(const std::exception& error) { std::cerr << error.what() << '\n'; return 2; }
  return 2;
}
