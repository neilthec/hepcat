(* Run from the publication checkout or set HEPCAT_ROOT for another source checkout.
   The WXF contains the two original constructor outputs, before collection. *)
qtestFolder=DirectoryName[ExpandFileName[$InputFileName]];
qtestRoot=Environment["HEPCAT_ROOT"];
If[!StringQ[qtestRoot] || qtestRoot === "", qtestRoot=Nest[DirectoryName, qtestFolder, 6]];
If[!FileExistsQ[FileNameJoin[{qtestRoot,"source","HEPCAT.wl"}]],Quit[2]];
Get[FileNameJoin[{qtestRoot,"source","HEPCAT.wl"}]];$HistoryLength=0;
qtestInputs=Import[FileNameJoin[{qtestFolder,"original-mixed.wxf"}],"WXF"];
qtestInverses[x_]:=Union[Cases[{x},Power[b_,e_?Negative]/;!NumberQ[b]:>b,Infinity]];
qtestRows=Table[
  qtestBody=qtestInputs[[i]];
  {qtestSeconds,qtestOutput}=AbsoluteTiming[CollectAmplitudeFactors[qtestBody,2]];
  <|"Helicities"->{"++-","+--"}[[i]],"TimeSeconds"->qtestSeconds,
    "OriginalLeaves"->LeafCount[qtestBody],"Leaves"->LeafCount[qtestOutput],
    "SpinorComplexity"->SpinorExpressionComplexity[qtestOutput],
    "SameReciprocalBases"->(qtestInverses[qtestBody]===qtestInverses[qtestOutput]),
    "ExactRationalEquality"->(Together[qtestBody-qtestOutput]===0)|>,
 {i,Length[qtestInputs]}];
Print[qtestRows];
Quit[If[Length[qtestRows]==2 && AllTrue[qtestRows,#["Leaves"]<=330 &&
  #["SpinorComplexity"]<=62 && #["SameReciprocalBases"] && #["ExactRationalEquality"]&],0,1]];
