(* Run from the publication checkout or set HEPCAT_ROOT for another source checkout.
   The WXF contains the two original constructor outputs, before collection. *)
qtestFolder=DirectoryName[ExpandFileName[$InputFileName]];
qtestRoot=Environment["HEPCAT_ROOT"];
If[!StringQ[qtestRoot] || qtestRoot === "", qtestRoot=Nest[DirectoryName, qtestFolder, 6]];
If[!FileExistsQ[FileNameJoin[{qtestRoot,"source","HEPCAT.wl"}]],Quit[2]];
Get[FileNameJoin[{qtestRoot,"source","HEPCAT.wl"}]];$HistoryLength=0;
qoriginal=Import[FileNameJoin[{qtestFolder,"original-mixed.wxf"}],"WXF"];
Clear[ordinary];ordinary[q_, budget_]:=Block[{ConstructiveDiagrams`Private`preparationSpinSectorCollection},
 ConstructiveDiagrams`Private`preparationSpinSectorCollection[b_,___]:=b;CollectAmplitudeFactors[q,budget]];
qbody=First[qoriginal]; qbest=ordinary[qbody,2];
qseen=False;qlate=Block[{ConstructiveDiagrams`Private`preparationSpinSectorCollection},
 ConstructiveDiagrams`Private`preparationSpinSectorCollection[b_,___]:=(qseen=True;Pause[2];0);
 CollectAmplitudeFactors[qbody,0.2]];
qseen2=False;qmemory=Block[{ConstructiveDiagrams`Private`preparationSpinSectorCollection},
 ConstructiveDiagrams`Private`preparationSpinSectorCollection[b_,___]:=(qseen2=True;Range[24000000];0);
 CollectAmplitudeFactors[qbody,2]];
qbig=Total[Table[Unique["large"] qbody,{5}]];
qtouched=False;qlarge=Block[{ConstructiveDiagrams`Private`preparationSpinSectorCollection},
 ConstructiveDiagrams`Private`preparationSpinSectorCollection[b_,___]:=(qtouched=True;b);
 CollectAmplitudeFactors[qbig,Infinity]];
qans=<|"incumbent_leaves"->LeafCount[qbest],"time_fallback_exact"->(qseen && qlate===qbest),
 "memory_fallback_exact"->(qseen2 && qmemory===qbest),"big_input_leaves"->LeafCount[qbig],
 "large_input_skipped_optional"->!qtouched,"large_equals_ordinary"->(qlarge===ordinary[qbig,Infinity]),
 "zero_budget_unchanged"->(CollectAmplitudeFactors[qbody,0]===qbody)|>;
Print[qans];Quit[If[TrueQ[And@@(qans[#]&/@{"time_fallback_exact","memory_fallback_exact","large_input_skipped_optional","large_equals_ordinary","zero_budget_unchanged"})],0,1]];
