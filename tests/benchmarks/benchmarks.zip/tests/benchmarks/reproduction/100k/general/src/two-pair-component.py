#!/usr/bin/env python3
"""Trace the absolute and normalized Ward residual for two-pair event 8223."""
import argparse
import csv
import importlib.util
import json
from pathlib import Path

import mpmath as mp

sibling = Path(__file__).with_name('one-minus-multiprecision.py')
spec = importlib.util.spec_from_file_location('spinor_conventions', sibling)
spinor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(spinor)


def hexadecimal(text):
    """Promote a C++ hexadecimal floating-point token exactly at the working precision."""
    mantissa, power = text.lower().split('p')
    integer, separator, fraction = mantissa.partition('.')
    sign = -1 if integer.startswith('-') else 1
    digits = integer.lstrip('+-').removeprefix('0x') + fraction
    return mp.mpf(sign*int(digits,16))*mp.power(2,int(power)-4*len(fraction))


def add(*vectors):
    return [sum(entries) for entries in zip(*vectors)]


def metric(mu):
    return 1 if mu==0 else -1


def lower(p):
    e,x,y,z=p
    return ((e+z,x-mp.j*y),(x+mp.j*y,e-z))


def upper(p):
    return lower([p[0],-p[1],-p[2],-p[3]])


def apply(matrix, v):
    return [spinor.contract(row,v) for row in matrix]


def norm(v):
    return mp.sqrt(mp.fsum(abs(x)**2 for x in v))


def pstr(v):
    return mp.nstr(v,35)


def choose_reference(p):
    best=None
    for h in range(4,len(p)):
        coefficient=2*spinor.minkowski(p[0],p[h])
        spatial=[coefficient*p[0][mu]-p[h][mu] for mu in (1,2,3)]
        n=norm(spatial)
        q=[mp.mpf(1),*(x/n for x in spatial)]
        score=min(spinor.minkowski(q,r)/r[0] for r in p[4:])
        if best is None or score>best[0]:best=(score,h,q)
    return best[1],best[2]


def project(original):
    p=[r[:] for r in original]
    for mu in (1,2,3):
        p[-1][mu]=-mp.fsum(row[mu] for row in p[2:-1])
    for i in range(2,len(p)):
        p[i][0]=mp.sqrt((1 if i<4 else 0)+mp.fsum(x*x for x in p[i][1:]))
    energy=mp.fsum(row[0] for row in p[2:])/2
    z=mp.sqrt((energy-1)*(energy+1))
    p[0]=[energy,0,0,z]
    p[1]=[energy,0,0,-z]
    return p


def diagnostics(p,target):
    photons=len(p)-4
    masks=range(1<<photons)
    members=[[i for i in range(photons) if mask & (1<<i)] for mask in masks]
    incoming=[[x*(1 if i<2 else -1) for x in row] for i,row in enumerate(p)]
    subsetmom=[[mp.fsum(incoming[4+i][mu] for i in group) for mu in range(4)] for group in members]
    particles=[spinor.spinors(row,mp.mpf(1) if i<4 else 0) for i,row in enumerate(p)]
    reference_index,q=choose_reference(p)
    la=spinor.spinors(q,0)['la'][-1]
    sigma_lower=[]
    sigma_upper=[]
    for mu in range(4):
        unit=[int(k==mu) for k in range(4)]
        sigma_lower.append(lower(unit))
        sigma_upper.append(upper(unit))
    brackets=[]
    polarization=[]
    for i in range(photons):
        h=particles[4+i]
        b=-spinor.contract(la,h['ra'][-1])
        brackets.append(b)
        polarization.append([metric(mu)*spinor.contract(la,apply(sigma_lower[mu],h['rs']))/(mp.sqrt(2)*b)
                             for mu in range(4)])
    scalar=[]
    for a in range(4):
        j=[mp.mpc(0) for mask in masks]
        j[0]=1
        for mask in range(1,len(masks)):
            subset=members[mask]
            den=-2*(1 if a<2 else -1)*mp.fsum(spinor.minkowski(p[a],p[i+4]) for i in subset)
            den+=2*mp.fsum(spinor.minkowski(p[i+4],p[k+4]) for i in subset for k in subset if i<k)
            terms=[]
            for i in subset:
                pred=mask^(1<<i)
                vertex=spinor.contract(la,apply(lower(add(incoming[a],subsetmom[pred])),particles[i+4]['rs']))
                terms.append(j[pred]*vertex/brackets[i])
            j[mask]=mp.fsum(terms)/den
        scalar.append(j)
    max_component=mp.mpf(0)
    max_tensor=mp.mpf(0)
    target_detail=None
    worst=None
    for family,(a,b) in enumerate(((0,1),(3,2),(0,2),(3,1))):
        crossing=(1 if a<2 else -1)*(1 if b<2 else -1)
        density=[mp.mpc(0) for mask in masks]
        for mask in masks:
            left=mask
            weights=[]
            oterms=[[] for mu in range(4)]
            while True:
                right=mask^left
                w=(-1)**len(members[right])*scalar[a][left]*scalar[b][right]
                weights.append(w)
                q=add(incoming[a],subsetmom[left])
                for mu in range(4):oterms[mu].append(2*w*q[mu])
                if not left:break
                left=(left-1)&mask
            density[mask]=mp.fsum(weights)
            orbital=[mp.fsum(oterms[mu])-mp.sqrt(2)*mp.fsum(density[mask^(1<<i)]*polarization[i][mu] for i in members[mask]) for mu in range(4)]
            k=[-x for x in add(incoming[a],incoming[b],subsetmom[mask])]
            klen=norm(k)
            per_spin=[]
            for sa in (-1,1):
                ls=particles[a]['la'][sa]
                for sb in (-1,1):
                    rs=particles[b]['ra'][sb]
                    ab=crossing*spinor.contract(ls,rs)
                    kright=apply(upper(k),rs)
                    vector=[ab*orbital[mu]+crossing*density[mask]*spinor.contract(ls,apply(sigma_upper[mu],kright)) for mu in range(4)]
                    abs_divergence=abs(mp.fsum(metric(mu)*k[mu]*vector[mu] for mu in range(4)))
                    jlen=norm(vector)
                    ratio=abs_divergence/(klen*jlen) if klen*jlen else abs_divergence
                    per_spin.append(((family,mask,sa,sb),jlen,abs_divergence,ratio))
            tensor_current=norm([s[1] for s in per_spin])
            tensor_divergence=norm([s[2] for s in per_spin])
            tr=tensor_divergence/(klen*tensor_current) if klen*tensor_current else tensor_divergence
            max_tensor=max(max_tensor,tr)
            for key,jlen,residual,ratio in per_spin:
                if key==target or ratio>max_component:
                    details=dict(family=key[0],subset_mask=key[1],spins=list(key[2:]),
                                 absolute_divergence=pstr(residual),k_euclidean_norm=pstr(klen),
                                 component_current_norm=pstr(jlen),component_scale=pstr(klen*jlen),
                                 component_relative_error=pstr(ratio),tensor_current_norm=pstr(tensor_current),
                                 component_fraction_of_tensor=pstr(jlen/tensor_current) if tensor_current else None,
                                 tensor_scale=pstr(klen*tensor_current),tensor_divergence_norm=pstr(tensor_divergence),
                                 tensor_relative_error=pstr(tr))
                    if key==target:target_detail=details
                    if ratio>max_component:
                        max_component=ratio
                        worst=details
    assert target_detail is not None
    return dict(reference_seed_photon_leg=reference_index+1,
                max_mass_shell_residual=pstr(max(abs(spinor.minkowski(v,v)-(1 if j<4 else 0)) for j,v in enumerate(p))),
                max_momentum_residual=pstr(max(abs(x) for x in add(*incoming))),
                max_component_relative_error=pstr(max_component),max_tensor_relative_error=pstr(max_tensor),
                original_x87_worst_component=target_detail,worst_component_here=worst)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('hex_coordinates',type=Path)
    parser.add_argument('extended_detail',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    with args.extended_detail.open() as f:
        ext=list(csv.DictReader(f))
    targetrow=next(r for r in ext if r['kinematics']=='x87_projection')
    target=tuple(int(targetrow[key]) for key in ('family','mask','spin_a','spin_b'))
    with args.hex_coordinates.open() as f:
        hx={r[0]:r[1:] for r in csv.reader(f)}
    result={'point':8223,'photons':5,'mass':1,'reference':'same geometrically selected common angle reference as the archived two-pair code',
            'x87':ext,'digits':{}}
    for digits in (45,70):
        with mp.workdps(digits):
            points={key:[list(map(hexadecimal,val[i:i+4])) for i in range(0,len(val),4)] for key,val in hx.items()}
            points['high_precision_projection']=project(points['original'])
            result['digits'][str(digits)]={key:diagnostics(v,target) for key,v in points.items()}
    args.output.write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
