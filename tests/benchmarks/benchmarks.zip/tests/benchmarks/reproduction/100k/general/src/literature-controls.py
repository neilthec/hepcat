"""Combine contiguous parts of the identical seeded phase-space stream."""
import json
from pathlib import Path


def summarize(parts):
    families = []
    for n in range(2, 7):
        runs = sorted((part for part in parts if part["photons"] == n),
                      key=lambda part: part["begin"])
        if (not runs or runs[0]["begin"] != 0 or runs[-1]["end"] != 400000
                or any(left["end"] != right["begin"] for left, right in zip(runs, runs[1:]))):
            raise ValueError(f"Incomplete or overlapping sample for {n} photons")
        if any(run["seed"] != 180206730 + n or run["significand_bits"] != runs[0]["significand_bits"]
               or sum(setting["points"] for setting in run["settings"]) != run["end"] - run["begin"]
               for run in runs):
            raise ValueError(f"Inconsistent run metadata for {n} photons")
        settings = []
        for setting_number in range(4):
            rows = [run["settings"][setting_number] for run in runs]
            mass, charge = rows[0]["mass"], rows[0]["charge"]
            count = sum(row["points"] for row in rows)
            if count != 100000 or any((row["mass"], row["charge"]) != (mass, charge) for row in rows):
                raise ValueError(f"Inconsistent parameter sample for {n} photons")
            setting = {"mass": mass, "charge": charge, "points": count}
            for name in ("one_ordering", "omitted_coupling_factor"):
                values = [row[name] for row in rows]
                accepted = [p for value in values for p in value["within_1e-7_points"]]
                if any((p-1) % 4 != setting_number or not 1 <= p <= 400000 for p in accepted):
                    raise ValueError(f"Invalid event indices in {name}")
                setting[name] = {"minimum_relative_difference": min(value["min"] for value in values),
                                 "maximum_relative_difference": max(value["max"] for value in values),
                                 "rejected_at_1e-7": count - len(accepted),
                                 "above_1e-4": count - sum(value["within_1e-4"] for value in values),
                                 "points_within_1e-7": accepted}
            settings.append(setting)
        families.append({"photons": n, "seed": runs[0]["seed"],
                         "significand_bits": runs[0]["significand_bits"], "settings": settings})
    return {"reference": "Ochirov Eq. (35), complete Abelian sum of all labeled photon permutations",
            "quantity": "complex scalar multiplying the common massive-spin bracket",
            "relative_difference": "abs(complete - altered) / max(abs(complete), abs(altered))",
            "relative_tolerance": 1e-7, "points_per_parameter_setting": 100000,
            "kinematics": "same generated sample as literature-four-settings-N*.json, 8 <= sqrt(s)/m <= 80",
            "point_indices": "one-based across the four interleaved settings at each multiplicity",
            "points_total": 2000000, "families": families}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pieces", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    raw = [json.loads(path.read_text()) for path in sorted(args.pieces.glob("N*.json"))]
    args.output.write_text(json.dumps(summarize(raw), indent=2) + "\n")
