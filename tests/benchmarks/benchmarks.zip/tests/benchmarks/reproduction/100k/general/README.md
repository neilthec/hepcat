# General QED formulas and independent published-amplitude checks

Each primary MadGraph sample contains 100,000 physical phase-space points per photon multiplicity. The all-positive and one-negative one-pair tests cover two through eight photons. The two-pair tests cover zero through five. A second one-negative sample uses independent seeds. Each independent literature or low-point catalog comparison uses at least 100,000 points per tested parameter setting. The 32 and 258 exact Mathematica checks count algebraic assertions.

The one-pair MadGraph results sum the four absolute squares of the complex amplitudes over the two massive spins. The two-pair tests sum all 16. Photon helicities are fixed. The weights carry neither a spin average nor an identical-particle factor. All widths vanish. The charge is one third, and the incoming energy is sampled logarithmically from 10 to 100. The fermion mass is one through seven photons and 1.5 at eight photons. Each report records the helicity family, count, mass, charge, seed and tolerance. The literature reports contain their own mass, charge and energy choices.

Run `python3 verify.py` in this directory to audit the stored point counts and repeat the summary calculations from all saved threshold crossings.

The [scalar-collection regression](scalar-collection/README.md) checks the five-point constructor, all 38 paper expressions, the mixed-helicity notebook calls and the 14 compiled process sources.

## Reproducing the calculations

Use Python 3, a C++11 compiler, a SPINAS source checkout and a matching SPINAS static library compiled with `WITH_LONG_DOUBLE`. The archived native results use a 53-bit significand. On Apple Silicon the native long-double ABI has this precision. The higher-precision controls use x86 long double with a 64-bit significand. The remaining one-negative exceptions are reevaluated with mpmath 1.3.0 at 45 and 70 decimal digits, first on the original inputs and then with the mass shells and momentum conservation restored. A Linux x86 host may have native long double with a 64-bit significand. Confirm the significand in the program output when comparing precision-specific results. The MadGraph references require MadGraph5_aMC@NLO, its standard model files, GNU Fortran and make. The symbolic controls require Wolfram Language and the two HEPCAT test fixtures in the repository.

From the repository root, these commands reproduce the individual stages. Replace the three installation paths below with local paths.

```sh
driver=tests/benchmarks/reproduction/100k/general/run.py
out="$PWD/general-validation-results"
spinas=/path/to/spinas
lib=/path/to/matching/libspinas.a
mg=/path/to/MG5_aMC
python3 "$driver" exact --output "$out" --kernel /path/to/WolframKernel
python3 "$driver" literature --spinas "$spinas" --library "$lib" --output "$out"
python3 "$driver" literature_controls --spinas "$spinas" --library "$lib" --output "$out"
python3 "$driver" components --spinas "$spinas" --library "$lib" --output "$out"
python3 "$driver" general --spinas "$spinas" --library "$lib" --madgraph "$mg" --output "$out"
python3 "$driver" controls --spinas "$spinas" --library "$lib" --madgraph "$mg" --output "$out"
python3 "$driver" split --spinas "$spinas" --library "$lib" --madgraph "$mg" --output "$out"
python3 "$driver" retests --spinas "$spinas" --library "$lib" --output "$out/native-repeat"
python3 "$driver" retests --spinas "$spinas" --wide-library /path/to/extended/libspinas.a --output "$out/extended-repeat"
```

On an Apple Silicon host with an x86 extended-precision build, add `--wide-flags='-arch x86_64'` to the last command. Use `--family positive|minus|minus-secondary|two` and `--photons N` with `general` to rerun a single sample. Independent references are generated from the requested external particles and identical parameter cards for the two calculations. The unpolarized spin and photon helicity sums in the main-text timing study are separate calculations.

The generator stores reference libraries and model metadata in the output directory. The general validation writes the pointwise rates, complex components, errors and full external momenta to gzip-compressed CSV files. The retained reference matrices and compiled libraries used for the paper are identified by SHA-256 in `results/source-and-reference-sha256.json`. Recompilation on another platform can change library fingerprints. The generated matrix source and parameter card are recorded separately. The two-pair comparison against published four-quark amplitudes is documented in the accompanying independent study.

## Reading the evidence

- `positive-N*.json` contains the physical- and spurious-pole recursions, their complex phase-sensitive comparison, the collected physical representation and the scalar ordering check.
- `minus-N*.json` and `minus-secondary-N*.json` contain the independently seeded one-negative samples. Each point tests the rate against MadGraph, changes the square reference spinor, permutes the positive photons, moves the negative photon and evaluates the Ward identity.
- `two-N*.json` contains the two-pair MadGraph rate and the common-reference, permutation and current-conservation checks. The component-wise Ward diagnostic uses the magnitude of one spin current. For a nearly vanishing spin current this ratio can grow much larger than the Ward residual normalized to the full spin tensor.
- `*-retest.json` records the native counts and same-input higher-precision results for crossings of the original tolerance. The compressed `threshold-retests.tar.gz` stores every selected point, its MadGraph rate and the native and extended errors from evaluating the two forms. The scripts parse each saved coordinate through double before promoting it. The exact binary64 inputs are thereby held fixed. Retests are subsets of their parent 100,000-point samples. For any remaining two-pair component Ward exception, the projection control restores the external mass shells and momentum conservation and repeats the current-conservation checks on the adjusted momenta. The point-8223 trace exports the 64-significand-bit momenta in hexadecimal and records the absolute divergence, the four-component current norm, and the corresponding full spin-tensor norms. It repeats the complete current calculation at 45 and 70 decimal digits, both at those unchanged coordinates and after a higher-precision restoration.
- `components-*.jsonl` compares every complex massive-spin component directly with both pole forms in the catalog. The archive `catalog-spin-components.tar.gz` contains the generated source and associated headers actually used for these comparisons. Each row uses one fixed mass and charge with 100,000 points.
- `literature-four-settings-N*.json` uses Ochirov's complete Abelian all-positive sum and compares both recursions. At three photons the code also evaluates Das and Zeng's Eq. (4.10). `literature-one-minus.json` gives the results for the independently implemented one-negative amplitude, including the unused BCJ equations and the omitted-orderings negative control.
- `literature-negative-controls.json` compares two deliberately modified versions of Ochirov’s Eq. (35) with its complete Abelian sum on the same 2,000,000 points as the positive-helicity literature test. One keeps only the first photon ordering. The other omits the factor of `sqrt(2)` at every vertex. For each mass and charge the report gives the minimum and maximum relative difference, how many exceed the chosen tolerances, and the indices of any points where a modified formula still agrees at `1e-7`.
- `native-split-control.json` compares two complete MadGraph exports at seven photons. Every point and each of its four massive-spin evaluations enter separately.
- `positive-low-control.log` reports comparisons with established two-, three- and four-photon formulas. `positive-negative-control.json` records a deliberate charge mismatch used to test whether the comparison detects incorrect normalization.
