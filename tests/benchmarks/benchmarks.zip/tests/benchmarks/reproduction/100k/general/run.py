#!/usr/bin/env python3
"""Run the QED general-formula and literature checks from their publication sources."""
import argparse
import csv
import ctypes
import gzip
import json
import math
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tarfile

HERE = Path(__file__).resolve().parent
FAMILIES = {
    'positive': ('all-positive', range(2, 9), 2026111900),
    'minus': ('one-minus', range(2, 9), 2026112900),
    'minus-secondary': ('one-minus', range(2, 9), 201151817),
    'two': ('four-fermion-all-plus', range(6), 2026113900),
}
PROCESSES = [(2,3,'eeAAA'), (2,4,'eeAAAA'), (4,0,'eeee'), (4,1,'eeeeA'), (4,2,'eeeeAA')]


def unpack(archive, target):
    with tarfile.open(archive) as tar:
        for item in tar.getmembers():
            if not item.isfile() or Path(item.name).is_absolute() or '..' in Path(item.name).parts:
                raise ValueError(f'Unexpected archived path {item.name}')
            dest = target / item.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            with dest.open('wb') as stream:
                shutil.copyfileobj(tar.extractfile(item), stream)


class Campaign:
    def __init__(self, args):
        self.args = args
        self.out = args.output.resolve()
        self.out.mkdir(parents=True, exist_ok=True)
        self.repo = args.repo.resolve()
        self.bench = self.repo / 'tests/benchmarks'
        self.export = self.repo / 'source/internal/export'
        self.bins = self.out / 'bin'
        self.bins.mkdir(exist_ok=True)

    def build(self, name, sources, flags=(), wide=False):
        binary = self.bins / name
        lib = self.args.wide_library if wide else self.args.library
        if lib is None:
            raise ValueError('Supply the SPINAS library matching the requested arithmetic')
        opts = self.args.wide_flags if wide else self.args.flags
        includes = [self.args.spinas.resolve(), self.args.spinas.resolve() / 'include', self.bench, self.export]
        cmd = [self.args.cxx, '-std=c++11', '-O2', '-DWITH_LONG_DOUBLE', *shlex.split(opts), *flags]
        cmd.extend('-I' + str(p) for p in includes)
        cmd.extend(map(str, sources))
        cmd.extend([str(lib.resolve()), '-o', str(binary)])
        if sys.platform.startswith('linux'):
            cmd.append('-ldl')
        subprocess.run(cmd, check=True)
        return binary

    def exact(self):
        with (self.out/'alt-five-point.json').open('w') as f:
            subprocess.run([sys.executable,str(HERE/'src/alt-five-point.py')], stdout=f, check=True)
        with (self.out/'das-zeng-five-point.json').open('w') as f:
            subprocess.run([self.args.kernel,'-script',str(HERE/'src/das-zeng-five-point.wl')], stdout=f, check=True)
        for stem in ('one-minus','four-fermion-all-plus'):
            src = self.bench / (stem+'-symbolic-tests.wl')
            log = self.out / (stem+'-symbolic.log')
            with log.open('w') as f:
                subprocess.run([self.args.kernel,'-script',str(src)], stdout=f, stderr=subprocess.STDOUT, check=True)
            if 'FAILURES 0' not in log.read_text() or '_SYMBOLIC_TESTS_PASS' not in log.read_text():
                raise ValueError(log)

    def literature(self):
        for stem in ('literature-one-minus', 'literature-all-positive'):
            exe = self.build(stem, [self.bench / (stem+'-validation.cpp')])
            if stem=='literature-one-minus':
                with (self.out/'literature-one-minus.json').open('w') as f:
                    subprocess.run([str(exe),'--points-per-configuration','100000','--seed','731042'],stdout=f,check=True)
            else:
                subprocess.run([str(exe),'400000',str(self.out/'literature-four-settings')],check=True)

    def literature_controls(self):
        exe = self.build('literature-controls', [HERE/'src/literature-controls.cpp'])
        parts = self.out/'literature-control-parts'
        parts.mkdir(exist_ok=True)
        for n in range(2, 7):
            with (parts/f'N{n}.json').open('w') as stream:
                subprocess.run([str(exe), str(n), '0', '400000'], stdout=stream, check=True)
        subprocess.run([sys.executable, str(HERE/'src/literature-controls.py'), str(parts),
                        str(self.out/'literature-negative-controls.json')], check=True)

    def components(self):
        sources = self.out/'catalog-spin-components'
        unpack(HERE/'catalog-spin-components.tar.gz', sources)
        for f,n,name in PROCESSES:
            for mode in ('physical','spurious'):
                directory = sources/mode/name
                flags = [f'-DFERMIONS={f}',f'-DPHOTONS={n}',f'-DPROCESS={name}','-I'+str(directory)]
                key = f'components-{f}f-{n}g-{mode}'
                exe = self.build(key,[HERE/'src/components.cpp',directory/'process.cpp'],flags)
                with (self.out/(key+'.jsonl')).open('w') as log:
                    subprocess.run([str(exe)], stdout=log, check=True)

    def reference(self, family, n, unsplit=False):
        pair = family=='two'
        key = ('unsplit' if unsplit else 'two' if pair else 'one')+f'-{n}'
        root = self.out/'references'/key
        result = root/'result.json'
        if not result.exists():
            if not self.args.madgraph:
                raise ValueError('Supply the MadGraph installation with --madgraph')
            m = 1.5 if n==8 else 1
            f = 4 if pair else 2
            config = dict(MadGraphDirectory=str(self.args.madgraph.resolve()),MadGraphModel='sm-full',
                          PhysicalPDGs=[11,-11]*(f//2)+[22]*n,AllowedParticlePDGs=[11,22],
                          Masses=[m]*f+[0]*n, Parameters=[dict(Name='Me',Value=m),dict(Name='EE',Value=1/3)],
                          ParameterRules={},ParameterMap={},ZeroWidths=True,TimeConstraint=14400)
            config['JampSplit'] = 128 if (not pair and n>=7 and not unsplit) or (pair and n==5) else 0
            config['OptimizationLevel'] = 0 if not pair and n>=6 else 1 if pair and n==5 else 3
            root.parent.mkdir(exist_ok=True)
            card=root.parent/(key+'.json')
            card.write_text(json.dumps(config, indent=2))
            subprocess.run([sys.executable,str(self.export/'madgraph-runtime.py'),'--config',str(card),'--output',str(root)], check=True)
        manifest=json.loads(result.read_text())
        if manifest['Status']!='READY':
            raise ValueError(result)
        library=root/Path(manifest['Library']).name
        if not library.is_file():
            raise FileNotFoundError(library)
        return root,library

    def general(self):
        names = {}
        for family,(stem,orders,seed) in FAMILIES.items():
            if self.args.family and family!=self.args.family:
                continue
            if stem not in names:
                names[stem] = self.build(stem,[self.bench/(stem+'-validation.cpp')])
            for n in orders:
                if self.args.photons is not None and n!=self.args.photons:
                    continue
                root, lib = self.reference(family,n)
                prefix = self.out / (family+f'-N{n}')
                cmd = [str(names[stem]),'--photons',str(n),'--points','100000','--seed',str(seed+n),
                       '--mass',str(1.5 if n==8 else 1),'--reference',str(lib),'--output',str(prefix)]
                code = subprocess.run(cmd,cwd=root).returncode
                report=prefix.with_suffix('.json')
                if code not in (0,1) or not report.is_file() or json.loads(report.read_text())['Points']!=100000:
                    raise RuntimeError(prefix)
                if not self.args.keep_uncompressed:
                    for suffix in ('-points.csv','-values.csv'):
                        p=Path(str(prefix)+suffix)
                        with p.open('rb') as fin, gzip.open(str(p)+'.gz','wb',compresslevel=1) as fout:
                            shutil.copyfileobj(fin,fout)
                        p.unlink()
        # Nonzero threshold counts in intact 100,000-point reports are scientific results.
        # Missing rows, reference build failures and invalid files stop the campaign.

    def controls(self):
        src=(self.bench/'all-positive-validation.cpp').read_text()
        if 'sample < 20;' in src:
            src=src.replace('sample < 20;', 'sample < 200000;')
        private=self.out/'small-controls.cpp'
        private.write_text(src)
        exe=self.build('small-controls',[private])
        with (self.out/'positive-low-control.log').open('w') as log:
            subprocess.run([str(exe),'--self-test'],stdout=log,check=True)
        root,lib=self.reference('positive',2)
        prefix=self.out/'positive-negative-control'
        code=subprocess.run([str(exe),'--photons','2','--points','100000','--mass','1','--charge','0.35',
                             '--seed','2026111984','--reference',str(lib),'--output',str(prefix)],cwd=root).returncode
        result=json.loads(prefix.with_suffix('.json').read_text())
        if code!=1 or result['Failures']!=result['Points'] or result['Points']!=100000:
            raise RuntimeError('Wrong-charge control did not fail at every point')

    def split(self):
        roots=[self.reference('positive',7,unsplit=u) for u in (True,False)]
        from os import chdir,getcwd
        old=getcwd()
        try:
            libs=[]
            for root,path in roots:
                chdir(root)
                lib=ctypes.CDLL(str(path))
                if lib.hepcat_mg_initialize()!=0:raise RuntimeError(path)
                lib.hepcat_mg_evaluate.argtypes=[ctypes.POINTER(t) for t in (ctypes.c_double,ctypes.c_int,ctypes.c_double)]
                libs.append(lib)
            pa=(ctypes.c_double*36)()
            h=(ctypes.c_int*9)(*([1]*9))
            count=unequal=0
            maximum=0.
            with open_csv(self.out/'positive-N7-points.csv') as f:
                rows=csv.reader(f);next(rows)
                for row in rows:
                    point,leg=map(int,row[:2])
                    if point!=count+1:raise ValueError(row)
                    pa[(leg-1)*4:leg*4]=list(map(float,row[2:]))
                    if leg<9:continue
                    for a in (-1,1):
                        for b in (-1,1):
                            h[0]=a;h[1]=b
                            values=[ctypes.c_double() for lib in libs]
                            for lib,v in zip(libs,values):lib.hepcat_mg_evaluate(pa,h,ctypes.byref(v))
                            x,y=(v.value for v in values)
                            if not all(math.isfinite(v) and v>=0 for v in (x,y)):raise ValueError(point)
                            unequal+=int(x!=y)
                            maximum=max(maximum,abs(x-y)/max(x,y) if x or y else 0.)
                    count+=1
            if count!=100000:raise ValueError(count)
            (self.out/'native-split-control.json').write_text(json.dumps(dict(points=count,individual_spins_per_point=4,unequal_individual_values=unequal,maximum_individual_relative_error=maximum),indent=2))
        finally:chdir(old)

    def retests(self):
        path=self.out/'selected-retests'
        unpack(HERE/'results/threshold-retests.tar.gz',path)
        for family in ('minus','two','positive'):
            suffix='-'+family+'.cpp'
            exe=self.build('retest-'+family,[HERE/'src'/('retest'+suffix)],wide=self.args.wide_library is not None)
            for p in sorted(path.glob(family+'-*-selected.csv')):
                n=int(p.name.split('-N')[-1].split('-')[0]); prefix=self.out/(p.stem+'-new')
                if family=='positive':
                    cmd=[str(exe),str(p),str(prefix.with_suffix('.csv'))]
                else:
                    cmd=[str(exe),'--photons',str(n),'--mass',str(1.5 if n==8 else 1),'--reference',str(p),'--output',str(prefix)]
                subprocess.run(cmd,check=True)
                if family=='two' and n==5 and self.args.wide_library:
                    with prefix.with_suffix('.csv').open() as f:
                        flagged={int(r[0]) for r in csv.reader(f) if max(map(float,r[1:]))>1e-7}
                    selected=self.out/'two-N5-extended-flagged.csv'
                    with selected.open('w') as out, p.open() as inp:
                        r=csv.reader(inp);w=csv.writer(out);w.writerow(next(r))
                        w.writerows(row for row in r if int(row[0]) in flagged)
                    check=self.build('two-ward-projection',[HERE/'src/two-ward-projection.cpp'],wide=True)
                    subprocess.run([str(check),'--photons','5','--mass','1','--reference',str(selected),
                                    '--output',str(self.out/'two-N5-projected64')],check=True)
                    trace=self.build('two-pair-component',[HERE/'src/two-pair-component.cpp'],wide=True)
                    hex_coordinates=self.out/'two-N5-point8223-hex.csv'
                    trace_table=self.out/'two-N5-point8223-x87.csv'
                    subprocess.run([str(trace),str(p),str(hex_coordinates),str(trace_table)],check=True)
                    subprocess.run([sys.executable,str(HERE/'src/two-pair-component.py'),str(hex_coordinates),
                                    str(trace_table),str(self.out/'two-N5-point8223-multiprecision.json')],check=True)
                if family=='minus' and n==8 and self.args.wide_library:
                    subprocess.run([sys.executable,str(HERE/'src/one-minus-multiprecision.py'),str(p),
                                    str(prefix.with_suffix('.csv')),str(self.out/(p.stem+'-multiprecision.json'))], check=True)


def open_csv(path):
    return path.open() if path.is_file() else gzip.open(str(path)+'.gz','rt')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=['all','literature','literature_controls','components','general','exact','controls','retests','split'])
    p.add_argument('--repo',type=Path,default=HERE.parents[4])
    p.add_argument('--spinas',type=Path,default=Path('.'))
    p.add_argument('--library',type=Path)
    p.add_argument('--wide-library',type=Path)
    p.add_argument('--flags',default='')
    p.add_argument('--wide-flags',default='')
    p.add_argument('--cxx',default='c++')
    p.add_argument('--kernel',default='WolframKernel')
    p.add_argument('--madgraph',type=Path)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--family',choices=list(FAMILIES))
    p.add_argument('--photons',type=int)
    p.add_argument('--keep-uncompressed',action='store_true')
    args=p.parse_args()
    stages=['exact','literature','literature_controls','components','general','controls','split','retests'] if args.stage=='all' else [args.stage]
    run=Campaign(args)
    for name in stages:getattr(run,name)()


if __name__=='__main__':
    main()
