// Trace the maximally amplified spin component in a selected two-pair Ward check.
#include "two-pair-instrumented.hpp"
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

using Formula = hepcat_four_fermion_all_plus::Formula<5>;
using Momenta = Formula::Momenta;

void report(const Momenta& p, std::string label, std::ostream& coordinates, std::ostream& diagnostics) {
    const Formula formula(p,1,static_cast<ldouble>(double(1)/3));
    const auto& d = formula.worst_detail;
    diagnostics << std::setprecision(std::numeric_limits<ldouble>::max_digits10)
                << label << ',' << d.family << ',' << d.mask << ',' << d.spin_a << ',' << d.spin_b << ','
                << d.divergence << ',' << d.current_norm << ',' << d.k_norm << ','
                << d.tensor_divergence << ',' << d.tensor_current_norm << ','
                << formula.component_ward_relative_error() << ',' << formula.ward_relative_error() << '\n';
    coordinates << std::hexfloat << label;
    for(const auto& row:p)for(const auto& entry:row) coordinates << ',' << entry;
    coordinates << '\n';
}

int main(int argc,char** argv) {
    if(argc!=4 || std::numeric_limits<ldouble>::digits!=64) return 2;
    std::ifstream in(argv[1]);
    std::ofstream coordinates(argv[2]),diagnostics(argv[3]);
    if(!in || !coordinates || !diagnostics) return 3;
    std::string line;
    std::getline(in,line);
    diagnostics << "kinematics,family,mask,spin_a,spin_b,abs_divergence,current_norm,k_norm,tensor_divergence,tensor_current_norm,component_ratio,max_tensor_ratio\n";
    while(std::getline(in,line)) {
        std::replace(line.begin(),line.end(),',',' ');
        std::istringstream fields(line);
        int point;
        double rate;
        fields >> point >> rate;
        if(point!=8223) continue;
        Momenta p;
        for(auto& row:p)for(auto& x:row){double raw;fields>>raw;x=raw;}
        if(!fields) return 4;
        report(p,"original",coordinates,diagnostics);
        for (unsigned mu=1;mu<4;++mu) {
            p.back()[mu]=0;
            for (unsigned k=2;k+1<p.size();++k) p.back()[mu]-=p[k][mu];
        }
        ldouble total=0;
        for (unsigned k=2;k<p.size();++k) {
            const ldouble mass=k<4?1:0;
            p[k][0]=std::hypot(std::hypot(mass,p[k][1]),std::hypot(p[k][2],p[k][3]));
            total+=p[k][0];
        }
        const ldouble energy=total/2;
        const ldouble z=std::sqrt((energy-1)*(energy+1));
        p[0]={{energy,0,0,z}};p[1]={{energy,0,0,-z}};
        report(p,"x87_projection",coordinates,diagnostics);
        return 0;
    }
    return 5;
}
