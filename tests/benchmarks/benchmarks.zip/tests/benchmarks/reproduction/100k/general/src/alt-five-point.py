"""Independent exact formal check of Ema et al. v2 Eq. (3.23).

Uses only antisymmetry of two-spinor brackets and scalar commutativity.
Momentum chains are independent ORDERED atoms; no momentum, Dirac,
Schouten, internal-shell, or reference identities are supplied.
Denominator atoms are formal Laurent variables.
"""
from collections import defaultdict
from fractions import Fraction
import json


class Laurent:
    def __init__(self, terms=None):
        self.terms = {key: Fraction(value) for key, value in (terms or {}).items() if value}

    def __add__(self, other):
        result = defaultdict(Fraction, self.terms)
        for key, value in other.terms.items():
            result[key] += value
        return Laurent(result)

    def __neg__(self):
        return Laurent({key: -value for key, value in self.terms.items()})

    def __sub__(self, other):
        return self + (-other)

    def __mul__(self, other):
        result = defaultdict(Fraction)
        for left, lv in self.terms.items():
            for right, rv in other.terms.items():
                powers = defaultdict(int)
                for atom, exponent in left + right:
                    powers[atom] += exponent
                key = tuple(sorted((atom, exponent) for atom, exponent in powers.items() if exponent))
                result[key] += lv * rv
        return Laurent(result)

    def parity(self):
        result = defaultdict(Fraction)
        flip = {"A": "S", "S": "A", "CA": "CS", "CS": "CA"}
        for key, value in self.terms.items():
            mapped = tuple(sorted(((flip.get(atom[0], atom[0]),) + atom[1:], power)
                                  for atom, power in key))
            result[mapped] += value
        return Laurent(result)


def atom(kind, *labels, exponent=1, sign=1):
    return Laurent({(((kind,) + labels, exponent),): sign})


def bracket(kind, a, b):
    if a == b:
        return Laurent()
    return atom(kind, min(a, b), max(a, b), sign=1 if a < b else -1)


def A(a, b):
    return bracket("A", a, b)


def S(a, b):
    return bracket("S", a, b)


def tau_inverse(a, i):
    return atom("tau", min(a, i), max(a, i), exponent=-1)


def s_inverse(a, b):
    return atom("s", min(a, b), max(a, b), exponent=-1)


def B(a, b, c, d):
    # Current QED manuscript, cat:vector-tensor.
    return A(b, d)*S(a, c) + A(b, c)*S(a, d) + A(a, d)*S(b, c) + A(a, c)*S(b, d)


def R(a, b, c, d, i):
    # Current QED manuscript, cat:radiation-block.
    return (S(a, i)*(S(i, d)*A(b, c) + S(i, c)*A(b, d))*tau_inverse(a, i)
            - S(b, i)*(S(i, d)*A(a, c) + S(i, c)*A(a, d))*tau_inverse(b, i)
            + B(a, b, c, d)*atom("CS", i, b, a, i)*tau_inverse(a, i)*tau_inverse(b, i))


def ema_negative_channel(a, b, c, d, i):
    # Direct Eq. (3.23) transcription, divided by e_tilde**3.
    b_ema = A(a, d)*S(b, c) + A(b, d)*S(a, c) + A(a, c)*S(b, d) + A(b, c)*S(a, d)
    radiation = (atom("CA", i, d, c, i)*b_ema*tau_inverse(c, i)*tau_inverse(d, i)
                 + (S(a, d)*A(b, i) + S(b, d)*A(a, i))*A(c, i)*tau_inverse(c, i)
                 - (S(a, c)*A(b, i) + S(b, c)*A(a, i))*A(d, i)*tau_inverse(d, i))
    return radiation*s_inverse(a, b)


def mapped_ema_direct(a, b, c, d, i):
    # Canonical labels (a electron, b positron, c positron, d electron).
    # Ema labels (a,b,d,c), followed by its pair-swap contribution.
    return (ema_negative_channel(a, b, d, c, i)
            + ema_negative_channel(d, c, a, b, i)).parity()


def manuscript_direct(a, b, c, d, i):
    return R(a, b, c, d, i)*s_inverse(c, d) + R(d, c, a, b, i)*s_inverse(a, b)


checks = []


def check(name, expression):
    residual = len(expression.terms)
    assert residual == 0, (name, expression.terms)
    checks.append({"name": name, "residual_monomials": residual})


check("Parity of Ema displayed channel equals R(3,4;1,2;5)/s12",
      ema_negative_channel(1, 2, 3, 4, 5).parity() - R(3, 4, 1, 2, 5)*s_inverse(1, 2))
check("R symmetry in spectator pair", R(1, 2, 3, 4, 5)-R(1, 2, 4, 3, 5))
check("Mapped direct-pair amplitude", mapped_ema_direct(1, 2, 3, 4, 5)-manuscript_direct(1, 2, 3, 4, 5))
check("Mapped exchanged-positron amplitude", mapped_ema_direct(1, 3, 2, 4, 5)-manuscript_direct(1, 3, 2, 4, 5))
ema_full = mapped_ema_direct(1, 2, 3, 4, 5)-mapped_ema_direct(1, 3, 2, 4, 5)
manuscript_full = (R(1, 2, 3, 4, 5)*s_inverse(3, 4)
                   + R(4, 3, 1, 2, 5)*s_inverse(1, 2)
                   - R(4, 2, 1, 3, 5)*s_inverse(1, 3)
                   - R(1, 3, 2, 4, 5)*s_inverse(2, 4))
check("Complete identical-fermion manuscript formula", ema_full-manuscript_full)

# Negative control: reversing the two inserted momenta is NOT permitted.
channel = ema_negative_channel(1, 2, 3, 4, 5).parity()
wrong_order = defaultdict(Fraction)
for key, value in channel.terms.items():
    wrong_key = tuple(sorted((((atom[0], atom[1], atom[3], atom[2], atom[4])
                              if atom[0] == "CS" else atom), exponent)
                            for atom, exponent in key))
    wrong_order[wrong_key] += value
wrong_residual = Laurent(wrong_order) - R(3, 4, 1, 2, 5)*s_inverse(1, 2)
assert wrong_residual.terms

print(json.dumps({
    "status": "PASS",
    "checks": checks,
    "coefficient": "e_tilde=sqrt(2)*e, hence e_tilde^3=2*sqrt(2)*e^3",
    "denominator_dictionary": "2*p_j.dot(p5)=tau_j5; p_ab^2=s_ab",
    "normal_form_monomials_full_amplitude": len(manuscript_full.terms),
    "negative_control_reversed_chain_residual_monomials": len(wrong_residual.terms),
    "kinematic_sample_count": 0,
    "internal_shell_conditions_used": False,
    "additional_spinor_or_momentum_identities_used": False,
}, indent=2))
