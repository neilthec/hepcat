(* Regenerate the fourteen process.cpp files using the finite QED catalog.
   HEPCAT_VALIDATION_OUTPUT must designate a working output directory. *)
qfolder=DirectoryName[ExpandFileName[$InputFileName]];
qroot=Environment["HEPCAT_ROOT"];
If[!StringQ[qroot] || qroot==="",qroot=Nest[DirectoryName,qfolder,6]];
qoutput=Environment["HEPCAT_VALIDATION_OUTPUT"];qspinas=Environment["SPINAS_ROOT"];
If[!StringQ[qoutput]||qoutput===""||!StringQ[qspinas]||!DirectoryQ[qspinas],Quit[2]];
If[!DirectoryQ[qoutput],CreateDirectory[qoutput,CreateIntermediateDirectories->True]];
Get[FileNameJoin[{qroot,"source","HEPCAT.wl"}]];$HistoryLength=0;
(* The original C++ files used the exporter's full expression-sharing plan.
   Let it finish under load with a longer wall-time budget. *)
qopt=Import[FileNameJoin[{qroot,"source","internal","HEPCAT-SPINAS-Optimize.wl"}],"Text"];
If[StringCount[qopt,"timeBudget = 30,"]=!=1,Print["Cannot identify the optimizer budget."];Quit[2]];
qoptfile=FileNameJoin[{qoutput,"optimizer-with-extended-time.wl"}];
Export[qoptfile,StringReplace[qopt,"timeBudget = 30,"->"timeBudget = 300,"],"Text"];Get[qoptfile];
qcat=FileNameJoin[{qroot,"tests","benchmarks","reproduction","100k","catalog"}];
qrows=Import[FileNameJoin[{qcat,"input-expressions.wxf"}],"WXF"];
qwanted=Import[FileNameJoin[{qcat,"symbolic-exports.json"}],"RawJSON"]["processes"];
qfamilies=Import[FileNameJoin[{qfolder,"export-families.json"}],"RawJSON"];
qnb=Get[FileNameJoin[{qroot,"tests","QED-6-point-construction.nb"}]];
qcells=Select[Cases[qnb,Cell[code_String,"Input",___]:>code,Infinity],
  StringContainsQ[#,"qedBalancedPhotonCurrent[endpoints_List"]&];
If[Length[qcells]=!=1,Quit[2]];ToExpression[First[qcells]];
qmodels=<|"physical"->ReadModel[FileNameJoin[{qroot,"models"}],3],
  "spurious"->ReadModel[FileNameJoin[{qroot,"models"}],4]|>;
qresults=Table[
  qform=job["form"];qname=job["name"];qmodel=qmodels[qform];
  qexpected=SelectFirst[qwanted,#["form"]===qform && #["process"]===qname&]["process_cpp_sha256"];
  qentries=Table[
    With[{row=SelectFirst[qrows,#["form"]===qform && #["particles"]===qparticles&]},
      {qparticles,row["expression"]/.p_ModelParameter:>ModelParameter[qmodel,ModelParameterName[p]]}],
    {qparticles,job["order"]}];
  If[qname==="eeAAAA",
    qbalanced=CollectAmplitudeFactors[qedBalancedPhotonCurrent[{1,2},{3,4},{5,6},
      ModelParameter[qmodel,"Me"],4 ModelParameter[qmodel,"EE"]^4,
      If[qform==="physical","Physical","SingleBracket"]],Infinity];
    If[Together[qbalanced-qentries[[3,2]]]=!=0,Print["Balanced tensor mismatch."];Quit[1]];
    qentries[[3,2]]=qbalanced];
  qlegs=qentries[[1,1]];
  qphysical=Take[qlegs,2]->(Drop[qlegs,2]/.{"e"->"E","E"->"e","A.+"|"A.-"->"A"});
  qdest=FileNameJoin[{qoutput,qform,qname}];
  qexport=WriteSPINASProcess[qdest,qphysical,qentries,qmodel,"ProcessName"->qname,
    "Precision"->job["precision"],"SPINASDirectory"->qspinas,"Build"->False,"Overwrite"->True];
  qhash=FileHash[FileNameJoin[{qdest,"process.cpp"}],"SHA256","HexString"];
  Print[qform," ",qname," ",qhash===qexpected];
  <|"form"->qform,"process"->qname,"sha256"->qhash,"matches"->(qhash===qexpected)|>,{job,qfamilies}];
Export[FileNameJoin[{qoutput,"regenerated-sources.json"}],qresults,"RawJSON"];
Quit[If[Length[qresults]===14 && And@@Lookup[qresults,"matches"],0,1]];
