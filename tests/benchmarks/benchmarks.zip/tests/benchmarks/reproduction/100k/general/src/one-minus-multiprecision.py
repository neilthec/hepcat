#!/usr/bin/env python3
"""Higher-precision one-negative checks on events still over tolerance at 64 bits."""
import argparse
import csv
import json
import math
from pathlib import Path
import mpmath as mp


def spinors(p, mass):
    energy,x,y,z=p
    rho=mp.sqrt(x*x+y*y)
    length=mp.sqrt(rho*rho+z*z)
    large=mp.sqrt((1+abs(z)/length)/2) if length else mp.mpf(1)
    small=rho/length/(2*large) if length else mp.mpf(0)
    c,s=(large,small) if z>=0 else (small,large)
    if rho:s*=mp.mpc(x,y)/rho
    root=mp.sqrt(energy+length)
    smallroot=mass/root
    def longitudinal(sign):
        if sign*z>=0:return energy+sign*z
        return (mass*mass+rho*rho)/(energy+abs(z))
    return dict(la={-1:(root*s,-root*c),1:(smallroot*c,smallroot*mp.conj(s))},
                ra={-1:(root*c,root*s),1:(-smallroot*mp.conj(s),smallroot*c)},
                ls=(root*c,root*mp.conj(s)),rs=(root*mp.conj(s),-root*c),
                matrix=((longitudinal(1),mp.mpc(x,-y)),(mp.mpc(x,y),longitudinal(-1))))


def contract(a,b):return a[0]*b[0]+a[1]*b[1]
def minkowski(a,b):return a[0]*b[0]-sum(a[i]*b[i] for i in (1,2,3))
def difference(a,b):
    scale=max([abs(z) for z in a+b])
    return max(abs(x-y) for x,y in zip(a,b))/scale if scale else 0


def evaluate(p, order, external_ref, negative=None):
    n=len(p)-2; mass=mp.mpf('1.5')
    charge=mp.mpf(float(1/3))
    particles=[spinors(momentum,mass if j<2 else 0) for j,momentum in enumerate(p)]
    if negative is None:negative=len(p)-1
    h=particles[negative]
    if external_ref:ref=spinors((1,0,1,0),0)
    else:
        refidx=max(order,key=lambda i:abs(contract(h['ls'],particles[i]['rs']))**2/p[i][0])
        ref=particles[refidx]
    def chain(internal,end):
        left=h['la'][-1]; mat=particles[internal]['matrix']
        return contract([left[0]*mat[0][k]+left[1]*mat[1][k] for k in range(2)],end['rs'])
    angle=[contract(h['la'][-1],particles[i]['ra'][-1]) for i in order]
    bracket=contract(h['ls'], ref['rs'])
    ends=[[-chain(a,particles[i]) for i in order] for a in (0,1)]
    emitted=[[chain(j,particles[i]) if i!=j else 0 for j in order] for i in order]
    refvert=[chain(i,ref) for i in order]
    wardvert=[chain(i,h) for i in order]
    masks=range(1<<(n-1))
    subsets=[[i for i in range(n-1) if mask&(1<<i)] for mask in masks]
    current=[]
    for a in (0,1):
        values=[mp.mpc(1)]+[mp.mpc(0) for mask in range(1,len(masks))]
        for mask in range(1,len(masks)):
            members=subsets[mask]
            denominator=-2*sum(minkowski(p[a],p[order[i]]) for i in members)
            denominator+=2*sum(minkowski(p[order[i]],p[order[j]]) for i in members for j in members if j>i)
            terms=[]
            for i in members:
                prev=mask^(1<<i)
                vertex=ends[a][i]+sum(emitted[i][j] for j in subsets[prev])
                terms.append(values[prev]*vertex/angle[i])
            values[mask]=mp.fsum(terms)/denominator
        current.append(values)
    orbital=mp.mpc(0); spin=mp.mpc(0); ward=mp.mpc(0)
    ref_initial=chain(0,ref);ward_initial=chain(0,h)
    for mask in masks:
        right=(len(masks)-1)^mask
        weight=(-1)**len(subsets[right])*current[0][mask]*current[1][right]
        orbital+=weight*(-ref_initial+sum(refvert[i] for i in subsets[mask]))/bracket
        ward+=weight*(-ward_initial+sum(wardvert[i] for i in subsets[mask]))
        spin+=weight
    pref=(-mp.sqrt(2)*charge)**n/mass
    amps=[]
    for a in (-1,1):
        for b in (-1,1):
            la=particles[0]['la'][a];lb=particles[1]['la'][b]
            angle12=contract(la,particles[1]['ra'][b])
            spinfactor=contract(la,h['ra'][-1])*contract(lb,h['ra'][-1])
            amps.append(pref*(angle12*orbital+spinfactor*spin))
    energy=p[0][0]+p[1][0]
    scale=max(energy*abs(orbital),energy*energy*abs(spin))
    return amps,abs(ward)/scale if scale else abs(ward)


def project(p):
    q=[x[:] for x in p]
    for mu in (1,2,3):q[-1][mu]=-sum(row[mu] for row in q[2:-1])
    for row in q[2:]:row[0]=mp.sqrt(sum(x*x for x in row[1:]))
    energy=sum(row[0] for row in q[2:])/2
    z=mp.sqrt(energy*energy-mp.mpf('1.5')**2)
    q[0]=[energy,0,0,z];q[1]=[energy,0,0,-z]
    return q


def analyze(row, restore):
    original=[list(map(lambda x:mp.mpf(float(x)),row[i:i+4])) for i in range(2,len(row),4)]
    momenta=project(original) if restore else original
    order=list(range(2,len(momenta)-1))
    a,ward=evaluate(momenta,order,False)
    b,_=evaluate(momenta,order,True)
    permuted,_=evaluate(momenta,order[::-1],False)
    moved=momenta[:2]+list(reversed(momenta[2:]))
    relocated,_=evaluate(moved,list(range(3,len(moved))),False,negative=2)
    out={'negative_relocation':float(difference(a,relocated)),'reference':float(difference(a,b)),'positive_permutation':float(difference(a,permuted)),
         'ward':float(ward),'rate':float(sum(abs(x)**2 for x in a))}
    if restore:
        out['largest_momentum_adjustment']=float(max(abs(x-y) for p,q in zip(original,momenta) for x,y in zip(p,q)))
    else:
        rate=sum(abs(x)**2 for x in a);mg=mp.mpf(float(row[1]))
        out['relative_madgraph']=float(abs(rate-mg)/max(rate,mg))
    return out


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('points',type=Path);parser.add_argument('extended_errors',type=Path)
    parser.add_argument('output',type=Path);args=parser.parse_args()
    with args.extended_errors.open() as f:ids={int(row[0]) for row in csv.reader(f) if max(map(float,row[1:]))>1e-7}
    with args.points.open() as f:reader=csv.reader(f);next(reader);rows=[row for row in reader if int(row[0]) in ids]
    assert len(rows)==len(ids)
    results={}
    for row in rows:
        per_event={}
        for digits in (45,70):
            with mp.workdps(digits):
                per_event[str(digits)]={'unchanged':analyze(row,False),'restored':analyze(row,True)}
        # Rate and square-reference diagnostics must converge at both working precisions.
        for kind in ('unchanged','restored'):
            for key in ('rate','reference'):
                a=per_event['45'][kind][key];b=per_event['70'][kind][key]
                if abs(a-b)>max(1e-32,1e-14*max(abs(a),abs(b))):raise ValueError((row[0],kind,key,a,b))
        results[row[0]]=per_event
    out={'selection':'Every point with at least one diagnostic above 1e-7 using a 64-bit significand',
         'selected':len(rows),'decimal_digits':[45,70],
         'input':'Each saved coordinate is rounded to binary64, then promoted exactly.',
         'restoration':'Keep all but the last outgoing spatial momentum, fix the last by conservation, put each photon on shell, and match two equal-energy on-shell beams. Only internal identities are compared after this change.',
         'results':results}
    args.output.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
if __name__=='__main__':main()
