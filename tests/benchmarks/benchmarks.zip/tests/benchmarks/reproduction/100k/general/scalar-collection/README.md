# Scalar collection for the mixed three-photon amplitudes

The two input expressions in `original-mixed.wxf` are the mixed-helicity five-point results at seed 410073 before the additional collection. Each input consists of 343 Wolfram expression leaves and has spinor complexity 62. Their helicity orders are `++-` and `+--`.

Run the commands from this directory with Wolfram available. The scripts find the publication checkout from their location. Set `HEPCAT_ROOT` to check another installation.

```sh
WolframKernel -noinit -script verify.wl
WolframKernel -noinit -script verify-catalog.wl
WolframKernel -noinit -script verify-fallbacks.wl
WolframKernel -noinit -script verify-notebook.wl
```

The focused check invokes the ordinary public two-second collector on each saved expression. It checks the leaf count and spinor score, compares the exact reciprocal bases and proves the two bodies equal as rational expressions. Both new bodies have 324 leaves and retain the original spinor complexity of 62. The independent constructor regression runs from the repository root with the following command.

```sh
HEPCAT_FIVE_POINT_INTEGRATION_CASES=PPM,PMM WolframKernel -noinit -script tests/checks/five-point-construction-integration-tests.wl
```

The notebook check evaluates its six mixed-helicity and balanced collection cells, covering ten expressions. It compares ordinary and updated collection with unrestricted ordinary time and repeats the actual notebook calls with their recorded settings.

The catalog check applies the old and new collection paths to all 38 published expressions. It gives ordinary collection unlimited wall time for both evaluations. Set `HEPCAT_VALIDATION_OUTPUT` to an optional destination for its JSON output. The fallback checks deliberately exhaust the optional pass's time and memory budgets and confirm that the already accepted ordinary result survives. They also check that large trees bypass the optional step and that a zero time budget preserves the input.

To regenerate the 14 production `process.cpp` kernels from the formula catalog, set `SPINAS_ROOT` to the SPINAS checkout and `HEPCAT_VALIDATION_OUTPUT` to a working output directory. Run `WolframKernel -noinit -script verify-exports.wl`. It evaluates both four-photon balanced expressions through the notebook routine with unlimited time for ordinary collection, then checks each C++ file against its archived SHA-256. It gives common-subexpression elimination 300 seconds to reproduce the production layout.
