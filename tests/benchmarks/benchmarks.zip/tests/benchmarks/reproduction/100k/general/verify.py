#!/usr/bin/env python3
"""Audit the archived counts, exact checks and every saved same-input retest."""
import csv
import io
import json
import math
from pathlib import Path
import tarfile

results = Path(__file__).resolve().parent/'results'
def load(name):
    return json.loads((results/(name+'.json')).read_text())

def table(key):
    entry=load(key)
    assert entry['Points']==100000 and entry.get('FailedPoints',entry.get('Failures')) is not None
    return entry

expected_retests=set()
for fam,orders in [('positive',range(2,9)),('minus',range(2,9)),('minus-secondary',range(2,9)),('two',range(6))]:
    for n in orders:
        name=f'{fam}-N{n}';entry=table(name)
        assert entry['Photons']==n
        if fam=='minus-secondary':assert entry['Seed']!=load('minus-N'+str(n))['Seed']
        if fam=='positive':flagged=entry['Failures']
        else:flagged=entry['FailedPoints'] or entry.get('MaximumIndividualComponentWardError',0)>1e-7
        if flagged:expected_retests.add(name)

with tarfile.open(results/'threshold-retests.tar.gz') as tar:
    for name in sorted(expected_retests):
        report=load(name+'-retest')
        primary=table(name)
        wide=report['x86_64'];native=report['arm64'];tol=report['tolerance']
        assert tol==primary['RelativeTolerance']
        assert report['original_points']==100000 and report['largest_native_reproduction_difference']==0
        assert wide.get('bits',wide.get('significand_bits'))==64 and native.get('bits',native.get('significand_bits'))==53
        def rows(suffix):
            with tar.extractfile(name+'-selected'+suffix+'.csv') as raw:
                return list(csv.reader(io.TextIOWrapper(raw)))
        points=rows('')[1:]; ids=[int(row[0]) for row in points]
        assert len(set(ids))==len(ids)==report['selected']
        legs=primary['ExternalParticles']; assert all(len(row)==4*legs+2 for row in points)
        assert all(math.isfinite(float(x)) for row in points for x in row)
        for arch,stats in [('arm64',native),('x86_64',wide)]:
            diagnostic=rows('-'+arch)
            assert ids==[int(row[0]) for row in diagnostic]
            for i,(maximum,count) in enumerate(zip(stats['maxima'],stats['counts']),1):
                values=[float(row[i]) for row in diagnostic]
                assert all(math.isfinite(x) and x>=0 for x in values)
                assert max(values,default=0)==maximum
                assert sum(x>tol for x in values)==count
        if name.startswith('two-'):
            assert report['selected']>=primary['FailedPoints']
        else:
            assert report['selected']==primary.get('FailedPoints',primary.get('Failures'))
        if name.startswith('minus'):
            assert native['counts']==[v['Failures'] for v in primary['Checks'].values()]
        if name.startswith('two-'):
            assert native['counts'][:4]==[v['Failures'] for v in primary['Checks'].values()]
        if name.startswith('minus') and any(wide['counts']):
            mp=load(name+'-multiprecision')
            flagged={int(row[0]) for row in rows('-x86_64') if any(float(v)>tol for v in row[1:])}
            assert set(map(int,mp['results']))==flagged and len(flagged)==mp['selected']
            for report in mp['results'].values():
                for digits in ('45','70'):
                    unchanged=report[digits]['unchanged']
                    assert all(unchanged[k]<=tol for k in ('relative_madgraph','reference','positive_permutation','negative_relocation','ward'))

for n in range(2,7):
    s=load('literature-four-settings-N'+str(n))
    assert s['Samples']==400000 and s['ComplexSpinComparisons']==1600000 and s['Failures']==0
    assert len(s['Masses'])==len(s['Charges'])==4
controls=load('literature-negative-controls')
assert controls['points_total']==2000000 and controls['relative_tolerance']==1e-7
assert [family['photons'] for family in controls['families']]==list(range(2,7))
for family in controls['families']:
    n=family['photons']; primary=load('literature-four-settings-N'+str(n))
    assert family['seed']==primary['Seed'] and family['significand_bits']==primary['MantissaBits']
    assert len(family['settings'])==len(primary['Masses'])==4
    for i,setting in enumerate(family['settings']):
        assert setting['points']==100000
        assert setting['mass']==primary['Masses'][i] and math.isclose(setting['charge'],primary['Charges'][i],rel_tol=2e-16)
        for name in ('one_ordering','omitted_coupling_factor'):
            c=setting[name]
            assert c['rejected_at_1e-7']==setting['points']-len(c['points_within_1e-7'])
            assert c['rejected_at_1e-7']==100000 and c['minimum_relative_difference']>1e-7
            assert 0<=c['above_1e-4']<=c['rejected_at_1e-7']
            assert c['maximum_relative_difference']>=c['minimum_relative_difference']
        coupling=setting['omitted_coupling_factor']
        expected=1-math.pow(2,-n/2)
        assert all(math.isclose(coupling[key],expected,rel_tol=2e-15) for key in
                   ('minimum_relative_difference','maximum_relative_difference'))
s=load('literature-one-minus');assert s['pass'] and s['points_per_mass_charge_configuration']==100000
assert all(r['points']==600000 and r['complex_spin_components']==2400000 and r['incomplete_permutation_sum_failures']==600000 for r in s['results'])
for family,n,settings in [(2,3,1),(2,4,1),(4,0,2),(4,1,2),(4,2,2)]:
    for mode in ('physical','spurious'):
        rows=[json.loads(r) for r in (results/f'components-{family}f-{n}g-{mode}.jsonl').read_text().splitlines()]
        assert len(rows)==settings and len({(r['mass'],r['charge']) for r in rows})==settings
        assert all(r['points']==100000 and r['failed']==0 and r['max_scaled_complex_error']<=r['relative_tolerance'] for r in rows)
assert load('one-minus-exact')['checks']==32 and load('one-minus-exact')['failures']==0
assert load('two-plus-exact')['checks']==258 and load('two-plus-exact')['failures']==0
assert load('alt-five-point')['status']==load('das-zeng-five-point')['status']=='PASS'
assert load('native-split-control')['points']==100000
assert load('native-split-control')['unequal_individual_values']==0
assert load('positive-negative-control')['Failures']==100000
assert (results/'positive-low-control.log').read_text().count('PASS')==3
sources=load('source-and-reference-sha256')
assert all(f'ref-one-{n}' in sources for n in range(2,9))
assert all(f'ref-two-{n}' in sources for n in range(6))
trace=load('two-N5-point8223-multiprecision')
frozen={p['kinematics']:p for p in trace['x87']}
observed=load('two-N5-projected')['results']['8223']
assert float(frozen['x87_projection']['component_ratio'])==observed['individual_Ward']
assert float(frozen['x87_projection']['max_tensor_ratio'])==observed['tensor_Ward']
for key in ('original','x87_projection'):
    a,b=[trace['digits'][digits][key] for digits in ('45','70')]
    for quantity in ('absolute_divergence','component_current_norm','tensor_current_norm','component_relative_error'):
        left,right=[float(r['original_x87_worst_component'][quantity]) for r in (a,b)]
        assert math.isclose(left,right,rel_tol=1e-12),quantity
    assert float(b['max_component_relative_error'])<1e-7
assert float(trace['digits']['70']['high_precision_projection']['max_component_relative_error'])<1e-55
scalar=results.parent/'scalar-collection'
def scalar_report(name):
    return json.loads((scalar/(name+'.json')).read_text())
focused=scalar_report('focused')
assert len(focused)==2 and all(row['leaf_count']==324 and row['score']==62 and row['exact'] for row in focused)
assert scalar_report('constructor')['failures']==0 and scalar_report('constructor')['assertions']==18
catalog=scalar_report('catalog-audit')
assert len(catalog)==38 and all(not r['changed_from_existing'] and r['exact'] and r['identical_denominator_bases'] for r in catalog)
notebook=scalar_report('notebook')
assert len(notebook)==10 and all(r['same_ordinary_and_new'] and r['default_matches_unbounded'] and r['default_exact'] for r in notebook)
fallbacks=scalar_report('safeguards')
assert all(fallbacks[key] for key in ('time_fallback_exact','memory_fallback_exact','large_input_skipped_optional','large_equals_ordinary','zero_budget_unchanged'))
kernels=scalar_report('regenerated-sources')
assert len(kernels['production_kernels'])==14 and all(r['matched'] for r in kernels['production_kernels'])
assert len(kernels['independent_full_notebook_exports'])==4 and all(r['matches'] for r in kernels['independent_full_notebook_exports'])
print('General QED validation evidence verified.')
