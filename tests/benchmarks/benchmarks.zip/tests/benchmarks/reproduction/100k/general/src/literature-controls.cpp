// Deliberately corrupt Ochirov's complete Abelian sum on its published validation samples.
#include "literature-all-positive.hpp"
#include "spinas-validation.hpp"
#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <vector>

namespace {
constexpr int sample_size = 400000;
const std::array<ldouble, 4> masses = {{0.1L, 1, 1.5L, 3}};
const std::array<ldouble, 4> charges = {{ldouble(1)/3, ldouble(2)/7, -0.25L, 0.7L}};

struct Errors {
  ldouble minimum = std::numeric_limits<ldouble>::infinity();
  ldouble maximum = 0;
  std::vector<int> within_tolerance;
  unsigned within_stricter_separation = 0;
  void add(cdouble complete, cdouble altered, int point) {
    const ldouble denominator = std::max(std::abs(complete), std::abs(altered));
    if (!(denominator > 0)) throw std::runtime_error("Undefined relative error.");
    const ldouble relative = std::abs(complete-altered)/denominator;
    if (!std::isfinite(relative)) throw std::runtime_error("Nonfinite relative error.");
    minimum = std::min(minimum, relative);
    maximum = std::max(maximum, relative);
    if (relative <= 1e-7L) within_tolerance.push_back(point);
    if (relative <= 1e-4L) ++within_stricter_separation;
  }
  void print() const {
    std::cout << "{\"min\":" << minimum << ",\"max\":" << maximum
              << ",\"within_1e-4\":" << within_stricter_separation << ",\"within_1e-7_points\":[";
    for (std::size_t k=0; k<within_tolerance.size(); ++k)
      std::cout << (k ? "," : "") << within_tolerance[k];
    std::cout << "]}";
  }
};

template<std::size_t N>
void run(int begin, int end) {
  std::mt19937_64 rng(180206730 + N);
  std::array<Errors,4> order_error, coupling_error;
  std::array<int,4> counts = {};
  std::array<ldouble,N+2> particle_masses = {};
  const ldouble omitted_factor = std::pow(std::sqrt(ldouble(2)), int(N));
  for (int i=0; i<end; ++i) {
    const int setting = i % 4;
    const ldouble m = masses[setting], e = charges[setting];
    particle_masses[0] = particle_masses[1] = m;
    hepcat_spinas::ValidationOptions options;
    options.minimum_center_of_mass_energy = 8*m;
    options.maximum_center_of_mass_energy = 80*m;
    auto p = hepcat_spinas::make_random_validation_momenta(particle_masses, {{0,1}}, rng, options);
    if (i < begin) continue;
    hepcat_literature_all_positive::Ochirov35<N> published(p, m, e);
    const cdouble complete = published.coefficient();
    order_error[setting].add(complete, published.first_ordering_coefficient(), i+1);
    coupling_error[setting].add(complete, complete/omitted_factor, i+1);
    ++counts[setting];
  }
  std::cout << std::setprecision(20) << "{\"photons\":" << N << ",\"seed\":" << 180206730+N
            << ",\"begin\":" << begin << ",\"end\":" << end
            << ",\"significand_bits\":" << std::numeric_limits<ldouble>::digits << ",\"settings\":[";
  for (int k=0; k<4; ++k) {
    std::cout << (k ? "," : "") << "{\"mass\":" << masses[k] << ",\"charge\":" << charges[k]
              << ",\"points\":" << counts[k] << ",\"one_ordering\":";
    order_error[k].print();
    std::cout << ",\"omitted_coupling_factor\":";
    coupling_error[k].print();
    std::cout << "}";
  }
  std::cout << "]}\n";
}
}
int main(int argc, char** argv) {
  if (argc != 4) return 1;
  const int n = std::stoi(argv[1]), begin = std::stoi(argv[2]), end = std::stoi(argv[3]);
  if (begin<0 || end>sample_size || end-begin<4) return 1;
  switch(n) {
    case 2: run<2>(begin,end); break;
    case 3: run<3>(begin,end); break;
    case 4: run<4>(begin,end); break;
    case 5: run<5>(begin,end); break;
    case 6: run<6>(begin,end); break;
    default: return 1;
  }
}
