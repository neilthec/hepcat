(* Das and Zeng, Eq. (4.9), first line at spin 1/2. Labels are
   (1,2,3,4,5)DZ -> (1,i,5,j,2), and the two orders exchange i,j.
   Both expressions are divided by the common 2 Sqrt[2] e^3.
   x=<5|1|i], y=<5|2|j], c=[i|1(i+5)|j], t=<12>, u=<15><25>.
   aa=<5i>, bb=<5j>, si=[i5], sj=[5j], h=[ij].
   d12=tau1i, d54=tau2j, d13=tau15, d53=tau25.
   The published s15 maps to s345 by external momentum conservation. *)
ClearAll["Global`*"];
coefficient=1+d12/d13+d54/d53;
(* Their <23> maps to <i5>=-aa and <3|-5|4] maps to -y.
   Their spinor/coupling phase is M = -e^3 A_DZ/i. *)
publishedOrdered=coefficient*(-x^2*y^2/(d12*d54*(-aa)*bb*c)
   *(t/m+c*u/(m*x*(-y)))+m^2*h^4/(s345*si*sj*c)*(t/m));
ourOrdered=coefficient/m*(x*y/(d12*d54*aa*bb)*(u-t*x*y/c)
   -m^2*t*h^4/(s345*si*sj*c));
residual=Cancel[Together[ourOrdered+publishedOrdered]];
phaseControl=Numerator[Together[ourOrdered-publishedOrdered]];
passed=TrueQ[residual===0 && phaseControl=!=0];
Print[ExportString[<|"status"->If[passed,"PASS","FAIL"],
  "spin"->"1/2","ordered_difference"->ToString[residual,InputForm],
  "wrong_phase_nonzero"->TrueQ[phaseControl=!=0],
  "both_photon_orders"->"The equality holds for independent ordered spinor atoms, and therefore holds after exchanging i,j and adding both orders.",
  "kinematics"->"Symbolic rational identity with s15_DZ=s345 from momentum conservation",
  "kinematic_sample_count"->0|>,"RawJSON"]];
Exit[If[passed,0,1]];
