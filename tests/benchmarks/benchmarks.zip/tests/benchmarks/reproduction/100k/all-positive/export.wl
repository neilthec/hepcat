(* Export the two all-positive formulas directly from the publication notebook. *)
root = ExpandFileName[Replace[Environment["HEPCAT_ROOT"], Except[_String] :> Directory[]]];
target = Environment["HEPCAT_VALIDATION_OUTPUT_DIRECTORY"];
If[!StringQ[target] || target === "", Print["Set HEPCAT_VALIDATION_OUTPUT_DIRECTORY."]; Quit[2]];
target = ExpandFileName[target];
Get[FileNameJoin[{root,"source","HEPCAT.wl"}]];
heldNotebook = ToExpression[
  Import[FileNameJoin[{root,"tests","QED-6-point-construction.nb"}],"Text"],
  InputForm, HoldComplete];
definitions = Cases[heldNotebook, Cell[s_String,"Input",___] /;
   (StringContainsQ[s,"qedAllPositivePhysicalFormula[model_List"] ||
    StringContainsQ[s,"qedAllPositiveSpuriousFormula[model_List"]) :> s, Infinity];
If[Length[definitions] != 2, Print["Expected two formula definitions."]; Quit[2]];
Scan[ToExpression, definitions];
model = ReadModel[FileNameJoin[{root,"models"}],2];
If[!DirectoryQ[target], CreateDirectory[target, CreateIntermediateDirectories -> True]];
Do[
  directory = FileNameJoin[{target,form <> "-" <> ToString[n]}];
  If[FileExistsQ[directory], Print["Output already exists: ",directory]; Quit[2]];
  particles = Join[{"e","E"},ConstantArray["A.+",n]];
  expression = If[form === "physical",qedAllPositivePhysicalFormula[model,n],
    qedAllPositiveSpuriousFormula[model,n]][[2]];
  export = Block[{ConstructiveDiagrams`Private`$spinasValidationArithmeticLeafLimit=250000},
    WriteSPINASProcess[directory,particles,expression,model,
      "SPINASDirectory" -> Environment["SPINAS_ROOT"],
      "MadGraphDirectory" -> Environment["MADGRAPH_ROOT"],
      "MadGraphModel" -> "sm-full", "MadGraphAllowedParticles" -> {11,22},
      "Build" -> False, "RunExamples" -> False, "ReturnDetails" -> True]];
  If[!AssociationQ[export] || !FileExistsQ[FileNameJoin[{directory,"process.cpp"}]],
    Print["Export failed for ",n," photons (",form,")."]; Quit[3]],
  {n,3,8}, {form,{"physical","spurious"}}];
