# All-positive formulas at the QED model parameters

These comparisons evaluate the expressions in the QED notebook at electron mass 0.0005 GeV and charge 0.31333. The center-of-mass energy is uniform in its logarithm between 1.5 and 6 GeV. All photons have positive helicity. Both programs sum the four fermion spin assignments and divide by four to average the incoming spins. The tolerance on the symmetric relative difference from MadGraph is 1e-7.

Set `HEPCAT_ROOT`, `SPINAS_ROOT`, `MADGRAPH_ROOT` and `HEPCAT_VALIDATION_OUTPUT_DIRECTORY` to absolute paths. The output directory must have room for the generated processes and independent MadGraph references. The following commands export the physical and spurious formulas directly from the notebook and evaluate them with the publication seeds. Use a Python environment with MadGraph's required dependencies.

```sh
wolframscript -file tests/benchmarks/reproduction/100k/all-positive/export.wl
python3 tests/benchmarks/reproduction/100k/all-positive/compare.py "$HEPCAT_VALIDATION_OUTPUT_DIRECTORY"
```

For three through seven photons the two pole forms use the same momenta at each multiplicity. The seven-photon sample contains one million points per form. The eight-photon samples each contain 100,000 points and use the two seeds of the original numerical conditioning study. The records of that earlier evaluation order are retained separately so that its original precision failures can be reproduced.
