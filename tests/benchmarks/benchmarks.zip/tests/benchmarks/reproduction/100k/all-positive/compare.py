"""Run independent MadGraph validations on the all-positive QED notebook exports."""
import argparse
import json
import os
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("exports", type=Path)
    args = parser.parse_args()
    reports = []
    for n in range(3, 9):
        for form in ("physical", "spurious"):
            directory = args.exports.resolve() / f"{form}-{n}"
            build = directory / "build"
            target = "hepcat_process_validate_madgraph"
            seed = 26111900 + n
            if n == 8:
                seed = 1794447136623380000 if form == "physical" else 1794448410592767000
            count = 1_000_000 if n == 7 else 100_000
            subprocess.run(["cmake", "-S", str(directory), "-B", str(build),
                            "-DCMAKE_BUILD_TYPE=Release", "-DSPINAS_ROOT=" + os.environ["SPINAS_ROOT"]],
                           check=True)
            subprocess.run(["cmake", "--build", str(build), "--target", target], check=True)
            report = directory / "validation.json"
            completed = subprocess.run([str(build / target), "--points", str(count), "--seed", str(seed),
                                        "--min-energy", "1.5", "--max-energy", "6", "--report", str(report)],
                                       cwd=directory)
            if completed.returncode not in (0, 1):
                raise RuntimeError(f"{directory.name}: validator exited with {completed.returncode}")
            rows = json.loads(report.read_text())["Rows"]
            if len(rows) != 1 or rows[0]["ComparedPoints"] != count or rows[0]["EvaluationErrors"]:
                raise RuntimeError(f"{directory.name}: incomplete evaluation")
            row = rows[0]
            reports.append({"photons": n, "pole_form": form, "seed": seed, "points": count,
                            "mismatches": row["Mismatches"],
                            "maximum_relative_difference": row["MaximumRelativeError"]})
            (args.exports / "summary.json").write_text(json.dumps(reports, indent=2) + "\n")


if __name__ == "__main__":
    main()
