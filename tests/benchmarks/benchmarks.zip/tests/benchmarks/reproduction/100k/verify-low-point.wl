(* Check the signed three-point vertices with independent reference spinors
   and evaluate the paper's five-point polynomial proof from the QED notebook. *)
qedVerificationRoot = Nest[DirectoryName, ExpandFileName[$InputFileName], 5];
Get[FileNameJoin[{qedVerificationRoot,"source","HEPCAT.wl"}]];
$HistoryLength = 0;
paperModels = <|2 -> ReadModel[FileNameJoin[{qedVerificationRoot,"models"}],2]|>;
paperFeynman = ReadModel[FileNameJoin[{qedVerificationRoot,"tests","reference-models","calchep"}],2];
photon={{0,t},{0,0}};
positron={{z,y},{0,mass^2/z}};
momenta=<|1->-positron-photon,2->positron,3->photon|>;
angle=<|1->{u1,u2},2->{v1,v2},3->{1,0}|>;
square=Association[Table[j->{{0,1},{-1,0}}.ConstructiveDiagrams`Private`residueAdjugate[momenta[j]].angle[j]/mass,{j,{1,2}}]];
AssociateTo[square,3->{0,t}];
geometry=<|"Momenta"->momenta,"Angle"->angle,"Square"->square,"PoleVariable"->auditPole,"ReferenceOverrides"-><|"Angle"-><|3->{r1,r2},10->{x1,x2}|>,"Square"-><|3->{r3,r4},10->{x3,x4}|>|>|>;
rows=Table[pr={"e","E",hel};
 cand=DiagramAmplitudes[CreateDiagrams[pr,paperModels[2]]][[1,2]];
 fe=FeynmanToSpinorProducts[DiagramAmplitudes[CreateDiagrams[pr,paperFeynman]],"ReduceSpinorProducts"->False][[1,2]];
 bind={ModelParameter["Me",___]->mass,ModelParameter["EE",___]->charge};
 cv=Factor[ConstructiveDiagrams`Private`residueEvaluateChart[cand/.bind,geometry,{}]];
 fv=Factor[ConstructiveDiagrams`Private`residueEvaluateChart[fe/.bind,geometry,{}]];
 Print[hel," ",InputForm[{cv,fv,Cancel[cv-fv]}]];
 <|"Process"->pr,"Nonzero"->(cv=!=0),"ReferenceIndependent"->FreeQ[{cv,fv},r1|r2|r3|r4|x1|x2|x3|x4],"SignedEquality"->(Cancel[cv-fv]===0)|>,{hel,{"A.+","A.-"}}];

If[!AllTrue[rows, TrueQ[#["Nonzero"] && #["ReferenceIndependent"] && #["SignedEquality"]] &], Quit[1]];
qedHeld = ToExpression[Import[FileNameJoin[{qedVerificationRoot,"tests","QED-6-point-construction.nb"}],"Text"], InputForm, HoldComplete];
qedCells = Cases[qedHeld, Cell[code_String, "Input", CellTags -> "QEDFivePointDisplayedPoleIdentity", ___] :> code, Infinity];
If[Length[qedCells] =!= 1 || !TrueQ[ToExpression[First[qedCells]]], Print["Five-point polynomial identity failed."]; Quit[2]];
Print["Both three-point vertices and the five-point polynomial identity passed."]; Quit[0];
