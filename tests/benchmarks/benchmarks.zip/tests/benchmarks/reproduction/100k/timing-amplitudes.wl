(* The expressions carry the spin labels and leg ordering of the QED notebook. *)
loadTimingAmplitudes[file_] := Module[{records = Import[file, "WXF"]},
  If[!ListQ[records] || Length[records] =!= 38 ||
      !DuplicateFreeQ[({#["form"], #["particles"]} & /@ records)],
    Print["Incomplete or ambiguous paper amplitude catalog: ", file]; Quit[1]];
  Association[( {#["form"], #["particles"]} -> #["expression"] ) & /@ records]];

paperTimingExpression[records_, representation_, particles_, model_] := Module[{key, expression},
  key = {Switch[representation, "AllPhysical", "physical", "AllSpurious", "spurious"], particles};
  expression = records[key];
  If[!FreeQ[expression, _Missing | _Failure | $Failed] || FreeQ[expression, _SpinorChain],
    Print["Missing paper amplitude for ", representation, " ", particles]; Quit[1]];
  expression /. parameter_ModelParameter :> ModelParameter[model, ModelParameterName[parameter]]];
