# QED validation at 100,000 points and above

The [study index](summary.json) lists the statistical samples used in the current QED paper. Each sample contains at least 100,000 phase-space points. The index identifies shared momenta. For example, the two pole forms, all photon helicities and both spin bases in a catalog family are evaluated at the same 100,000 points. Targeted precision retests follow selected events from their parent samples. Exact symbolic and rational-kinematics tests are reported separately.

| Calculation | Records and reproduction commands |
|---|---|
| All seven catalog processes, both pole forms, signed Feynman amplitudes, CalcHEP and MadGraph | [Catalog](catalog/README.md) |
| Equal-helicity notebook formulas at the QED model parameters, including one million points per form at seven photons | [All-positive notebook exports](all-positive/README.md) |
| General helicity formulas against MadGraph, spinor identities, published one-pair formulas and the fixed-helicity split-code control | [General formulas](general/README.md) |
| Published four-fermion amplitudes at zero and one photon, keeping all 16 complex spin components | [Four-fermion literature comparison](../../four-fermion-literature/README.md) |
| Numerical conditioning at three precisions and complete spin and helicity sum timings | [Precision and timing](precision-timing/README.md) |

For the independent three-point Feynman checks and the exact polynomial identity between the two printed five-point equal-helicity forms, run `wolframscript -file tests/benchmarks/reproduction/100k/verify-low-point.wl` from the checkout. The catalog directory provides exact signed checks for all 38 expressions and the exact sums of 120 and 720 Feynman diagrams at five and six photons. The general-formula directory gives the symbolic recurrence and literature checks. The [regression summary](regressions.json) records the software and exact-identity checks and the hashes of the regenerated timing kernels.

The rates retain their native discrepancies. The retest records separately identify results obtained by increasing the arithmetic precision at the original momenta and those obtained after restoring the external mass shells and momentum conservation. At adjusted momenta a comparison between the two pole forms uses both formulas evaluated at those momenta.

To verify the distributed files and the notebook's study index, run `python3 tests/benchmarks/reproduction/100k/verify-release.py`. The individual directories give the commands for recalculating the amplitudes with the physics packages.
