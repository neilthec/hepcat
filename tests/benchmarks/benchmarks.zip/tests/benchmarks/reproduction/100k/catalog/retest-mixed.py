"""Reevaluate all sixteen four-photon helicities on the original native binary64 inputs."""
import argparse
import csv
import os
from pathlib import Path
import subprocess
import sys
from replay import PACKAGE,write_sources


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True,help="Output directory used by replay.py.")
    parser.add_argument("--double",type=Path,required=True,help="53-bit x86 SPINAS prefix with include/ and libspinas.a.")
    parser.add_argument("--extended",type=Path,required=True,help="64-bit-significand x86 SPINAS prefix.")
    args=parser.parse_args()
    work=args.output.resolve()
    spur=work/"spurious/eeAAAA"
    captured=[spur/s for s in ("binary64-momenta.dat","binary64-reference.dat","native-failures.csv")]
    if not all(p.is_file() for p in captured):
        raise SystemExit("Run replay.py --capture-four-photon --families eeAAAA --forms spurious --checks madgraph first.")
    d=work/"precision-control"
    d.mkdir(exist_ok=True)
    # A separate build directory preserves the native captured inputs for each retest.
    stub={name:"unused" for name in ("@MODELDIR@","@MGDIR@","@MGHELPER@","@PYTHON@")}
    p=write_sources(d,"eeAAAA","physical",stub)
    s=write_sources(d,"eeAAAA","spurious",stub)
    lines=(p/"process.hpp").read_text().splitlines()
    (d/"physical.hpp").write_text("\n".join(line for line in lines if not line.startswith("#include")).replace("eeAAAA","physical_eeAAAA")+"\n")
    for label,prefix in (("double",args.double),("extended",args.extended)):
        prefix=prefix.resolve()
        cxx=os.environ.get("CXX","clang++")
        flags=[cxx,"-std=c++17","-O2","-ffp-contract=off","-I"+str(prefix/"include")]
        if sys.platform=="darwin":flags.extend(["-arch","x86_64"])
        exe=d/label
        subprocess.run(flags+["-I"+str(s),str(PACKAGE/"mixed-precision.cpp"),str(s/"process.cpp"),
                              str(prefix/"libspinas.a"),"-o",str(exe)],check=True)
        with (d/(label+".csv")).open("w") as out:
            subprocess.run([exe,*captured],stdout=out,check=True)
        if label=="extended":
            subprocess.run(flags+["-DeeAAAA=physical_eeAAAA","-c",str(p/"process.cpp"),"-o",str(d/"physical.o")],check=True)
            exe=d/"project"
            subprocess.run(flags+["-I"+str(s),"-I"+str(d),str(PACKAGE/"projection.cpp"),str(s/"process.cpp"),
                                  str(d/"physical.o"),str(prefix/"libspinas.a"),"-o",str(exe)],check=True)
            with (d/"projected.csv").open("w") as out:
                subprocess.run([exe,*captured],stdout=out,check=True)


if __name__=="__main__":
    main()
