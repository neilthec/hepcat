"""Cache repeated ordered subexpressions of the generated four-photon Feynman sum."""
import ast
import re
import sys
from pathlib import Path


def share(f,d):
    txt=(f/'process.cpp').read_text()
    lo=txt.index('cdouble fdeeAAAA::amp_unchecked(')
    hi=txt.index('\n}',lo)+2
    orig=txt[lo:hi]
    branches=re.findall(r'case (\d+)ULL: \{\s*return (.*?);\s*\}',orig,re.S)
    assert len(branches)==16
    leaves={};nodes={}; pool=[];statements=[];roots=[]
    def atom(txt):
        if txt not in leaves:leaves[txt]=len(leaves)
        return ('leaf',leaves[txt])
    def subtree(node,spins):
        if isinstance(node,ast.BinOp):
            kind={ast.Mult:0,ast.Add:1,ast.Sub:2,ast.Div:3}[type(node.op)]
            a=subtree(node.left,spins);b=subtree(node.right,spins)
            key=(kind,a,b)
        elif isinstance(node,ast.UnaryOp):
            assert isinstance(node.op,ast.USub)
            a=subtree(node.operand,spins);key=(4,a,a)
        elif isinstance(node,ast.Call) or isinstance(node,ast.Name) or isinstance(node,ast.Constant):
            txt=ast.unparse(node)
            for i,v in enumerate(spins):txt=txt.replace('ds'+str(i+1),str(v))
            return atom(txt)
        else:raise ValueError(ast.dump(node))
        if key not in nodes:
            index=len(nodes);nodes[key]=index;pool.append(key)
        return ('node',nodes[key])
    for h,expression in branches:
        tree=ast.parse(' '.join(expression.split()),mode='eval').body
        for a,b in [(1,1),(1,-1),(-1,1),(-1,-1)]:
            roots.append((int(h),a,b,subtree(tree,(a,b))))
    L=len(leaves)
    def ix(n):return n[1]+(L if n[0]=='node' else 0)
    code='struct Triple { unsigned op,a,b; };\nstatic constexpr Triple graph[]={\n'
    code+=''.join('{'+str(k)+','+str(ix(a))+','+str(ix(b))+'},\n' for k,a,b in pool)+'};\n'
    code+='cdouble fdeeAAAA::amp_unchecked(const int& ds1,const int& ds2,const int& ds3,const int& ds4,const int& ds5,const int& ds6){\n'
    code+='if(!fd_graph_ready){\n'
    code+=''.join(f'fd_values[{j}]={v};\n' for v,j in leaves.items())
    code+=f'unsigned offset={L};\n'
    code+='for (auto q : graph) { auto a=fd_values[q.a], b=fd_values[q.b]; cdouble v; switch(q.op){case 0:v=a*b;break; case 1:v=a+b;break;case 2:v=a-b;break;case 3:v=a/b;break;default:v=-a;break;} fd_values[offset++]=v; }\n'
    code+='fd_graph_ready=true;\n}\n'
    code+='static constexpr unsigned root[16][4]={\n'
    for h in range(16): code+='{'+','.join(str(ix(n)) for hh,a,b,n in roots if hh==h)+'},\n'
    code+='};\nunsigned h=(ds3>0)|((ds4>0)<<1)|((ds5>0)<<2)|((ds6>0)<<3);return fd_values[root[h][(ds1<0)*2+(ds2<0)]];\n}'
    txt=txt[:lo]+code+txt[hi:]
    # Reuse the generated cache invalidation and clear the new cache on all kinematic or parameter updates.
    cnt=txt.count('momenta_ready = false;')
    assert cnt>=1
    txt=txt.replace('momenta_ready = false;','fd_graph_ready = false; momenta_ready = false;')
    (d/'process.cpp').write_text(txt)
    hdr=(f/'process.hpp').read_text().replace('  bool momenta_ready = false;',f'  bool fd_graph_ready=false; std::array<cdouble,{L+len(nodes)}> fd_values;\n  bool momenta_ready = false;')
    (d/'process.hpp').write_text(hdr)
    print('leaves',len(leaves),'distinct ordered operations',len(nodes),'bytes for cached complex values',(L+len(nodes))*16,'invalidation sites',cnt,flush=True)


if __name__=="__main__":
    share(Path(sys.argv[1]), Path(sys.argv[2]))
