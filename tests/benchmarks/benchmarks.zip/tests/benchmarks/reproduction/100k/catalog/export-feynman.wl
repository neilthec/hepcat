(* Build numerical signed helicity amplitudes from independent Feynman rules. *)
root=ExpandFileName[Environment["HEPCAT_ROOT"]];Get[root<>"/source/HEPCAT.wl"];
d=ExpandFileName[Environment["HEPCAT_CATALOG_OUTPUT"]];fm=ReadModel[root<>"/tests/reference-models/calchep",2];mdl=ReadModel[root<>"/models",3];
catalog=Import[root<>"/drafts/QED-paper/catalog-expressions.json","RawJSON"];
name[pr_]:=Switch[Count[pr,"e"|"E"],2,"ee",4,"eeee",6,"eeeeee"]<>StringRepeat["A",Count[pr,"A.+"|"A.-"]];
physical[pr_]:=Take[pr,2]->(Drop[pr,2]/.{"e"->"E","E"->"e","A.+"|"A.-"->"A"});
(* With a single photon i, use the angle reference p1 |i] or its square partner.
   Antisymmetry of a bracket and equal values of reversed one-momentum chains
   give the minus sign for a reference at a left endpoint. *)
project[args_List]:=Module[{left=First[args],right=Last[args],middle=Rest[Most[args]],sgn=1},
 If[MatchQ[left,Spinor["Xi",_,_Integer]],left=Sequence[Spinor["Helicity",If[left[[2]]==="Angle","Square","Angle"],left[[3]]],Mom[1]];sgn=-1];
 If[MatchQ[right,Spinor["Xi",_,_Integer]],right=Sequence[Mom[1],Spinor["Helicity",If[right[[2]]==="Angle","Square","Angle"],right[[3]]]]];
 sgn Apply[SpinorChain,Join[{left},middle,{right}]]];
Do[
 family=Select[catalog,#["model"]===3 && name[#["particles"]]===familyName&];
 ent=Table[legs=r["particles"];photons=Flatten[Position[legs,"A.+"|"A.-"]];
 ds=DiagramAmplitudes[CreateDiagrams[legs,fm]];
 ref=If[Length[photons]>=2,AssociationThread[photons,RotateLeft[photons]],Automatic];
 converted=FeynmanToSpinorProducts[ds,"ReduceSpinorProducts"->False,"ReferenceSpinors"->ref,"TimeConstraint"->120];
 If[!ListQ[converted]||Length[converted]=!=Length[ds],Print["conversion failed ",familyName,legs,Short[converted]];Quit[2]];
 expr=Total[Last/@converted] /. param_ModelParameter:>ModelParameter[mdl,ModelParameterName[param]];
 If[Length[photons]==1,expr=expr/.chain_SpinorChain:>project[List@@chain]];
 If[!FreeQ[expr,_Failure|Spinor["Xi",___]|_LorentzMomentum|_DiracChain|_PolarizationVector|_Mass],Print["unsupported spin algebra ",legs," ",Short[expr]];Quit[3]];
 Print["Converted ",legs," ",LeafCount[expr]," leaves ",Length[ds]," diagrams"];
 {legs,expr},{r,family}];
 output=d<>"/feynman/"<>familyName;
 res=WriteSPINASProcess[output,physical[First[ent][[1]]],ent,mdl,
 "ProcessName"->("fd"<>familyName),"SPINASDirectory"->ExpandFileName[Environment["SPINAS_ROOT"]],
 "Precision"->"LongDouble","Build"->False,"Overwrite"->True];
 If[FailureQ[res]||res===$Failed,Print["Failed write ",Short[res,4]];Quit[4]];
 Print["Ready ",familyName];
 ,{familyName,{"eeAA","eeee","eeeeA","eeAAA","eeeeAA","eeeeee","eeAAAA"}}];
Quit[];
