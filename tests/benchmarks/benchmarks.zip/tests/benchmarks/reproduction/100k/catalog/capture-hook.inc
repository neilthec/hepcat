
      static std::size_t records_written = 0;
      static std::ofstream coords("binary64-momenta.dat", std::ios::binary);
      static std::ofstream weights("binary64-reference.dat", std::ios::binary);
      static std::ofstream failures("native-failures.csv");
      if (records_written==0) failures<<"helicity_index,point_one_based,relative_error\n";
      if (records_written<options.points) {
        for (const auto& four : point) for (const auto value : four) {
          const double coordinate = static_cast<double>(value);
          coords.write(reinterpret_cast<const char*>(&coordinate),sizeof(coordinate));
        }
      }
      const double w=reference_squared;
      weights.write(reinterpret_cast<const char*>(&w),sizeof(w));
      if (relative_error > options.relative_tolerance)
        failures<<records_written/options.points<<","<<point_index+1<<","<<relative_error<<"\n";
      ++records_written;
