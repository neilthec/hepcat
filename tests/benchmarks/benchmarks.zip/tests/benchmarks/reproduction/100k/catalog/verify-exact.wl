(* Reproduce the fixed exact-arithmetic regression configurations recorded in
   exact-controls.json. replay.py runs the 100,000-point numerical checks. *)
pkg=DirectoryName[ExpandFileName[$InputFileName]];
hepcatRoot=ExpandFileName[Environment["HEPCAT_ROOT"]];
Get[FileNameJoin[{hepcatRoot,"source","HEPCAT.wl"}]];
$HistoryLength=0;
forms=Import[FileNameJoin[{pkg,"input-expressions.wxf"}],"WXF"];
expected=Import[FileNameJoin[{pkg,"exact-controls.json"}],"RawJSON"];
feynmanModel=ReadModel[FileNameJoin[{hepcatRoot,"tests","reference-models","calchep"}],2];
models=<|"physical"->ReadModel[FileNameJoin[{hepcatRoot,"models"}],3],"spurious"->ReadModel[FileNameJoin[{hepcatRoot,"models"}],4]|>;
Do[
 mdl=models[rec["pole_form"]];legs=rec["particles"];
 matches=Select[forms,#["particles"]===legs && #["form"]===rec["pole_form"]&];If[Length[matches]=!=1,Quit[2]];
 amp=First[matches]["expression"]/.variable_ModelParameter:>ModelParameter[mdl,ModelParameterName[variable]];
 masses=MapIndexed[Mass[First[#2]]->If[MemberQ[{"e","E"},#1],ModelParameter[mdl,"Me"],0]&,legs];
 input=ConstructiveDiagrams`Private`residueSimpleInputs[{masses,amp},FactorizationAmplitudeChannels[legs,mdl],mdl];
 diagrams=DiagramAmplitudes[CreateDiagrams[legs,feynmanModel]];
 compared=ConstructiveDiagrams`Private`amplitudeFeynmanReport[input,diagrams,mdl,rec["completed_points"],rec["seed"],ModelParameterRules[mdl],ModelParameterRules[feynmanModel],480,0];
 Print[rec["pole_form"]," ",legs," ",compared["Status"]];
 If[compared["Status"]=!="PASS" || compared["OverallSign"]=!=1 || compared["CompletedSamples"]=!=rec["completed_points"],Quit[3]],
 {rec,expected}];
