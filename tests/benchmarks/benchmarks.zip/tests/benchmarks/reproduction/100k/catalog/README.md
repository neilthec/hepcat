# QED catalog validation

The catalog contains seven external-particle families through six points and both pole representations. The generated sources include the restored three- and four-photon mixed-helicity formulas, the equal-helicity formulas at each multiplicity, the balanced four-photon amplitude, and the current four- and six-fermion expressions. The six-fermion amplitude has the same expression in both pole representations.

Each family uses 100,000 random physical phase-space points. Both pole forms, both spin bases, all labeled photon helicities and the three reference calculations reuse the same random seed. The energy is sampled uniformly in the logarithm of the center-of-mass energy between 1.5 and 6 GeV. The electron mass is 0.0005 GeV, its charge magnitude is 0.31333, and all widths vanish. Counts summed over helicities and representations include repeated use of the same momenta. Point indices in the signed table start at zero. MadGraph and precision-retest indices start at one.

* CalcHEP compares the complete squared matrix element, including the initial spin average and final-state symmetry factor.
* MadGraph checks the squared matrix element at every labeled photon-helicity assignment, summed over all massive spins with the same normalization. For both squared-rate checks the relative difference is the absolute difference divided by the larger absolute value, with a tolerance of 1e-7.
* The signed comparison constructs the tree diagrams of the conventional QED model in HEPCAT and evaluates their sum as a complex amplitude. Each photon uses the same reference throughout the diagram sum. This comparison enumerates all massive-spin components for each photon-helicity assignment. Feynman and constructive expressions use the same crossing conventions and SPINAS spinors.
* For the signed comparison the tensor error is the largest absolute component difference divided by the largest absolute Feynman component for this photon helicity at this point. The files also report each component relative to its own Feynman value. The latter can be dominated by rounding when an exact component vanishes in the beam-aligned spin basis. A second comparison applies a fixed, unitary two-state transformation to each massive leg in both calculations. The transformations are specified in `signed-rotated.cpp` and are independent of the data.

## Reproduce the comparisons

Use CMake, a C++17 compiler, a long-double build of SPINAS, CalcHEP, MadGraph and a Python interpreter supported by MadGraph. The original native tests ran on Apple ARM, where C++ long double has a 53-bit significand. Set the following environment variables to the corresponding installation directories.

```sh
export HEPCAT_ROOT=/path/to/hepcat
export CALCHEP_ROOT=/path/to/calchep
export MADGRAPH_ROOT=/path/to/madgraph
export SPINAS_ROOT=/path/to/spinas
python3 replay.py --output /path/to/results/catalog
```

The runner checks source hashes before unpacking the generated amplitudes. It builds and runs both signed comparisons, the CalcHEP comparison and the helicity-resolved MadGraph comparison. Every numerical run requests at least 100,000 points. Use `--families`, `--forms` or `--checks` to select a subset. The raw CalcHEP logs, MadGraph reports and signed CSV files appear in the chosen output directory. The runner returns a nonzero status when an external program reports a mismatch, including a reproducible original-precision mismatch.

`results.json` gives each comparison count and maximum for the production run. `generated-sources.zip` contains the exact generated evaluation sources, with installation paths in the external validation adapters filled in by the runner. The SHA-256 values in the archive identify every input file. `export-one-pair.wl` documents how the three- and four-photon expressions were assembled from the paper and the QED notebook. `export-feynman.wl` generates the independent diagram sums with the HEPCAT model in `tests/reference-models/calchep`.

## Four-photon precision retest

To repeat the full-sample precision control, run the native comparison on Apple ARM with `--capture-four-photon --families eeAAAA --forms spurious --checks madgraph`. This saves the native binary64 momenta and every MadGraph fixed-helicity reference. Supply x86 SPINAS prefixes with matching `double` and `long double` types in their headers to the second runner. Each prefix must contain `include/` and `libspinas.a`.

```sh
python3 retest-mixed.py --output /path/to/results/catalog --double /path/to/spinas-double --extended /path/to/spinas-extended
```

The retest preserves the original momenta, parameters, helicities and MadGraph weights and measures the actual significand width. The separate projection control restores the photon mass shells and momentum conservation at extended precision and compares the physical and spurious expressions on those adjusted inputs. The retest reads the size of the captured ensemble and checks the reference count. The published comparison covers 100,000 points and all sixteen photon-helicity assignments.

The unreduced four-photon Feynman sum contains many repeated spinor products and ordered subexpressions. For the signed tests, `share-feynman.py` evaluates each distinct subexpression once per phase-space point. Its input is the literal generated Feynman sum in the archive. The transformation preserves the order of each addition, subtraction, multiplication and division.

For a retest of each native signed tensor outlier, use the same captured momenta.

```sh
python3 retest-signed.py --output /path/to/results/catalog --native /path/to/native-spinas --extended /path/to/spinas-extended
```

The program scans the full native sample for differences between the two pole forms above 6e-8 and compares the resulting candidates directly with the Feynman sum. These candidates contain all 98 native beam-basis and all 90 native rotated-basis tensor outliers. It repeats every flagged signed comparison at extended precision with the original momentum bits and with the adjusted kinematics. The Feynman sum is reevaluated on each set of momenta. `signed-outliers.json` records the three errors for every flagged comparison. `mixed-native-events.json` identifies the 25 distinct momenta involved in the 50 original MadGraph discrepancies and the hashes of the full captured binary64 data streams.

`input-expressions.wxf` contains the 38 HEPCAT expressions underlying the catalog exports. `exact-controls.json` records the fixed exact-arithmetic regression configurations, all with signed ratio +1. To repeat these separate checks, set `HEPCAT_ROOT` and evaluate `verify-exact.wl` using the Wolfram kernel.

All fourteen process sources have been regenerated from the archived symbolic inputs. Their SHA-256 values are recorded in `symbolic-exports.json`. For the two balanced four-photon seeds, `export-one-pair.wl` collects the common factors with an unlimited algebraic time allowance. For the two-pair, two-photon spurious-pole export, a longer allowance for common-subexpression analysis reproduced the measured C++ graph on a busy machine. The archive already contains that graph.

## Five and six equal-helicity photons

The independent exact check in `verify-high-feynman.wl` generates every conventional tree diagram from the Feynman model, converts its numerator to spinor chains and sums all diagrams with the same photon references. At five photons there are 120 diagrams and 30 distinct fermion channels. At six photons there are 720 diagrams and 62 channels. For each multiplicity the calculation checks every channel denominator at each of four rational configurations, then tests both recurrences and all four massive-spin components against the signed diagram sum.

Set `HEPCAT_ROOT` to the publication checkout and `HEPCAT_EXACT_OUTPUT` to a writable results directory. Run `verify-high-feynman.wl` with the Wolfram kernel. The optional variable `HEPCAT_PHOTONS` selects five or six photons using the value `5` or `6`. The JSON reports give the masses, charge, seeds, channel counts and exact differences.

`seven-point-integration.json` records the end-to-end construction of both five-photon pole forms using the unmodified public integration tests. The constructor retains the resolved fermion-line expression if further preparation would increase its spinor complexity. The final physical and spurious expressions reach the previously verified scores of 820 and 1160. At each of two parameter assignments, the former passes 33 checks and the latter 43, including all 30 physical channels.

## One photon and two fermion pairs

The physical-pole constructor also combines the two possible emission positions on a charged line when there is one external photon. For each photon helicity the automatically returned expression has spinor complexity 160 and 879 expression leaves. Its difference from the corresponding catalog formula vanishes identically after putting spinor chains and propagators in canonical order. For a direct check of the matching signs, set `HEPCAT_ROOT` and run `verify-one-emission.wl`. It compares the four diagrams of each fermion matching with the corresponding part of the amplitude at three exact configurations, repeats the comparison in four external orderings and tests rejection of incomplete or altered diagram sets. The outcomes are in `one-emission-integration.json`.
