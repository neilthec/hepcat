(* Independent off-cut regression for the equal-helicity formula.
   HEPCAT_ROOT supplies the publication checkout. Optionally set HEPCAT_PHOTONS
   to 5 or 6 to run a single multiplicity. Output is written to the directory
   specified by HEPCAT_EXACT_OUTPUT. *)
root=ExpandFileName[Environment["HEPCAT_ROOT"]];
exactOutputDirectory=ExpandFileName[Environment["HEPCAT_EXACT_OUTPUT"]];
If[!DirectoryQ[exactOutputDirectory],CreateDirectory[exactOutputDirectory,CreateIntermediateDirectories->True]];
Get[FileNameJoin[{root,"source","HEPCAT.wl"}]];
$HistoryLength=0;
model=ReadModel[FileNameJoin[{root,"models"}],3];
refModel=ReadModel[FileNameJoin[{root,"tests","reference-models","calchep"}],2];
nb=Get[FileNameJoin[{root,"tests","QED-6-point-construction.nb"}]];
cells=Cases[nb,Cell[c_String,"Input",___]:>c,Infinity];
Do[defs=Select[cells,StringContainsQ[#,wanted]&];If[Length[defs]=!=1,Quit[2]];ToExpression[First[defs]],
 {wanted,{"qedAllPositivePhysicalFormula[model_List, n_Integer","qedAllPositiveSpuriousFormula[model_List, n_Integer"}}];
die[text_] := (Print["FAIL ",text];Quit[3]);
choices=Switch[Environment["HEPCAT_PHOTONS"],"5",{5},"6",{6},_,{5,6}];
Do[
  photons=Range[3,n+2];legs=Join[{"e","E"},ConstantArray["A.+",n]];
  mass=ModelParameter[model,"Me"];ext=Thread[(Mass/@Range[n+2])->Join[{mass,mass},ConstantArray[0,n]]];
  channels=ConstructiveDiagrams`Private`residueSimpleChannel[Prepend[#,1],mass,Range[n+2],ext,model]&/@
    Select[Subsets[photons],0<Length[#]<n&];
  refs=Thread[photons->RotateLeft[photons]];
  brackets=Table[SpinorChain[Spinor["Helicity","Angle",i/.refs],Spinor["Helicity","Angle",i]],{i,photons}];
  predictions={Last[qedAllPositivePhysicalFormula[model,n]],Last[qedAllPositiveSpuriousFormula[model,n]]};
  brackets=Join[brackets,DeleteDuplicates@Cases[predictions,Power[chain_SpinorChain,_Integer?Negative]:>chain,Infinity]];
  charts={};
  Do[
    rules=ModelParameterRules[model,{"Me"->mv,"EE"->2/7}];frules=ModelParameterRules[refModel,{"Me"->mv,"EE"->2/7}];
    accepted=False;
    Do[seed=202611058000+n+100*s+retry;
      chart=ConstructiveDiagrams`Private`amplitudeRationalComparisonChart[channels,s+7*retry,seed,rules];
      If[!AssociationQ[chart]||!TrueQ[chart["OffCutKinematicValidation"]["Valid"]],Continue[]];
      zeros=ConstructiveDiagrams`Private`residueEvaluateChart[brackets,chart,rules];
      If[!ListQ[zeros]||!AllTrue[zeros,ConstructiveDiagrams`Private`residueFiniteQ[#]&&!ConstructiveDiagrams`Private`residueExactZero[#]&],Continue[]];
      pvals=ConstructiveDiagrams`Private`residueEvaluateChart[predictions,chart,rules];
      If[Length[pvals]=!=2||!FreeQ[pvals,_Missing|_Failure|$Failed],die["proposal evaluation"]];
      AppendTo[charts,<|"chart"->chart,"rules"->frules,"predictions"->pvals,"seed"->seed,"mass"->mv|>];accepted=True;Break[],
    {retry,0,4}];If[!accepted,die["chart selection"]],{mv,{1,3/2}},{s,1,2}];
  graphs=CreateDiagrams[legs,refModel];If[Length[graphs]=!=Factorial[n],die["diagram inventory"]];
  totals=ConstantArray[0,Length[charts]];done=0;
  Print["Photons ",n," exact charts ",Length[charts]," Feynman diagrams ",Length[graphs]];
  Do[
    raw=DiagramAmplitudes[batch];converted=FeynmanToSpinorProducts[raw,"ReferenceSpinors"->refs,"ReduceSpinorProducts"->False,"TimeConstraint"->Infinity];
    If[!ListQ[converted]||Length[converted]=!=Length[batch]||!FreeQ[converted,_Missing|_Failure|$Failed|$Aborted|$TimedOut|(Spinor|SpinorHat)["Xi",___]|_MomHat|_SpinorHat],die["independent Feynman conversion"]];
    Do[v=ConstructiveDiagrams`Private`residueEvaluateChart[Last/@converted,charts[[j]]["chart"],charts[[j]]["rules"]];
      If[!ListQ[v]||Length[v]=!=Length[batch]||!FreeQ[v,_Missing|_Failure|$Failed],die["independent exact evaluation"]];
      totals[[j]]=Expand[totals[[j]]+Total[v]],{j,Length[charts]}];
    done+=Length[batch];Print["Photons ",n," summed diagrams ",done," of ",Length[graphs]],{batch,Partition[graphs,UpTo[12]]}];
  records=Table[spins=charts[[j]]["chart"]["SpinVariables"];
    coeffs=Table[diff=Expand[charts[[j]]["predictions"][[k]]-totals[[j]]];
      If[!PolynomialQ[diff,spins]||!And@@Thread[Exponent[diff,spins]<=1],die["massive-spin degree"]];
      Flatten[Table[Cancel[Together[Coefficient[Coefficient[diff,spins[[1]],a],spins[[2]],b]]],{a,0,1},{b,0,1}]],{k,2}];
    If[coeffs=!=ConstantArray[0,{2,4}],die["signed coherent-spin agreement"]];
    <|"seed"->charts[[j]]["seed"],"mass"->ToString[charts[[j]]["mass"],InputForm],"charge"->"2/7","physical_cuts_nonzero"->Length[channels],
      "signed_differences_physical"->First[coeffs],"signed_differences_spurious"->Last[coeffs]|>,{j,Length[charts]}];
  exported=Export[FileNameJoin[{exactOutputDirectory,"off-cut-"<>ToString[n]<>".json"}],<|"photons"->n,"independent_feynman_diagrams"->done,"charts"->records|>,"RawJSON"];If[!StringQ[exported]||!FileExistsQ[exported],die["writing evidence"]];
  Print["PASS ",n," photons, both forms, ",Length[charts]," exact charts, all massive-spin components"],{n,choices}];
