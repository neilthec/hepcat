#include "process.hpp"
#include "feynman-sig.hpp"
#include <array>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <vector>
using Candidate = hepcat_generated::CONSTRUCTIVE_PROCESS;
using Feynman = hepcat_generated::FEYNMAN_PROCESS;

int main(int argc, char** argv) {
  std::size_t n = argc > 1 ? std::stoul(argv[1]) : 100000;
  Candidate c;
  Feynman f;
  c.set_widths_enabled(false);
  f.set_widths_enabled(false);
  auto mass = c.masses();
  if (mass != f.masses() || c.incoming_legs() != f.incoming_legs()
      || c.helicity_configurations() != f.helicity_configurations()) return 3;
  hepcat_spinas::ValidationOptions opts;
  opts.points = n;
  opts.seed = 861811;
  std::mt19937_64 engine(opts.seed);
  constexpr auto hcount = Candidate::helicity_count;
  const auto helicities = Candidate::helicity_configurations();
  std::array<std::vector<Candidate::Spins>, hcount> states;
  for (std::size_t h = 0; h < hcount; ++h) {
    states[h] = {helicities[h]};
    for (std::size_t j = 0; j < mass.size(); ++j) {
      if (helicities[h][j] != 0) continue;
      std::vector<Candidate::Spins> both;
      for (auto s : states[h]) {
        s[j] = 1;
        both.push_back(s);
        s[j] = -1;
        both.push_back(s);
      }
      states[h] = std::move(both);
    }
  }
  const double tol = 1e-7;
  std::array<double,hcount> maxrel{},maxscaled{};
  std::array<std::size_t,hcount> relbad{},scaledbad{},nonfinite{},processed{},worst{};
  for (std::size_t ip = 0; ip < n; ++ip) {
    auto point = hepcat_spinas::make_random_validation_momenta(mass,c.incoming_legs(),engine,opts);
    c.set_momenta(point);
    f.set_momenta(point);
    for (std::size_t h = 0; h < hcount; ++h) {
      double largest_reference = 0, largest_difference = 0;
      for (auto s : states[h]) {
        auto a = c.amp(s), b = f.amp(s);
        auto da = std::abs(a - b), ab = std::abs(b);
        if (!std::isfinite(da) || !std::isfinite(ab)) { ++nonfinite[h]; continue; }
        largest_difference = std::max(largest_difference,double(da));
        largest_reference = std::max(largest_reference,double(ab));
        double rel = ab == 0 ? (da == 0 ? 0 : std::numeric_limits<double>::infinity()) : da/ab;
        if (rel > tol) ++relbad[h];
        if (rel > maxrel[h]) maxrel[h] = rel;
        ++processed[h];
      }
      double scaled = largest_reference == 0 ? (largest_difference == 0 ? 0 : std::numeric_limits<double>::infinity()) : largest_difference/largest_reference;
      if (scaled > tol) ++scaledbad[h];
      if (scaled > maxscaled[h]) { maxscaled[h] = scaled; worst[h] = ip; }
    }
  }
  std::cout << "helicity_index,points,spin_components,nonfinite,component_rel_failed,component_max_rel,tensor_rel_failed,tensor_max_rel,worst_tensor_point\n" << std::setprecision(17);
  for (std::size_t h=0; h<hcount; ++h)
    std::cout << h << "," << n << "," << processed[h] << "," << nonfinite[h] << "," << relbad[h] << "," << maxrel[h] << "," << scaledbad[h] << "," << maxscaled[h] << "," << worst[h] << "\n";
}
