#include "process.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <set>
#include <sstream>
#include <vector>
using Process=hepcat_generated::eeAAAA;
#include "physical.hpp"
ldouble spatial_norm2(const std::array<ldouble,4>& p) {
  return std::fma(p[1],p[1],std::fma(p[2],p[2],p[3]*p[3]));
}
Process::Momenta project_true64(const Process::Momenta& original,ldouble mass) {
  auto p=original;std::array<ldouble,4> total={};
  for(std::size_t leg=2;leg<p.size();++leg){p[leg][0]=std::sqrt(spatial_norm2(p[leg]));for(std::size_t u=0;u<4;++u)total[u]+=p[leg][u];}
  const ldouble invariant=total[0]*total[0]-spatial_norm2(total);
  if(!(invariant>0))throw std::runtime_error("Photon total not timelike");
  const ldouble invariant_mass=std::sqrt(invariant);ldouble rest_energy=0;
  for(std::size_t leg=2;leg<p.size();++leg){const auto old=p[leg];ldouble dot=0;for(std::size_t u=1;u<4;++u)dot=std::fma(total[u],old[u],dot);const ldouble shift=dot/(invariant_mass*(total[0]+invariant_mass))-old[0]/invariant_mass;for(std::size_t u=1;u<4;++u)p[leg][u]=old[u]+total[u]*shift;p[leg][0]=std::sqrt(spatial_norm2(p[leg]));rest_energy+=p[leg][0];}
  const ldouble energy=original[0][0]+original[1][0];if(!(energy>2*mass)||!(rest_energy>0))throw std::runtime_error("Bad projected energy");
  const ldouble scale=energy/rest_energy;for(std::size_t leg=2;leg<p.size();++leg)for(std::size_t u=0;u<4;++u)p[leg][u]*=scale;
  const ldouble beam=energy/2,momentum=std::sqrt((beam-mass)*(beam+mass));p[0]={{beam,0,0,momentum}};p[1]={{beam,0,0,-momentum}};return p;
}


int main(int argc,char** argv) {
  if(argc!=4) return 2;
  std::ifstream coords(argv[1],std::ios::binary), weights(argv[2],std::ios::binary), flagged(argv[3]);
  if (!coords || !weights || !flagged) return 3;
  coords.seekg(0,std::ios::end);
  const std::streamoff coordinate_bytes=coords.tellg();
  const std::streamoff point_bytes=Process::Momenta{}.size()*4*sizeof(double);
  if (coordinate_bytes<100000*point_bytes || coordinate_bytes%point_bytes!=0) return 3;
  const std::size_t n=static_cast<std::size_t>(coordinate_bytes/point_bytes), nh=Process::helicity_count;
  coords.seekg(0);
  weights.seekg(0,std::ios::end);
  if (weights.tellg()!=static_cast<std::streamoff>(n*nh*sizeof(double))) return 3;
  weights.seekg(0);
  std::vector<double> references(n*nh);
  if(!weights.read(reinterpret_cast<char*>(references.data()),sizeof(double)*references.size())) return 3;
  std::set<std::pair<int,int>> native_flags;
  std::string line;
  std::getline(flagged,line);
  while(std::getline(flagged,line)) {
    std::replace(line.begin(),line.end(),',',' ');
    std::istringstream s(line);
    int h,i;double e;
    if (!(s>>h>>i>>e) || h<0 || static_cast<std::size_t>(h)>=nh ||
        i<=0 || static_cast<std::size_t>(i)>n || !native_flags.emplace(h,i).second) return 4;
  }
  auto hel=Process::helicity_configurations();
  Process p; hepcat_generated::physical_eeAAAA phys;
  auto par=p.get_parameters();
  for(auto& a:par) a=cdouble(static_cast<double>(a.real()),static_cast<double>(a.imag()));
  p.set_parameters(par);p.set_widths_enabled(false);
  phys.set_parameters(par); phys.set_widths_enabled(false);
  const auto norm=p.symmetry_factor()/p.incoming_spin_average();
  std::array<std::size_t,nh> failed{},flagged_failed{},original_flags{};
  std::array<ldouble,nh> worst{},flagged_worst{};
  std::array<std::size_t,nh> worst_index{};
  for(std::size_t i=0;i<n;++i){
    Process::Momenta point;
    for(auto& four:point)for(auto& value:four){
      double x;if(!coords.read(reinterpret_cast<char*>(&x),sizeof(x)))return 5;
      value=ldouble(x);
    }
    point=project_true64(point,p.masses()[0]);
    p.set_momenta(point); phys.set_momenta(point);
    for(std::size_t h=0;h<nh;++h){
      auto spins=hel[h];
      ldouble val=0,ref=0;
      for(int a : {-1,1})for(int b : {-1,1}){
        spins[0]=a;spins[1]=b;
        val+=std::norm(p.amp(spins));ref+=std::norm(phys.amp(spins));
      }
      val*=norm;
      ref*=norm;
      if(!std::isfinite(val)||!std::isfinite(ref))return 6;
      auto denom=std::max(val,ref);
      auto diff=denom==0 ? 0 : std::abs(val-ref)/denom;
      if(diff>worst[h]) {worst[h]=diff;worst_index[h]=i+1;}
      if(diff>1e-7L)++failed[h];
      if(native_flags.count({int(h),int(i+1)})){
        ++original_flags[h];flagged_worst[h]=std::max(flagged_worst[h],diff);
        if(diff>1e-7L)++flagged_failed[h];
      }
    }
  }
  std::cout<<"significand_bits,helicity_index,points,failures,max_relative,worst_point,native_flagged,still_flagged,native_flagged_max_relative\n";
  std::cout<<std::setprecision(19);
  for(std::size_t h=0;h<nh;++h)
    std::cout<<std::numeric_limits<ldouble>::digits<<","<<h<<","<<n<<","<<failed[h]<<","<<worst[h]<<","<<worst_index[h]<<","<<original_flags[h]<<","<<flagged_failed[h]<<","<<flagged_worst[h]<<"\n";
}
