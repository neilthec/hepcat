#include "process.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <set>
#include <sstream>
#include <vector>
using Process=hepcat_generated::eeAAAA;
int main(int argc,char** argv) {
  if(argc!=4) return 2;
  std::ifstream coords(argv[1],std::ios::binary), weights(argv[2],std::ios::binary), flagged(argv[3]);
  if (!coords || !weights || !flagged) return 3;
  coords.seekg(0,std::ios::end);
  const std::streamoff coordinate_bytes=coords.tellg();
  const std::streamoff point_bytes=Process::Momenta{}.size()*4*sizeof(double);
  if (coordinate_bytes<100000*point_bytes || coordinate_bytes%point_bytes!=0) return 3;
  const std::size_t n=static_cast<std::size_t>(coordinate_bytes/point_bytes), nh=Process::helicity_count;
  coords.seekg(0);
  weights.seekg(0,std::ios::end);
  if (weights.tellg()!=static_cast<std::streamoff>(n*nh*sizeof(double))) return 3;
  weights.seekg(0);
  std::vector<double> references(n*nh);
  if(!weights.read(reinterpret_cast<char*>(references.data()),sizeof(double)*references.size())) return 3;
  std::set<std::pair<int,int>> native_flags;
  std::string line;
  std::getline(flagged,line);
  while(std::getline(flagged,line)) {
    std::replace(line.begin(),line.end(),',',' ');
    std::istringstream s(line);
    int h,i;double e;
    if (!(s>>h>>i>>e) || h<0 || static_cast<std::size_t>(h)>=nh ||
        i<=0 || static_cast<std::size_t>(i)>n || !native_flags.emplace(h,i).second) return 4;
  }
  auto hel=Process::helicity_configurations();
  Process p;
  auto par=p.get_parameters();
  for(auto& a:par) a=cdouble(static_cast<double>(a.real()),static_cast<double>(a.imag()));
  p.set_parameters(par);p.set_widths_enabled(false);
  const auto norm=p.symmetry_factor()/p.incoming_spin_average();
  std::array<std::size_t,nh> failed{},flagged_failed{},original_flags{};
  std::array<ldouble,nh> worst{},flagged_worst{};
  std::array<std::size_t,nh> worst_index{};
  for(std::size_t i=0;i<n;++i){
    Process::Momenta point;
    for(auto& four:point)for(auto& value:four){
      double x;if(!coords.read(reinterpret_cast<char*>(&x),sizeof(x)))return 5;
      value=ldouble(x);
    }
    p.set_momenta(point);
    for(std::size_t h=0;h<nh;++h){
      auto spins=hel[h];
      ldouble val=0;
      for(int a : {-1,1})for(int b : {-1,1}){
        spins[0]=a;spins[1]=b;
        val+=std::norm(p.amp(spins));
      }
      val*=norm;
      auto ref=ldouble(references[h*n+i]);
      if(!std::isfinite(val)||!std::isfinite(ref))return 6;
      auto denom=std::max(val,ref);
      auto diff=denom==0 ? 0 : std::abs(val-ref)/denom;
      if(diff>worst[h]) {worst[h]=diff;worst_index[h]=i+1;}
      if(diff>1e-7L)++failed[h];
      if(native_flags.count({int(h),int(i+1)})){
        ++original_flags[h];flagged_worst[h]=std::max(flagged_worst[h],diff);
        if(diff>1e-7L)++flagged_failed[h];
      }
    }
  }
  std::cout<<"significand_bits,helicity_index,points,failures,max_relative,worst_point,native_flagged,still_flagged,native_flagged_max_relative\n";
  std::cout<<std::setprecision(19);
  for(std::size_t h=0;h<nh;++h)
    std::cout<<std::numeric_limits<ldouble>::digits<<","<<h<<","<<n<<","<<failed[h]<<","<<worst[h]<<","<<worst_index[h]<<","<<original_flags[h]<<","<<flagged_failed[h]<<","<<flagged_worst[h]<<"\n";
}
