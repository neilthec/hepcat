#include <iostream>
#include <set>
#include "process.hpp"
#include "spurious.hpp"
#include "feynman-sig.hpp"
#include <array>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <limits>
#include <random>
#include <string>

using Physical = hepcat_generated::eeAAAA;
using Spurious = hepcat_generated::spur_eeAAAA;
using Feynman = hepcat_generated::fdeeAAAA;
using Tensor = std::array<cdouble,4>;
struct Stats {
  int finite=0,nonfinite=0,fail_component=0,fail_tensor=0,worst_point=0;
  double worst_component=0,worst_tensor=0;
  void add(const Tensor& a,const Tensor& b,int point) {
    double largest=0,difference=0;
    for(int j=0;j<4;++j) {
      double d=std::abs(a[j]-b[j]),r=std::abs(b[j]);
      if(!std::isfinite(r)||!std::isfinite(d)){++nonfinite;continue;}
      ++finite;
      largest=std::max(largest,r);difference=std::max(difference,d);
      double rel=r==0?(d==0?0:std::numeric_limits<double>::infinity()):d/r;
      if(rel>1e-7)++fail_component;
      worst_component=std::max(worst_component,rel);
    }
    double rel=largest==0?(difference==0?0:std::numeric_limits<double>::infinity()):difference/largest;
    if(rel>1e-7)++fail_tensor;
    if(rel>worst_tensor){worst_tensor=rel;worst_point=point;}
  }
};
Tensor rotated(Tensor t){
  for(std::size_t i=0;i<2;++i) {
    const auto c=std::cos(0.31+0.09*i);
    const auto s=std::polar(ldouble(std::sin(0.31+0.09*i)),ldouble(0.42+0.37*i));
    const std::size_t stride=2>>i;
    for(std::size_t block=0;block<4;block+=2*stride)for(std::size_t j=block;j<block+stride;++j) {
      auto x=t[j],y=t[j+stride];
      t[j]=ldouble(c)*x+s*y;
      t[j+stride]=-std::conj(s)*x+ldouble(c)*y;
    }
  }
  return t;
}
#ifdef PROJECTED
ldouble spatial_norm2(const std::array<ldouble,4>& p) {
  return std::fma(p[1],p[1],std::fma(p[2],p[2],p[3]*p[3]));
}
Physical::Momenta project_true64(const Physical::Momenta& original,ldouble mass) {
  auto p=original;std::array<ldouble,4> total={};
  for(std::size_t leg=2;leg<p.size();++leg){p[leg][0]=std::sqrt(spatial_norm2(p[leg]));for(std::size_t u=0;u<4;++u)total[u]+=p[leg][u];}
  const ldouble invariant=total[0]*total[0]-spatial_norm2(total);
  if(!(invariant>0))throw std::runtime_error("Photon total not timelike");
  const ldouble invariant_mass=std::sqrt(invariant);ldouble rest_energy=0;
  for(std::size_t leg=2;leg<p.size();++leg){const auto old=p[leg];ldouble dot=0;for(std::size_t u=1;u<4;++u)dot=std::fma(total[u],old[u],dot);const ldouble shift=dot/(invariant_mass*(total[0]+invariant_mass))-old[0]/invariant_mass;for(std::size_t u=1;u<4;++u)p[leg][u]=old[u]+total[u]*shift;p[leg][0]=std::sqrt(spatial_norm2(p[leg]));rest_energy+=p[leg][0];}
  const ldouble energy=original[0][0]+original[1][0];if(!(energy>2*mass)||!(rest_energy>0))throw std::runtime_error("Bad projected energy");
  const ldouble scale=energy/rest_energy;for(std::size_t leg=2;leg<p.size();++leg)for(std::size_t u=0;u<4;++u)p[leg][u]*=scale;
  const ldouble beam=energy/2,momentum=std::sqrt((beam-mass)*(beam+mass));p[0]={{beam,0,0,momentum}};p[1]={{beam,0,0,-momentum}};return p;
}


#endif
int main(int argc,char** argv){
  if(argc!=5)return 2;
  std::ifstream coords(argv[1],std::ios::binary|std::ios::ate);
  if (!coords) return 3;
  const std::streamoff coordinate_bytes=coords.tellg();
  const std::streamoff point_bytes=Physical::Momenta{}.size()*4*sizeof(double);
  if (coordinate_bytes<100000*point_bytes || coordinate_bytes%point_bytes!=0 ||
      coordinate_bytes/point_bytes>std::numeric_limits<int>::max()) return 3;
  const int n=static_cast<int>(coordinate_bytes/point_bytes);
  coords.seekg(0);
  const bool prefilter=std::string(argv[2])=="prefilter";
  std::set<int> restrict;
  if(!prefilter){std::ifstream in(argv[2]);int i;while(in>>i)restrict.insert(i);}
  std::ofstream output(argv[3]);
  output<<"point_one_based,helicity_index,basis,tensor_relative,component_max_relative\n"<<std::setprecision(18);

  Physical p;Spurious s;Feynman f;
  auto par=p.get_parameters();
  for(auto& a:par) a=cdouble(static_cast<double>(a.real()),static_cast<double>(a.imag()));
  p.set_parameters(par);s.set_parameters(par);f.set_parameters(par);
  p.set_widths_enabled(false);s.set_widths_enabled(false);f.set_widths_enabled(false);
  hepcat_spinas::ValidationOptions opts;
  opts.points=n;opts.seed=861811;
  std::mt19937_64 engine(opts.seed);
  auto helicities=p.helicity_configurations();
  if(helicities!=s.helicity_configurations()||helicities!=f.helicity_configurations())return 3;
  std::array<std::array<Stats,16>,4> statistics{};
  for(int i=0;i<n;++i){
    Physical::Momenta point;
    for(auto& four:point)for(auto& val:four){double x;if(!coords.read(reinterpret_cast<char*>(&x),sizeof(x)))return 3;val=ldouble(x);}
    if(!prefilter && !restrict.count(i+1))continue;
#ifdef PROJECTED
    point=project_true64(point,p.masses()[0]);
#endif
    p.set_momenta(point);s.set_momenta(point);f.set_momenta(point);
    for(int h=0;h<16;++h){
      auto spins=helicities[h];
      Tensor a,b,c;int index=0;
      for(int r:{1,-1})for(int t:{1,-1}) {
        spins[0]=r;spins[1]=t;
        a[index]=p.amp(spins);b[index]=s.amp(spins);c[index]=prefilter?a[index]:f.amp(spins);++index;
      }
      auto compare=[&](const Tensor& observed,const Tensor& reference,const char* label) {
        double mx=0,delta=0,mxrel=0;
        for(int j=0;j<4;++j){
          const auto ab=std::abs(reference[j]),de=std::abs(observed[j]-reference[j]);
          if(!std::isfinite(ab)||!std::isfinite(de)) std::exit(4);
          mx=std::max(mx,(double)ab);delta=std::max(delta,(double)de);
          if(ab>0)mxrel=std::max(mxrel,(double)(de/ab));
        }
        double metric=delta/mx;
        if(prefilter ? metric>6e-8 : true)output<<i+1<<","<<h<<","<<label<<","<<metric<<","<<mxrel<<"\n";
      };
      compare(b,c,"beam");compare(rotated(b),rotated(c),"rotated");
    }
    if(i%5000==4999)std::cerr<<"Completed "<<i+1<<"\n";
  }
}
