#include "process.hpp"
#include "feynman-sig.hpp"
#include <array>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>
#include <vector>
using Candidate = hepcat_generated::CONSTRUCTIVE_PROCESS;
using Feynman = hepcat_generated::FEYNMAN_PROCESS;

int main(int argc, char** argv) {
  std::size_t n = argc > 1 ? std::stoul(argv[1]) : 100000;
  Candidate c;
  Feynman f;
  c.set_widths_enabled(false);
  f.set_widths_enabled(false);
  auto mass = c.masses();
  if (mass != f.masses() || c.incoming_legs() != f.incoming_legs()
      || c.helicity_configurations() != f.helicity_configurations()) return 3;
  hepcat_spinas::ValidationOptions opts;
  opts.points = n;
  opts.seed = 861811;
  std::mt19937_64 engine(opts.seed);
  constexpr auto hcount = Candidate::helicity_count;
  const auto helicities = Candidate::helicity_configurations();
  std::array<std::vector<Candidate::Spins>, hcount> states;
  for (std::size_t h = 0; h < hcount; ++h) {
    states[h] = {helicities[h]};
    for (std::size_t j = 0; j < mass.size(); ++j) {
      if (helicities[h][j] != 0) continue;
      std::vector<Candidate::Spins> both;
      for (auto s : states[h]) {
        s[j] = 1;
        both.push_back(s);
        s[j] = -1;
        both.push_back(s);
      }
      states[h] = std::move(both);
    }
  }
  std::vector<std::pair<double,cdouble>> rotations;
  for (std::size_t i=0; i<mass.size(); ++i) {
    if (mass[i]==0) continue;
    const double theta = 0.31 + 0.09*i;
    const double phase = 0.42 + 0.37*i;
    rotations.emplace_back(std::cos(theta),std::polar(ldouble(std::sin(theta)),ldouble(phase)));
  }
  auto rotate = [&](std::vector<cdouble>& a) {
    std::size_t stride = a.size();
    for (auto u : rotations) {
      stride /= 2;
      for (std::size_t block=0; block<a.size(); block+=2*stride)
        for (std::size_t k=block; k<block+stride; ++k) {
          auto x=a[k], y=a[k+stride];
          a[k]=ldouble(u.first)*x + u.second*y;
          a[k+stride]=-std::conj(u.second)*x + ldouble(u.first)*y;
        }
    }
  };
  const double tol = 1e-7;
  std::array<double,hcount> maxrel{},maxscaled{};
  std::array<std::size_t,hcount> relbad{},scaledbad{},nonfinite{},processed{},worst{};
  for (std::size_t ip = 0; ip < n; ++ip) {
    auto point = hepcat_spinas::make_random_validation_momenta(mass,c.incoming_legs(),engine,opts);
    c.set_momenta(point);
    f.set_momenta(point);
    for (std::size_t h = 0; h < hcount; ++h) {
      double largest_reference = 0, largest_difference = 0;
      std::vector<cdouble> aa, bb;
      aa.reserve(states[h].size());
      bb.reserve(states[h].size());
      for (auto s : states[h]) {
        aa.push_back(c.amp(s));
        bb.push_back(f.amp(s));
      }
      rotate(aa);
      rotate(bb);
      for (std::size_t j=0; j<aa.size(); ++j) {
        auto a=aa[j], b=bb[j];
        auto da = std::abs(a - b), ab = std::abs(b);
        if (!std::isfinite(da) || !std::isfinite(ab)) { ++nonfinite[h]; continue; }
        largest_difference = std::max(largest_difference,double(da));
        largest_reference = std::max(largest_reference,double(ab));
        double rel = ab == 0 ? (da == 0 ? 0 : std::numeric_limits<double>::infinity()) : da/ab;
        if (rel > tol) ++relbad[h];
        if (rel > maxrel[h]) maxrel[h] = rel;
        ++processed[h];
      }
      double scaled = largest_reference == 0 ? (largest_difference == 0 ? 0 : std::numeric_limits<double>::infinity()) : largest_difference/largest_reference;
      if (scaled > tol) ++scaledbad[h];
      if (scaled > maxscaled[h]) { maxscaled[h] = scaled; worst[h] = ip; }
    }
  }
  std::cout << "helicity_index,points,spin_components,nonfinite,component_rel_failed,component_max_rel,tensor_rel_failed,tensor_max_rel,worst_tensor_point\n" << std::setprecision(17);
  for (std::size_t h=0; h<hcount; ++h)
    std::cout << h << "," << n << "," << processed[h] << "," << nonfinite[h] << "," << relbad[h] << "," << maxrel[h] << "," << scaledbad[h] << "," << maxscaled[h] << "," << worst[h] << "\n";
}
