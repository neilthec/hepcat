"""Retest the four-photon signed outliers in the original and rotated spin bases."""
import argparse
import csv
from pathlib import Path
import shutil
import subprocess
import sys
from replay import PACKAGE,write_sources


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",required=True,type=Path)
    parser.add_argument("--native",required=True,type=Path,help="SPINAS prefix used in the native signed run.")
    parser.add_argument("--extended",required=True,type=Path,help="SPINAS prefix providing a 64-bit significand.")
    args=parser.parse_args()
    work=args.output.resolve()
    coords=work/"spurious/eeAAAA/binary64-momenta.dat"
    if not coords.is_file():
        raise SystemExit("Run the native four-photon MG comparison with --capture-four-photon first.")
    d=work/"signed-control"
    d.mkdir(exist_ok=True)
    stub={name:"unused" for name in ("@MODELDIR@","@MGDIR@","@MGHELPER@","@PYTHON@")}
    p=write_sources(d,"eeAAAA","physical",stub)
    s=write_sources(d,"eeAAAA","spurious",stub)
    f=d/"feynman/eeAAAA"
    for name,source in (("spurious.hpp",s),("feynman-sig.hpp",f)):
        lines=(source/"process.hpp").read_text().splitlines()
        txt="\n".join(line for line in lines if not line.startswith("#include"))
        if name=="spurious.hpp":txt=txt.replace("eeAAAA","spur_eeAAAA")
        (d/name).write_text(txt+"\n")
    for mode,lib in (("native",args.native.resolve()),("extended",args.extended.resolve())):
        flags=["clang++","-O2","-std=c++17","-I"+str(lib/"include"),"-I"+str(d),"-I"+str(p)]
        if mode=="native":flags.append("-DWITH_LONG_DOUBLE")
        else:
            flags.append("-ffp-contract=off")
            if sys.platform=="darwin":flags+=["-arch","x86_64"]
        spinas=lib/"libspinas.a"
        if not spinas.is_file():spinas=lib/"build/libspinas.a"
        objects=[]
        for name,source,extra in (("physical",p,[]),("spurious",s,["-DeeAAAA=spur_eeAAAA"]),("feynman",f,[])):
            obj=d/(name+"-"+mode+".o")
            subprocess.run(flags+extra+["-c",str(source/"process.cpp"),"-o",str(obj)],check=True)
            objects.append(str(obj))
        runs=(("native",False),) if mode=="native" else (("extended",False),("projected",True))
        selected=d/"selected-indices.txt"
        for label,project in runs:
            exe=d/label
            cmd=flags+(["-DPROJECTED"] if project else [])
            subprocess.run(cmd+[str(PACKAGE/"signed-control.cpp"),*objects,str(spinas),"-o",str(exe)],check=True)
            if label=="native":
                subprocess.run([exe,coords,"prefilter",d/"selected.csv","go"],check=True)
                rows=csv.DictReader((d/"selected.csv").read_text().splitlines())
                ids=sorted({int(row["point_one_based"]) for row in rows})
                selected.write_text("\n".join(map(str,ids))+"\n")
            subprocess.run([exe,coords,selected,d/(label+".csv"),"go"],check=True)


if __name__=="__main__":
    main()
