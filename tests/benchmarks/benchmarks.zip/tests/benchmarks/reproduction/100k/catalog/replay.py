"""Rebuild the signed Feynman, CalcHEP and MadGraph comparisons for the QED catalog."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from zipfile import ZipFile

PACKAGE = Path(__file__).resolve().parent
FAMILIES = ("eeAA", "eeee", "eeAAA", "eeeeA", "eeAAAA", "eeeeAA", "eeeeee")
FORMS = ("physical", "spurious")
POINTS = 100000
SEED = 861811


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--points", type=int, default=POINTS)
    parser.add_argument("--families", choices=FAMILIES, nargs="+", default=FAMILIES)
    parser.add_argument("--forms", choices=FORMS, nargs="+", default=FORMS)
    parser.add_argument("--checks", choices=("signed","calchep","madgraph"), nargs="+",
                        default=("signed","calchep","madgraph"))
    parser.add_argument("--capture-four-photon",action="store_true",
                        help="Save binary64 MG weights and momenta for the four-photon spurious precision test.")
    args = parser.parse_args()
    if args.points < POINTS:
        parser.error("Use at least 100000 points.")
    return args


def path_from_env(name):
    value = os.environ.get(name)
    if not value:
        raise SystemExit(f"Set {name}.")
    return Path(value).resolve(strict=True)


def write_sources(work, family, form, paths):
    project = work / form / family
    project.mkdir(parents=True, exist_ok=True)
    common = work / "common"
    common.mkdir(exist_ok=True)
    with ZipFile(PACKAGE / "generated-sources.zip") as archive:
        sums = json.loads(archive.read("sha256.json"))
        for path, expected in sums.items():
            prefix, _, filename = path.rpartition("/")
            if prefix not in ("common", f"{form}/{family}", f"feynman/{family}"):
                continue
            data = archive.read(path)
            if hashlib.sha256(data).hexdigest() != expected:
                raise ValueError(f"Source checksum failed: {path}")
            if filename in ("spinas-validation.hpp","calchep-main.cpp","madgraph-main.cpp"):
                data=data.replace(b"points = 1000;",b"points = 100000;")
            if prefix == "common":
                (common/filename).write_bytes(data)
            elif prefix.startswith("feynman/"):
                feynman = work / prefix
                feynman.mkdir(parents=True,exist_ok=True)
                (feynman/filename).write_bytes(data)
            else:
                if filename.endswith("-validation.cpp"):
                    contents = data.decode()
                    for key, value in paths.items():
                        contents = contents.replace(key,json.dumps(str(value))[1:-1])
                    data = contents.encode()
                (project/filename).write_bytes(data)
    # Exported headers normally live in each process directory. Here both
    # Feynman and constructive code use the identical archived runtime headers.
    for f in common.iterdir():
        for process in (project, work/"feynman"/family):
            target=process / f.name
            shutil.copyfile(f,target)
    template=(PACKAGE/"CMakeLists.in").read_text().replace("@CLASS@",family)
    if family=="eeAAAA":
        fdir=work/"feynman"/family
        subprocess.run([sys.executable,str(PACKAGE/"share-feynman.py"),str(fdir),str(fdir)],check=True)
    fdheader=(work/"feynman"/family/"process.hpp").read_text().splitlines()
    (project/"feynman-sig.hpp").write_text("\n".join(line for line in fdheader if not line.startswith("#include"))+"\n")
    template += '''
add_library(feynman_process STATIC "../../feynman/FAMILY/process.cpp")
target_include_directories(feynman_process PRIVATE "${SPINAS_INCLUDE_DIR}")
target_compile_definitions(feynman_process PRIVATE WITH_LONG_DOUBLE)
'''
    for stem in ("signed","signed-rotated"):
        shutil.copyfile(PACKAGE/(stem+".cpp"),project/(stem+".cpp"))
        template += f'''
add_executable({stem} {stem}.cpp)
set_property(TARGET {stem} PROPERTY CXX_STANDARD 17)
target_compile_definitions({stem} PRIVATE CONSTRUCTIVE_PROCESS=FAMILY FEYNMAN_PROCESS=fdFAMILY)
target_link_libraries({stem} PRIVATE FAMILY_process feynman_process)
'''
    (project/"CMakeLists.txt").write_text(template.replace("FAMILY",family))
    return project


def command(args, cwd, log):
    with log.open("w") as out:
        proc = subprocess.run(args,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
    return proc.returncode


def main():
    args=arguments()
    out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=True)
    spinas=path_from_env("SPINAS_ROOT")
    calchep=path_from_env("CALCHEP_ROOT") if "calchep" in args.checks else Path("/")
    modeldir=path_from_env("HEPCAT_ROOT")/"tests/reference-models/calchep" if "calchep" in args.checks else Path("/")
    mg=path_from_env("MADGRAPH_ROOT") if "madgraph" in args.checks else Path("/")
    paths={"@MODELDIR@":modeldir,"@MGDIR@":mg,"@PYTHON@":sys.executable,
           "@MGHELPER@":out/"common"/"madgraph-runtime.py"}
    errors=[]
    for family in args.families:
        for form in args.forms:
            project=write_sources(out,family,form,paths)
            if args.capture_four_photon and family=="eeAAAA" and form=="spurious":
                header=project/"spinas-validation.hpp"
                contents=header.read_text()
                marker="      report.maximum_absolute_error = std::max(report.maximum_absolute_error, absolute_error);"
                assert contents.count(marker)==1
                header.write_text("#include <fstream>\n"+contents.replace(marker,(PACKAGE/"capture-hook.inc").read_text()+marker))
            tools=[]
            for check in args.checks:
                if check=="signed":
                    tools.extend(("signed","signed-rotated"))
                else:
                    tools.append(family+"_validate_"+check)
            subprocess.run(["cmake","-S",".","-B","build","-DSPINAS_ROOT="+str(spinas),
                            "-DCALCHEP_ROOT="+str(calchep)],cwd=project,check=True)
            subprocess.run(["cmake","--build","build","--parallel","2","--target",*tools],cwd=project,check=True)
            for name in tools:
                binary=project/"build"/name
                if name.startswith("signed"):
                    path=project/(name+".csv")
                    rc=command([binary,str(args.points)],project,path)
                    if rc==0:
                        rows=list(csv.DictReader(path.read_text().splitlines()))
                        if (len(rows)!=2**family.count("A") or any(
                            int(row["points"])!=args.points or int(row["nonfinite"]) or
                            int(row["spin_components"])!=args.points*2**family.count("e")
                            for row in rows)):
                            rc=2
                        elif any(int(row["tensor_rel_failed"]) for row in rows):
                            rc=1
                else:
                    argv=[binary,"--points",str(args.points),"--seed",str(SEED)]
                    if name.endswith("madgraph"):
                        argv+=["--report",str(project/"madgraph.json")]
                    rc=command(argv,project,project/(name+".log"))
                if rc: errors.append([family,form,name,rc])
    if errors: raise SystemExit(f"Validation errors: {errors}")


if __name__=="__main__":
    main()
