(* Validate the two matching contributions independently of one another. *)
package = DirectoryName[ExpandFileName[$InputFileName]];
root = ExpandFileName[Environment["HEPCAT_ROOT"]];
Get[FileNameJoin[{root, "source", "HEPCAT.wl"}]];
$HistoryLength = 0;
diagramModel = ReadModel[FileNameJoin[{root, "models"}], 2];
model = ReadModel[FileNameJoin[{root, "models"}], 3];
feynmanModel = ReadModel[FileNameJoin[{root, "tests", "reference-models", "calchep"}], 2];
paperForms = Import[FileNameJoin[{package, "input-expressions.wxf"}], "WXF"];
baseProcess = {"e", "E", "E", "e", "A.+"};
canonical[value_] := ConstructiveDiagrams`Private`canonicalChains[
  ConstructiveDiagrams`Private`residueCanonicalPropagators[value, Range[5]]];
rebind[value_] := value /. p_ModelParameter :> ModelParameter[model, ModelParameterName[p]];
matching[diagram_] := Sort[Sort /@ ConstructiveDiagrams`diagramFermionLines[diagram]];
exchangePoles[diagram_] := Function[prop,
  ConstructiveDiagrams`Private`residueCanonicalPropagators[PropDen[Mom[prop["Index"]], 0], Range[5]]
] /@ Select[Values[diagram["Propagators"]], #["Spin2"] === 2 && #["Mass"] === 0 &];
checks = 0;
require[condition_, description_] := (checks++; If[!TrueQ[condition], Print[description]; Quit[1]]);
Do[
  particles = baseProcess[[permutation]] /. "A.+" -> helicity;
  massRules = MapIndexed[Mass[First[#2]] -> If[MemberQ[{"e", "E"}, #1],
    ModelParameter[model, "Me"], 0] &, particles];
  diagrams = CreateDiagrams[particles, diagramModel];
  propose[graphs_] := ConstructiveDiagrams`Private`constructGroupedVectorCurrents[
    graphs, particles, diagramModel, massRules, "AllPhysical"];
  candidate = propose[diagrams];
  require[AssociationQ[candidate], {"topology", particles}];
  amplitude = canonical[rebind[candidate["Expression"]]];
  If[permutation === Range[5],
    paper = SelectFirst[paperForms, #["particles"] === particles && #["form"] === "physical" &];
    require[Together[amplitude - canonical[rebind[paper["expression"]]]] === 0,
      {"ordinary identity against paper", particles}];
    require[MissingQ[propose[Most[diagrams]]], {"one missing graph", particles}];
    require[MissingQ[propose[ReplacePart[diagrams, -1 -> First[diagrams]]]],
      {"repeated graph", particles}];
    altered = First[diagrams]; propagators = altered["Propagators"];
    key = First[Keys[propagators]]; prop = propagators[key];
    AssociateTo[prop, "Factor" -> -prop["Factor"]];
    AssociateTo[propagators, key -> prop]; AssociateTo[altered, "Propagators" -> propagators];
    require[MissingQ[propose[ReplacePart[diagrams, 1 -> altered]]],
      {"reversed propagator sign", particles}]];
  byMatching = GatherBy[CreateDiagrams[particles, feynmanModel], matching];
  polesPerMatching = Function[graphs, DeleteDuplicates[Flatten[exchangePoles /@ graphs]]] /@ byMatching;
  allPoles = Union @@ polesPerMatching;
  require[Length[byMatching] === 2 && Length[allPoles] === 4, {"exchange poles", particles}];
  partitions = Function[keep, amplitude /. ((1/# -> 0) & /@ Complement[allPoles, keep])] /@ polesPerMatching;
  require[Together[Total[partitions] - amplitude] === 0, {"recombined matchings", particles}];
  Do[
    inputs = ConstructiveDiagrams`Private`residueSimpleInputs[{massRules, partitions[[i]]},
      FactorizationAmplitudeChannels[particles, model], model];
    reference = DiagramAmplitudes[byMatching[[i]]];
    report = ConstructiveDiagrams`Private`amplitudeFeynmanReport[inputs, reference, model,
      3, 973310 + 5 i + First[permutation], ModelParameterRules[model],
      ModelParameterRules[feynmanModel], 480, 0];
    require[report["Status"] === "PASS" && report["OverallSign"] === 1 &&
      report["CompletedSamples"] === 3, {"signed Feynman sum", particles, matching[First[byMatching[[i]]]]}],
    {i, Length[byMatching]}],
  {permutation, {{1, 2, 3, 4, 5}, {5, 1, 2, 3, 4}, {2, 1, 4, 3, 5}, {1, 4, 2, 3, 5}}},
  {helicity, {"A.+", "A.-"}}];
Print[checks, " checks passed."];
