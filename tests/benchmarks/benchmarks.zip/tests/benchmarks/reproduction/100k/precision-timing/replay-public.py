from pathlib import Path
import csv,json,subprocess,sys,itertools,time,hashlib,struct,tempfile,os,shutil
import argparse
a=argparse.ArgumentParser(description="Replay all 100,000 original eight-photon points with a compiled evaluation binary.")
a.add_argument('--executable',required=True,type=Path)
a.add_argument('--fixture',required=True,type=Path)
a.add_argument('--input',required=True,type=Path)
a.add_argument('--output',required=True,type=Path)
a.add_argument('--form',required=True,choices=['physical','spurious'])
a.add_argument('--mode',required=True,choices=['native','double','extended','restored'])
args=a.parse_args()
m=args.mode;form=args.form
src=args.input.resolve();d=args.output.resolve();d.mkdir(exist_ok=True,parents=True)
exe=args.executable.resolve();fixture=args.fixture.resolve();params=fixture/'inputs/parameters.csv'
if (d/'metadata.json').is_file():raise ValueError("Choose a new output directory or resume an unfinished run.")
def bits(x):return struct.pack('>d',float(x)).hex()
size=500
with src.open() as files:
 header=next(files);maxid=0
 for chunk in range(100000//size):
  lines=list(itertools.islice(files,size*10));assert len(lines)==size*10
  dst=d/('chunk-%03d.csv'%chunk)
  if dst.exists():maxid+=size;continue
  scratch=d/'active-input.csv';scratch.write_text(header+''.join(lines))
  js=d/'active-output.json'
  run=subprocess.run([str(exe),str(scratch),str(params),str(js)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  if run.returncode:raise RuntimeError((run.returncode,run.stdout))
  data=json.loads(js.read_text());assert len(data['Rates'])==size
  fn=d/'active-rates.csv'
  with fn.open('w') as out:
   out.write('point,rate,maximum_input_adjustment\n')
   for i,row in enumerate(data['Rates']):
    maxid+=1;assert row['Point']==maxid
    orig=[field.strip() for line in lines[i*10:(i+1)*10] for field in line.split(',')[2:]]
    assert list(map(bits,orig))==row['MomentBits']
    adjust=''
    if m=='restored':
     from decimal import Decimal
     flat=[Decimal(x) for leg in row['ProjectedMomenta'] for x in leg]
     adjust=str(max(abs(Decimal.from_float(float(a))-b) for a,b in zip(orig,flat)))
    out.write(f"{maxid},{row['Squared']},{adjust}\n")
  os.replace(fn,dst);js.unlink();scratch.unlink()
  print('through',maxid,flush=True)
 assert maxid==100000 and not files.readline()
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
out=d/'rates.csv'
with out.open('w') as target:
 target.write('point,rate,maximum_input_adjustment\n')
 for chunk in range(100000//size):
  path=d/('chunk-%03d.csv'%chunk)
  with path.open() as f:next(f);shutil.copyfileobj(f,target)
meta={'points':maxid,'bits':64 if m in ('extended','restored') else 53,'projection':m=='restored','parameter_sha256':digest(params),'graph_sha256':digest(fixture/f'graphs/{form}/process.cpp'),'exe_sha256':digest(exe),'point_sha256':digest(src),'rates_sha256':digest(out),'normalization':'same original binary64 1/4','input_bits_verified':True}
(d/'metadata.json').write_text(json.dumps(meta,indent=2));subprocess.run(['gzip','-1',str(out)],check=True)
for chunk in range(100000//size):(d/('chunk-%03d.csv'%chunk)).unlink()
