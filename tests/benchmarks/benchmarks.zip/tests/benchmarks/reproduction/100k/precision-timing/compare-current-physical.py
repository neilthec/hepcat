#!/usr/bin/env python3
"""Compare the current physical eight-photon export with MadGraph and the original controls."""
import argparse
import csv
import gzip
import json
from contextlib import ExitStack
from decimal import Decimal
from itertools import zip_longest
from pathlib import Path


def open_csv(path):
    return gzip.open(path, "rt", newline="") if path.suffix == ".gz" else path.open(newline="")


def delta(a, b):
    denominator = max(abs(a), abs(b))
    return abs(a - b) / denominator if denominator else Decimal(0)


def compare(current, native, original, reference):
    modes = ("native", "double", "extended", "restored")
    maximum, counts, ids, unequal = {}, {}, {}, dict.fromkeys(modes, 0)
    def add(key, value, point):
        if not value.is_finite():
            raise ValueError(f"Nonfinite error at {key}, point {point}")
        counts[key] = counts.get(key, 0) + int(value > Decimal("1e-7"))
        if key not in maximum or value > maximum[key]:
            maximum[key] = value
            ids[key] = point
    with ExitStack() as files:
        items = {mode: native if mode == "native" else current / mode / "rates.csv.gz" for mode in modes}
        items.update({mode + "-original": original / mode / "physical/rates.csv.gz" for mode in modes})
        items["spurious-restored"] = original / "restored/spurious/rates.csv.gz"
        items["madgraph"] = reference
        streams = [csv.DictReader(files.enter_context(open_csv(path))) for path in items.values()]
        count = 0
        for count, lines in enumerate(zip_longest(*streams), 1):
            if any(row is None or int(row["point"]) != count for row in lines):
                raise ValueError(f"Point mismatch at {count}")
            rows = dict(zip(items, lines))
            if float(rows["native"]["madgraph_squared"]).hex() != float(rows["madgraph"]["madgraph_squared"]).hex():
                raise ValueError(f"Independent MadGraph streams differ at {count}")
            mg = Decimal.from_float(float(rows["madgraph"]["madgraph_squared"]))
            for mode in modes:
                new = Decimal(rows[mode]["hepcat" if mode == "native" else "rate"])
                old = Decimal(rows[mode + "-original"]["rate"])
                if mode in ("native", "double"):
                    new, old = (Decimal.from_float(float(x)) for x in (new, old))
                unequal[mode] += int(new != old)
                add(mode + "-vs-original-graph", delta(new, old), count)
                if mode == "restored":
                    spurious = rows["spurious-restored"]
                    adjustment = Decimal(rows[mode]["maximum_input_adjustment"])
                    for previous in (rows[mode + "-original"], spurious):
                        if adjustment != Decimal(previous["maximum_input_adjustment"]):
                            raise ValueError(f"Projected momenta mismatch at point {count}")
                    add("restored-current-physical-vs-spurious", delta(new, Decimal(spurious["rate"])), count)
                else:
                    add(mode + "-current-vs-madgraph", delta(new, mg), count)
    if count != 100000:
        raise ValueError(f"Expected 100,000 points, found {count}")
    return {"points": count, "maximum_relative_difference": {k: str(v) for k, v in maximum.items()},
            "above_1e-7": counts, "worst_point": ids, "unequal_rates_current_vs_original": unequal,
            "retained_original_madgraph_binary64": count}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--current-intel", type=Path, required=True)
    parser.add_argument("--current-native", type=Path, required=True)
    parser.add_argument("--original-controls", type=Path, required=True)
    parser.add_argument("--original-madgraph", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = compare(args.current_intel, args.current_native, args.original_controls, args.original_madgraph)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
