"""Join native full-helicity timing results from the QED paper's current exports."""
import argparse,csv,gzip,hashlib,itertools,json,math,statistics
from pathlib import Path

def stream(path):
    return gzip.open(path,'rt',newline='') if path.suffix=='.gz' else path.open(newline='')
def locate(path):
    return path if path.is_file() else Path(str(path)+'.gz')
def digest(path):
    h=hashlib.sha256()
    with stream(path) as f:
        for line in f:h.update(line.encode())
    return h.hexdigest()
def read_rows(path):
    with stream(locate(path)) as f:yield from csv.DictReader(f)
def relative(a,b):
    assert math.isfinite(a) and math.isfinite(b) and min(a,b)>=0
    return abs(a-b)/max(a,b) if (a or b) else 0.
def run(folder):
    reports={}; summary=[]
    backends=['HEPCAT_SPINAS_AllPhysical','HEPCAT_SPINAS_AllSpurious','CalcHEP','MadGraph']
    for tag in ('physical','spurious'):
        meta=json.loads((folder/tag/'timings-metadata.json').read_text())
        assert meta['Status']=='COMPLETE' and meta['ValidatedRows']=='PASS' and meta['CompletedPhotonCounts']==[2,3,4]
        assert meta['Points']>=100000 and meta['SPINASPrecisionBits']==53 and meta['SPINASScalarType']=='double'
        reports[tag]=meta
    assert reports['physical']['Seed']==reports['spurious']['Seed']
    validation={}
    for n in (2,3,4):
        src=[folder/tag for tag in ('physical','spurious')];p,v=src
        pointdigests=[digest(locate(d/f'timings-points-N{n}.csv')) for d in src]
        assert pointdigests[0]==pointdigests[1]
        mgreps=[json.loads((d/f'timings-madgraph-N{n}.json').read_text()) for d in src]
        for m in mgreps:assert m['Status']=='READY' and m['HelicityStates']==4*2**n and m['AllowedParticlePDGs']==[11,22] and m['OptimizationLevel']==3
        rows=0;worst=0.;exhaustive=0.
        for a,b in itertools.zip_longest(*[read_rows(d/f'timings-values-N{n}.csv') for d in src]):
            rows+=1;assert int(a['point'])==int(b['point'])==rows
            assert a['calchep']==b['calchep'] and a['madgraph']==b['madgraph']
            arr=[float(a['spinas']),float(b['spinas']),float(a['calchep']),float(a['madgraph'])]
            worst=max(worst,relative(min(arr),max(arr)))
            exhaustive=max(exhaustive,relative(float(a['spinas']),float(a['spinas_exhaustive'])),relative(float(b['spinas']),float(b['spinas_exhaustive'])))
        assert rows==reports['physical']['Points']==reports['spurious']['Points']
        times=[]
        for d,tag in zip([p,v,p,p],['SPINAS','SPINAS','CalcHEP','MadGraph']):
            source=[r for r in read_rows(d/'timings-repetitions.csv') if int(r['photons'])==n and r['backend']==tag]
            assert sorted(int(r['repetition']) for r in source)==list(range(1,10))
            assert all(int(r['points'])==rows for r in source)
            times.append(statistics.median(float(r['seconds']) for r in source))
        summary.append(dict(photons=n,points=rows,**{k+'_seconds':x for k,x in zip(backends,times)}))
        validation[n]={'points':rows,'same_inputs_sha256':pointdigests[0],'maximum_four_way_error':worst,'maximum_exhaustive_error':exhaustive}
    with (folder/'fourway.csv').open('w',newline='') as f:
        z=csv.DictWriter(f,fieldnames=list(summary[0]));z.writeheader();z.writerows(summary)
    (folder/'fourway-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('directory',type=Path);run(a.parse_args().directory)
