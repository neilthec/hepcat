// Generate common six-fermion momenta with the published phase-space sampler.
/*
HEPCAT - High Energy Physics Constructive Amplitude Tool

Copyright (C) 2026 Neil Christensen

This file is part of HEPCAT.

HEPCAT is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HEPCAT is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HEPCAT.  If not, see <https://www.gnu.org/licenses/>.
*/
#include "process.hpp"
#include <fstream>
#include <iomanip>
#include <random>
#include <string>
int main(int argc, char** argv) {
  if (argc != 6) return 2;
  hepcat_generated::eeeeee process;
  hepcat_spinas::ValidationOptions options;
  options.seed = std::stoull(argv[5]);
  options.minimum_center_of_mass_energy = std::stod(argv[3]);
  options.maximum_center_of_mass_energy = std::stod(argv[4]);
  std::mt19937_64 random(options.seed);
  const int count = std::stoi(argv[2]);
  if (count < 1) throw std::invalid_argument("Point count must be positive");
  std::ofstream out(argv[1]);
  out << "point,leg,E,px,py,pz\n" << std::setprecision(17);
  for (int point = 1; point <= count; ++point) {
    const auto momenta = hepcat_spinas::make_random_validation_momenta(
        process.masses(), process.incoming_legs(), random, options);
    for (size_t leg = 0; leg < momenta.size(); ++leg) {
      out << point << ',' << leg + 1;
      for (auto component : momenta[leg]) out << ',' << component;
      out << '\n';
    }
  }
  return out ? 0 : 1;
}
