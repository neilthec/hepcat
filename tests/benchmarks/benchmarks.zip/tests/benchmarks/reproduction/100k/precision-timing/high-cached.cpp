// Evaluate the paper's collected physical and spurious recurrences on the same inputs.
#include "all-positive-formulas-cached.hpp"
#include <zlib.h>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <vector>
#include <cstdlib>
#include <stdexcept>

class Input {
  gzFile file;
public:
  explicit Input(const char* path):file(gzopen(path,"rb")) {if(!file)throw std::runtime_error(std::string("missing file ")+path);}
  ~Input(){gzclose(file);}
  bool row(std::vector<double>& data,bool header=false) {
    char text[8192];if(!gzgets(file,text,sizeof text)){if(!gzeof(file))throw std::runtime_error("read error");return false;}
    if(header)return true; data.clear();char* cur=text;
    while(*cur){char* end=nullptr;double x=std::strtod(cur,&end);if(end==cur)throw std::runtime_error("bad numeric input");data.push_back(x);
      if(*end!=',')break;cur=end+1;}
    return true;
  }
};
using hepcat_all_positive::Formulas;
template<class T> long double rel(T a,T b){const auto den=std::max(std::abs(a),std::abs(b));return den?std::abs(a-b)/den:0;}
using Four=std::array<ldouble,4>;
ldouble spatial_squared(const Four& p){return std::fma(p[1],p[1],std::fma(p[2],p[2],p[3]*p[3]));}
template<class Mom> Mom project(const Mom& original,ldouble mass) {
  Mom p=original;Four total={};for(std::size_t j=2;j<p.size();++j){p[j][0]=std::sqrt(spatial_squared(p[j]));for(int k=0;k<4;++k)total[k]+=p[j][k];}
  const auto mi=std::sqrt(total[0]*total[0]-spatial_squared(total));ldouble rest=0;
  for(std::size_t j=2;j<p.size();++j){auto old=p[j];ldouble dot=0;for(int k=1;k<4;++k)dot=std::fma(total[k],old[k],dot);
    auto shift=dot/(mi*(total[0]+mi))-old[0]/mi;for(int k=1;k<4;++k)p[j][k]=old[k]+total[k]*shift;p[j][0]=std::sqrt(spatial_squared(p[j]));rest+=p[j][0];}
  auto energy=original[0][0]+original[1][0], scale=energy/rest;for(std::size_t j=2;j<p.size();++j)for(auto& x:p[j])x*=scale;
  auto e=energy/2,z=std::sqrt((e-mass)*(e+mass));p[0]={e,0,0,z};p[1]={e,0,0,-z};return p;
}
template<int N> int run(const char* pp,const char* rv,const char* dst,bool restore,double mass53){
  std::vector<double> row,reference;Input all(pp),rates(rv);if(!all.row(row,true))throw std::runtime_error("missing header");
  rates.row(reference,true);
  std::ofstream output(dst);if(!output)throw std::runtime_error("failed to create output");
  output<<"point,physical,spurious,madgraph,complex_difference,max_input_adjustment\n"<<std::setprecision(std::numeric_limits<long double>::max_digits10);
  const unsigned first=std::getenv("QED_FIRST_POINT")?std::stoul(std::getenv("QED_FIRST_POINT")):1;
  const unsigned last=std::getenv("QED_LAST_POINT")?std::stoul(std::getenv("QED_LAST_POINT")):100000;
  if(first>last || first<1 || last>100000) throw std::runtime_error("invalid shard interval");
  unsigned n=std::getenv("QED_LOCAL_SHARD")?first-1:0,errors=0;ldouble m=static_cast<ldouble>(mass53),e=static_cast<ldouble>(double(1./3.));
  while(n<last && rates.row(reference)){++n;typename Formulas<N>::Momenta p{};
    if(reference.size()<4 || reference[0]!=n)throw std::runtime_error("reference ID");
    for(int j=0;j<N+2;++j){if(!all.row(row) || row.size()!=6 || row[0]!=n || row[1]!=j+1)throw std::runtime_error("point/leg mismatch");
       for(int k=0;k<4;++k)p[j][k]=static_cast<ldouble>(row[k+2]);}
    if(n<first)continue;
    long double adjust=0,complex_error=0;ldouble phys=0,spur=0;if(restore){auto original=p;p=project(p,m);for(int j=0;j<N+2;++j)for(int k=0;k<4;++k)adjust=std::max(adjust,std::abs((long double)p[j][k]-original[j][k]));}
    try{Formulas<N> f(p,m,e);for(int a:{-1,1})for(int b:{-1,1}){auto ap=f.collected_physical_amplitude(a,b),as=f.amplitudes(a,b).spurious;phys+=std::norm(ap);spur+=std::norm(as);
      complex_error=std::max(complex_error,rel(std::complex<long double>(ap.real(),ap.imag()),std::complex<long double>(as.real(),as.imag())));}
      if(!std::isfinite(phys)||!std::isfinite(spur)||!std::isfinite(complex_error))throw std::runtime_error("nonfinite");}
    catch(const std::exception& ex){if(errors++<5)std::cerr<<"Error point "<<n<<" "<<ex.what()<<"\n";phys=spur=std::numeric_limits<ldouble>::quiet_NaN();complex_error=phys;}
    output<<n<<','<<phys<<','<<spur<<',';if(!restore)output<<reference[3];output<<','<<complex_error<<','<<adjust<<'\n';
    if(n%1000==0){output.flush();std::cout<<n<<" points "<<errors<<" errors"<<std::endl;}
  }
  if(n!=last || (last==100000 && all.row(row)))throw std::runtime_error("data set length");
  std::cout<<"Points="<<n<<" Errors="<<errors<<" Bits="<<std::numeric_limits<ldouble>::digits<<'\n';return errors?1:0;
}
int main(int argc,char** v){try{if(argc!=7)throw std::runtime_error("usage: N points values output restore mass");auto i=std::stoi(v[1]);bool restore=std::stoi(v[5])!=0;double m=std::stod(v[6]);
  switch(i){case 5:return run<5>(v[2],v[3],v[4],restore,m);case 6:return run<6>(v[2],v[3],v[4],restore,m);case 7:return run<7>(v[2],v[3],v[4],restore,m);case 8:return run<8>(v[2],v[3],v[4],restore,m);}
  throw std::runtime_error("invalid N");}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 2;}}
