"""Evaluate the complete six-fermion MadGraph spin sum on saved momenta."""

# HEPCAT - High Energy Physics Constructive Amplitude Tool
#
# Copyright (C) 2026 Neil Christensen
#
# This file is part of HEPCAT.
#
# HEPCAT is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# HEPCAT is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with HEPCAT.  If not, see <https://www.gnu.org/licenses/>.

import csv
import ctypes
import math
import sys
from itertools import groupby
from pathlib import Path

points, library, result = map(Path, sys.argv[1:])
mg = ctypes.CDLL(str(library.resolve()))
mg.hepcat_mg_initialize.restype = ctypes.c_int
if mg.hepcat_mg_initialize() != 0:
    raise RuntimeError('MadGraph initialization failed')
mg.hepcat_mg_evaluate_sum.argtypes = [ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double)]
mg.hepcat_mg_evaluate_sum.restype = None
count = 0
with points.open() as source, result.open('w', newline='') as destination:
    writer = csv.writer(destination)
    writer.writerow(['point','madgraph','raw_spin_sum'])
    for key, group in groupby(csv.DictReader(source), lambda row: int(row['point'])):
        count += 1
        rows = list(group)
        if key != count or [int(row['leg']) for row in rows] != list(range(1,7)):
            raise ValueError('Unordered, missing or repeated point or leg')
        values = [float(row[k]) for row in rows for k in ('E','px','py','pz')]
        rate = ctypes.c_double()
        mg.hepcat_mg_evaluate_sum((ctypes.c_double*24)(*values), ctypes.byref(rate))
        if not (math.isfinite(rate.value) and rate.value >= 0):
            raise ArithmeticError(f'MadGraph rate is undefined at {key}')
        writer.writerow([key,format(rate.value/16,'.17g'),format(rate.value,'.17g')])
if count < 100000:
    raise ValueError(f'Expected at least 100,000 points, received {count}.')
print(count, 'complete MadGraph sums at sixty-four massive spin assignments each')
