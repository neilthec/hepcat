"""Reuse complex amplitudes within the two different spin sums at the same momenta."""
import argparse,re
from pathlib import Path
def emit(src, dest):
 h=(src/'process.hpp').read_text();c=(src/'process.cpp').read_text()
 sig=re.search(r'cdouble (\w+)::amp_unchecked\(([^)]+)\)\s*\{',c);assert sig
 cls,params=sig.groups();spins=re.findall(r'const int& (ds\d+)',params)
 assert len(spins)==6 and c.count('momenta_ready = true;')==1 and h.count('cdouble amp_unchecked(')==1
 dest.mkdir(exist_ok=True,parents=True)
 for q in src.glob('*.hpp'):(dest/q.name).write_bytes(q.read_bytes())
 signature=f'cdouble {cls}::amp_unchecked({params})'
 idx='0';p=','.join(spins)
 for spin in spins:idx=f'(({idx}) * 2 + ({spin} > 0))'
 entry=signature+' {\n  const auto i='+idx+';\n  if(!cached_rate_ready_[i]) {cached_rate_[i]=evaluate_for_sums('+p+'); cached_rate_ready_[i]=true;}\n  return cached_rate_[i];\n}\n'+f'cdouble {cls}::evaluate_for_sums({params}) {{'
 c=c[:sig.start()]+entry+c[sig.end():]
 c=c.replace('momenta_ready = true;','cached_rate_ready_.fill(false); momenta_ready = true;')
 h=h.replace('cdouble amp_unchecked(', 'std::array<bool,64> cached_rate_ready_{};\n  std::array<cdouble,64> cached_rate_{};\n  cdouble evaluate_for_sums('+params+');\n  cdouble amp_unchecked(')
 (dest/'process.hpp').write_text(h);(dest/'process.cpp').write_text(c);return cls
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('source',type=Path)
 parser.add_argument('destination',type=Path)
 args=parser.parse_args()
 emit(args.source,args.destination)
