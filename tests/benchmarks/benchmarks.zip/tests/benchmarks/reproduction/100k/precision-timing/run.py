#!/usr/bin/env python3
"""Build and run the QED current-process precision comparisons or time the native double sums."""
import argparse,hashlib,importlib.util,itertools,json,os,platform,re,shutil,subprocess,sys,zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
def checkout(explicit):
    if explicit:return explicit.resolve()
    for d in HERE.parents:
        if (d/'source/internal/export/madgraph-runtime.py').is_file():return d
    raise ValueError('Supply --repository for a HEPCAT checkout.')
def execute(*args, **kw):subprocess.run([str(x) for x in args],check=True,**kw)
def sources(output):
    raw=output/'processes'
    with zipfile.ZipFile(HERE/'current-processes.zip') as archive:
        records=json.loads(archive.read('SHA256.json'))
        for name,h in records.items():
            member=Path(name)
            if member.is_absolute() or '..' in member.parts:raise ValueError('Invalid member path')
            dest=raw/member;data=archive.read(name)
            if hashlib.sha256(data).hexdigest()!=h:raise ValueError('Export digest mismatch: '+name)
            dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    return raw
def precision_library(args,repo,mode):
    flags=['-std=c++17','-O2','-ffp-contract=off']
    if args.arch:flags[:0]=['-arch',args.arch]
    d=args.output/'spinas'/mode
    if not (d/'libspinas.a').exists():
        spec=importlib.util.spec_from_file_location('hepcat_precision_builder',repo/'tests/benchmarks/reproduction/replay-precision.py')
        builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
        builder.build_library(args.spinas.resolve(),d,mode,args.cxx,flags)
    return d,flags
def process_binary(raw,args,repo):
    proc=raw/args.form/args.code
    man=json.loads((proc/'manifest.json').read_text())
    out=args.output/'bin'/args.form/args.code/args.mode;out.parent.mkdir(parents=True,exist_ok=True)
    cpp=(proc/'process.cpp').read_text()
    guard='validate_momenta(values, external_masses, incoming_legs())'
    if cpp.count(guard)!=1:raise ValueError('Cannot identify the expected external kinematic check.')
    src=out.with_name('process.cpp')
    src.write_text(cpp.replace(guard,'validate_momenta(values, external_masses, incoming_legs(), std::max(ldouble(1e-10L), ldouble(64)*std::numeric_limits<ldouble>::epsilon()))'))
    if args.cache_spins:
        if args.code!='eeeeee':
            raise ValueError('The saved spin-cache replay is for the six-fermion sector.')
        (out.parent/'process.hpp').write_bytes((proc/'process.hpp').read_bytes())
        cached=out.parent/'spin-cache'
        execute(sys.executable,HERE/'cache-spin-sum.py',out.parent,cached)
        src=cached/'process.cpp'
    if args.cache_amplitudes:
        if args.code not in ('eeAAAA','eeeeAA') or args.cache_spins:
            raise ValueError('Use the amplitude cache with the four- or two-photon six-point process.')
        for path in proc.glob('*.hpp'):
            (out.parent/path.name).write_bytes(path.read_bytes())
        cached=out.parent/'amplitude-cache'
        execute(sys.executable,HERE/'cache-amplitudes.py',out.parent,cached)
        src=cached/'process.cpp'
        proc=cached
    lib,flags=precision_library(args,repo,args.mode)
    execute(args.cxx,*flags,'-DPROCESS='+man['Class'],'-I'+str(proc),'-I'+str(lib/'include'),HERE/'evaluate.cpp',src,lib/'libspinas.a','-o',out)
    return out
def timings(raw,args,repo):
    if args.arch:raise ValueError('Time the native double-precision target.')
    if not args.calchep or not args.madgraph:raise ValueError('Supply --calchep and --madgraph for timings.')
    from_backend=repo/'tests/benchmarks'
    if 'opposite three-momenta' not in (from_backend/'benchmark.hpp').read_text():
        raise ValueError('Install the accompanying two-body RAMBO change in tests/benchmarks/benchmark.hpp first.')
    library,flags=precision_library(args,repo,'double')
    four=args.form=='common'
    forms=('physical','spurious') if four else (args.form,)
    codes=('eeee','eeeeA','eeeeAA') if four else ('eeAA','eeAAA','eeAAAA')
    opts=[]
    for form in forms:
        leaves=[]
        for code in codes:
            proc=raw/form/code;d=args.output/'timing-exports'/form/code;d.mkdir(parents=True,exist_ok=True)
            m=json.loads((proc/'manifest.json').read_text());cls=m['Class'];new=cls+form.title()
            for p in [proc/'process.cpp',*proc.glob('*.hpp')]:
                source=p.read_text()
                if p.name in ('process.hpp','process.cpp'):source=re.sub(r'\b'+re.escape(cls)+r'\b',new,source)
                (d/p.name).write_text(source)
            ch=m['CalcHEPValidation'];ch.update(Status='AVAILABLE',Reason='',CalcHEPDirectory=str(args.calchep.resolve()),ModelDirectory=str(repo/'tests/reference-models/calchep'),Points=100000)
            mg=m['MadGraphValidation'];mg.update(Status='AVAILABLE',Reason='',PythonExecutable=str(Path(sys.executable).resolve()),MadGraphDirectory=str(args.madgraph.resolve()),Points=100000)
            m.update(Class=new,Precision='Double');(d/'manifest.json').write_text(json.dumps(m,indent=2))
            (d/'benchmark-amplitudes.json').write_text(json.dumps({'PolePreference':'All'+form.title(),'ProcessSourceSHA256':hashlib.sha256((proc/'process.cpp').read_bytes()).hexdigest()},indent=2))
            leaves.append(str(d))
        key=('HEPCAT_'+form.upper()+'_PROCESS_DIRECTORIES') if four else 'HEPCAT_PROCESS_DIRECTORIES'
        opts.append('-D'+key+'='+';'.join(leaves))
    build=args.output/('timing-build-'+args.form)
    execute('cmake','-S',from_backend/'four-fermion' if four else from_backend,'-B',build,'-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=OFF','-DSPINAS_ROOT='+str(args.spinas.resolve()),'-DSPINAS_LIBRARY='+str(library/'libspinas.a'),'-DCALCHEP_ROOT='+str(args.calchep.resolve()),*opts)
    execute('cmake','--build',build,'--parallel',args.jobs)
    d=args.output/'timing-results'/('four' if four else args.form);d.mkdir(parents=True,exist_ok=True)
    exe='qed_four_fermion_benchmark' if four else 'qed_photon_benchmark'
    seed=1794010385397612000 if four else 1793918752098091000
    execute(build/exe,'--points','100000','--repeats','9','--warmup','100','--seed',seed,'--energy','100','--output',d/'timings')
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('study',choices=['catalog','high','timing','six-points','fixed-reference'])
    p.add_argument('--repository',type=Path);p.add_argument('--spinas',required=True,type=Path);p.add_argument('--output',required=True,type=Path)
    p.add_argument('--mode',choices=['float','double','extended'],default='double')
    p.add_argument('--arch',help='On macOS use x86_64 for x87 extended and its same-target controls.')
    p.add_argument('--form',choices=['physical','spurious','common'],default='physical')
    p.add_argument('--code',default='eeAA');p.add_argument('--points',type=Path);p.add_argument('--values',type=Path);p.add_argument('--result',type=Path)
    p.add_argument('--photons',type=int);p.add_argument('--restore',action='store_true')
    p.add_argument('--calchep',type=Path);p.add_argument('--madgraph',type=Path);p.add_argument('--mg-library',type=Path)
    p.add_argument('--cache-amplitudes',action='store_true',help='Reuse six-point complex amplitudes across distinct spin sums at the same momenta.')
    p.add_argument('--cache-spins',action='store_true',help='Reuse partial spin contractions for the six-fermion replay.');p.add_argument('--low-energy',action='store_true');p.add_argument('--jobs',type=int,default=2);p.add_argument('--cxx',default='clang++')
    a=p.parse_args();a.output=a.output.resolve();a.output.mkdir(parents=True,exist_ok=True)
    repo=checkout(a.repository);raw=sources(a.output)
    if a.study=='timing':return timings(raw,a,repo)
    if not a.result:raise ValueError('Supply --result PATH for numerical output.')
    if a.study=='catalog':
        if not a.points:raise ValueError('Supply --points for the saved momentum CSV.')
        execute(process_binary(raw,a,repo),a.points,a.result);return
    if a.study=='fixed-reference':
        if not a.mg_library or not a.points:raise ValueError('Supply --mg-library and --points.')
        if a.code=='eeeeee':execute(sys.executable,HERE/'eval-mg.py',a.points,a.mg_library,a.result);return
        exe=a.output/'mg-helicities';execute(a.cxx,'-std=c++17','-O2',HERE/'helicities.cpp','-o',exe)
        execute(exe,a.code.count('e'),a.code.count('A'),a.mg_library,a.points,a.result);return
    lib,flags=precision_library(a,repo,a.mode)
    if a.study=='six-points':
        proc=raw/'common/eeeeee';exe=a.output/'generate-six'
        execute(a.cxx,*flags,'-I'+str(proc),'-I'+str(lib/'include'),HERE/'generate-six.cpp',proc/'process.cpp',lib/'libspinas.a','-o',exe)
        execute(exe,a.result,100000,'1.5' if a.low_energy else '100','6' if a.low_energy else '100',2026110806);return
    if a.photons not in [5,6,7,8] or not a.points or not a.values:raise ValueError('The high study requires --photons N --points CSV --values CSV.')
    if a.restore and (a.photons!=8 or a.mode!='extended'):raise ValueError('The restored-input study used the eight-photon extended build.')
    exe=a.output/('high-'+a.mode+('-'+a.arch if a.arch else ''))
    execute(a.cxx,*flags,'-I'+str(repo/'tests/benchmarks'),'-I'+str(lib/'include'),(HERE/'high-cached.cpp' if a.mode=='extended' or a.photons==8 else HERE/'high.cpp'),lib/'libspinas.a','-lz','-o',exe)
    execute(exe,a.photons,a.points,a.values,a.result,int(a.restore),1.5 if a.photons==8 else 1)
if __name__=='__main__':main()
