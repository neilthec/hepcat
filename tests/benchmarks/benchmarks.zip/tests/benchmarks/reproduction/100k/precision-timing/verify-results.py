#!/usr/bin/env python3
"""Check that every published precision and timing calculation contains its full sample."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path


def read_json(path):
    return json.loads(path.read_text())


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',type=Path,default=Path(__file__).resolve().parent)
    directory=parser.parse_args().directory
    results=directory/'results'
    for name,digest in read_json(directory/'source-sha256.json').items():
        if hashlib.sha256((directory/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('Source digest changed: '+name)

    modes=('float','double','extended')
    catalog={f'{code}-{form}-{mode}' for code in ('eeAA','eeAAA','eeAAAA','eeee','eeeeA','eeeeAA')
             for form in ('physical','spurious') for mode in modes}
    catalog|={f'{code}-common-{mode}' for code in ('eeeeee','six-control') for mode in modes}
    catalog_files={path.stem:path for path in (results/'summary-catalog').glob('*.json')}
    assert set(catalog_files)==catalog
    for label,path in catalog_files.items():
        record=read_json(path)
        assert record['points']==100000 and record['errors']==0
        assert math.isfinite(record['full_max']) and 0<=record['above1e-7']<=100000
        assert len(record['sectors'])==2**record['code'].count('A')
        assert all(1<=entry['point']<=100000 for entry in record['sectors'])

    high={f'N{n}-{m}' for n in range(5,9) for m in modes}|{'N8-native','N8-extended-restored'}
    high_files={path.stem:path for path in (results/'summary-high').glob('*.json')}
    assert set(high_files)==high
    for path in high_files.values():
        record=read_json(path)
        assert record['points']==100000 and record['nonfinite']==0
        for key,entry in record['stats'].items():
            if path.stem.endswith('-restored') and key in ('p_mg','s_mg'):
                assert entry['point'] is None
                continue
            assert 1<=entry['point']<=100000
            assert math.isfinite(entry['max']) and entry['max']>=0
            assert 0<=entry['above1e-7']<=entry['above1e-12']<=100000

    for form in ('physical','spurious'):
        for mode in ('native','double','extended','restored'):
            metadata=read_json(results/'public-replay'/mode/form/'metadata.json')
            assert metadata['points']==100000 and metadata['input_bits_verified']
            assert metadata['bits']==(64 if mode in ('extended','restored') else 53)
    report=read_json(results/'public-comparison.json')
    assert report['points']==report['native_spurious_rate_bits_reproduced']==100000
    independent=read_json(results/'independent-input-digests.json')
    expected={f'positive-N{n}-{kind}.csv.gz' for n in range(5,9) for kind in ('points','values')}
    assert set(independent)==expected|{'model-default-spurious-8-MadGraph.csv'}
    assert all(len(source['decompressed_sha256'])==64 for source in independent.values())
    for name in ('native-physical','native-spurious','double-physical','double-spurious',
                 'extended-physical','extended-spurious','restored-forms'):
        assert report['above_1e-7'][name]==len(report['failing_indices'].get(name,[]))
        assert 1<=report['worst_indices'][name]<=100000

    current=results/'current-physical'
    comparison=read_json(current/'comparison.json')
    assert comparison['points']==comparison['retained_original_madgraph_binary64']==100000
    assert set(comparison['unequal_rates_current_vs_original'])=={'native','double','extended','restored'}
    native=read_json(current/'native-summary.json')
    assert native['points']==100000 and native['seed']==1794448410592767000
    assert native['point']==comparison['worst_point']['native-current-vs-madgraph']
    for mode in ('double','extended','restored'):
        metadata=read_json(current/mode/'metadata.json')
        assert metadata['points']==100000 and metadata['input_bits_verified']
        assert metadata['mantissa_bits']==(53 if mode=='double' else 64)
    controls=read_json(current/'verification.json')
    assert controls['division_check_points']==1600
    assert {(r['mode'],r['points']) for r in controls['comparisons'] if r['input_bits_and_rate_exact']}=={
        (mode,n) for mode in ('double','extended','restored') for n in (16,128)}
    optimized=read_json(current/'optimized-direct-verification.json')
    assert {(r['mode'],r['points']) for r in optimized['comparisons'] if r['input_bits_and_rate_exact'] and r['direct_current_graph_optimization']=='-O2'}=={
        (mode,n) for mode in ('double','extended','restored') for n in (16,128)}
    graphs=read_json(current/'source-comparison.json')
    for name in ('process.cpp','process.hpp','spinas-runtime.hpp','madgraph-runtime.hpp'):
        assert graphs['spurious'][name]['current']==graphs['spurious'][name]['original']
    assert graphs['physical']['process.cpp']['current']==controls['source_sha256']==native['source_sha256']
    assert graphs['physical']['process.cpp']['current']!=graphs['physical']['process.cpp']['original']

    for form,photons in [('physical',[2,3,4]),('spurious',[2,3,4]),('four',[0,1,2])]:
        d=results/'timings'/form
        meta=read_json(d/'timings-metadata.json')
        assert meta['Status']=='COMPLETE' and meta['ValidatedRows']=='PASS'
        assert meta['Points']==100000 and meta['Repetitions']==9
        assert list(meta['CompletedPhotonCounts'])==photons
        with (d/'timings-repetitions.csv').open() as stream:
            rows=list(csv.DictReader(stream))
        names=sorted({row['backend'] for row in rows})
        assert len(names)==(4 if form=='four' else 3)
        for n in photons:
            for name in names:
                subset=[r for r in rows if r['backend']==name and int(r['photons'])==n]
                assert sorted(int(r['repetition']) for r in subset)==list(range(1,10))
                assert all(int(r['points'])==100000 and float(r['seconds'])>0 for r in subset)
    print(f'Verified {len(catalog_files)} catalog precision results, {len(high_files)} same-helicity results, '
          'eight original and four current-physical model-default comparisons, and all native timing sweeps.')


if __name__=='__main__':
    main()
