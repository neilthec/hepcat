#!/usr/bin/env python3
"""Compare the eight model-default evaluations on the same 100,000 point IDs."""
import argparse
import csv
import gzip
import json
import struct
from contextlib import ExitStack
from decimal import Decimal
from itertools import zip_longest
from pathlib import Path


def open_csv(path):
    return gzip.open(path, "rt", newline="") if path.suffix == ".gz" else path.open(newline="")


def relative(first, second):
    denominator = max(abs(first), abs(second))
    return abs(first - second) / denominator if denominator else Decimal(0)


def summarize(directory, reference):
    modes = ("native", "double", "extended", "restored")
    forms = ("physical", "spurious")
    ordered_keys = [(mode, form) for mode in modes for form in forms]
    counts, maxima, worst_points, failing, outliers = {}, {}, {}, {}, {}
    tolerance = Decimal("1e-7")

    def record(key, value, point):
        if not value.is_finite():
            raise ValueError(f"Nonfinite value for {key} at point {point}")
        counts[key] = counts.get(key, 0) + int(value > tolerance)
        if key not in maxima or value > maxima[key]:
            maxima[key] = value
            worst_points[key] = point
        if value > tolerance:
            failing.setdefault(key, []).append(point)

    points = 0
    with ExitStack() as files:
        streams = [csv.DictReader(files.enter_context(open_csv(reference)))]
        for mode, form in ordered_keys:
            path = directory / mode / form / "rates.csv.gz"
            streams.append(csv.DictReader(files.enter_context(open_csv(path))))
        for points, rows in enumerate(zip_longest(*streams), 1):
            if any(row is None or int(row["point"]) != points for row in rows):
                raise ValueError(f"Point ID or length mismatch at point {points}")
            mg = Decimal(rows[0]["madgraph_squared"])
            outputs = dict(zip(ordered_keys, rows[1:]))
            archived_rate = struct.pack(">d", float(rows[0]["hepcat"]))
            replayed_rate = struct.pack(">d", float(outputs["native", "spurious"]["rate"]))
            if archived_rate != replayed_rate:
                raise ValueError(f"The native spurious replay differs from the original graph at point {points}")
            errors = {}
            for mode, form in ordered_keys:
                if mode != "restored":
                    key = f"{mode}-{form}"
                    errors[key] = relative(Decimal(outputs[mode, form]["rate"]), mg)
                    record(key, errors[key], points)
            adjusted = [outputs["restored", form] for form in forms]
            disagreement = relative(*(Decimal(row["rate"]) for row in adjusted))
            record("restored-forms", disagreement, points)
            for row in adjusted:
                record("max-adjustment", Decimal(row["maximum_input_adjustment"]), points)
            if errors["native-spurious"] > tolerance:
                outliers[points] = {
                    "native_spurious": str(errors["native-spurious"]),
                    "extended_spurious": str(errors["extended-spurious"]),
                    "restored_forms": str(disagreement),
                }
    if points != 100000:
        raise ValueError(f"Expected 100,000 points, found {points:,}")
    return {
        "points": points,
        "native_spurious_rate_bits_reproduced": points,
        "maxima": {key: str(value) for key, value in maxima.items()},
        "above_1e-7": counts,
        "worst_indices": worst_points,
        "failing_indices": failing,
        "original_native_outliers": outliers,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replays", type=Path, required=True)
    parser.add_argument("--madgraph-rates", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = summarize(args.replays, args.madgraph_rates)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
