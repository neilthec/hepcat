// Evaluate the MadGraph photon-helicity sectors and its independently summed entry point.
#include <dlfcn.h>
#include <array>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <vector>
#include <limits>
using Eval=void(*)(const double*,const int*,double*);
int main(int argc,char** a){if(argc!=6)return 2;
 int f=std::stoi(a[1]),n=std::stoi(a[2]),legs=f+n;void* lib=dlopen(a[3],RTLD_NOW|RTLD_LOCAL);if(!lib){std::cerr<<dlerror();return 2;}
 auto init=(int(*)())dlsym(lib,"hepcat_mg_initialize");auto eval=(Eval)dlsym(lib,"hepcat_mg_evaluate");auto sum=(void(*)(const double*,double*))dlsym(lib,"hepcat_mg_evaluate_sum");
 if(!init||!eval||!sum||init()!=0)return 3;
 std::ifstream points(a[4]);std::ofstream out(a[5]);if(!points||!out)return 2;
 std::string line;std::getline(points,line);out<<std::setprecision(17)<<"point,total";
 for(int h=0;h<(1<<n);++h)out<<",h"<<h;out<<"\n";
 int count=0;double worst=0,norm=1/(4*std::tgamma(1+n));unsigned errors=0;
 while(std::getline(points,line)){++count;std::vector<double> momenta(4*legs);for(int i=0;i<legs;++i){
   if(i && !std::getline(points,line))return 5;const char* at=line.c_str();char* end;
   if(std::strtol(at,&end,10)!=count || *end!=',')return 5;at=end+1;if(std::strtol(at,&end,10)!=i+1 || *end!=',')return 5;
   for(int k=0;k<4;++k){at=end+1;momenta[i*4+k]=std::strtod(at,&end);}}
  double w=0,from=0;bool err=false;sum(momenta.data(),&w);out<<count<<','<<w*norm;
  for(int h=0;h<(1<<n);++h){double sector=0;std::vector<int> spins(legs);
    for(int j=0;j<n;++j)spins[f+j]=((h>>(n-j-1))&1)?-1:1;
    for(int m=0;m<(1<<f);++m){for(int j=0;j<f;++j)spins[j]=(m>>j)&1?1:-1;
      double s=0;eval(momenta.data(),spins.data(),&s);sector+=s;}
    err|=!std::isfinite(sector);out<<','<<norm*sector;from+=sector;}
  out<<'\n';double errw=std::abs(from-w)/std::max(std::abs(from),std::abs(w));worst=std::max(worst,errw);errors+=err || !std::isfinite(w);
 }
 std::cout<<count<<" points, "<<errors<<" errors, maximum summed/independent discrepancy "<<std::setprecision(17)<<worst<<"\n";
 return count==100000 && !errors && worst<1.e-12 ? 0:1;
}
