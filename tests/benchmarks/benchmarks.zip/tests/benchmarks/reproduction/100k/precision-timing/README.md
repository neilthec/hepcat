# QED precision and timing comparisons at 100,000 points

Each of the seven catalog processes has 100,000 phase-space points at 100 GeV.
Both forms and all photon-helicity contributions use the same momenta and
binary64 MadGraph reference. The six-fermion forms share one C++ expression.
A separate lower-energy control for six fermions uses 100,000 additional points.
The four high-multiplicity samples each have 100,000 points. A separate
100,000-point sample reproduces the eight-photon run with the model defaults.

## Inputs and working precision

The checksummed current-processes.zip contains the generated C++ sources used
in the paper, including the two restored helicity sectors. The driver verifies
every source-file hash before extracting it. Timing builds only rename classes
to allow both forms to link in one executable. The arithmetic driver changes
the external-momentum admission tolerance to account for the precision in
which the inputs are represented. It retains every point, helicity, spin
assignment and generated arithmetic expression.

All catalog samples use m = 0.0005 GeV and e = 0.31333. The timing and precision
samples use the same random stream for each process. The annihilation timing seed
is 1793918752098091000, the four-fermion seed is 1794010385397612000 and the
six-fermion seed is 2026110806. The stored decimal momentum components describe
binary64 values. All three builds first parse those values to binary64 and
then convert them to their working precision. Apple Silicon double and native
long double both have 53 significant bits. The Intel-compatible builds use the
SPINAS arithmetic types with 24, 53 and 64 significant bits. The latter is x87
extended. Isolated SPINAS builds use the publication's replay-precision.py.

Commands below run from this directory. Set REPO, SPINAS, CALCHEP, MG and WORK
to the HEPCAT checkout, SPINAS checkout, CalcHEP installation, MadGraph
installation and an output directory. The tested environment used macOS with
Apple Clang and x86_64 translation. On a native Intel platform whose long
double has 64 significand bits, omit the macOS --arch x86_64 flags. Use separate
working directories for different target architectures.

## Native timings

Run the three commands sequentially. We suspended our other QED calculations during this measurement. Unrelated applications and operating-system services continued running. The results/timings/resources.json record gives wall and process CPU time for each complete benchmark program, including its untimed setup and validation. Each uses nine serial
100,000-point sweeps per backend and multiplicity, with 100 unmeasured warmup
evaluations. The four-fermion benchmark checks the two representations together.
The paired annihilation builds check identical physical inputs and reproduce
the same independent reference rates before their medians are joined.

```sh
for form in physical spurious common; do
  python3 run.py timing --repository "$REPO" --spinas "$SPINAS" --calchep "$CALCHEP" --madgraph "$MG" --output "$WORK/native" --form "$form"
done
python3 compare-current.py "$WORK/native/timing-results"
python3 plot-photon-timings.py --input-directory "$WORK/native/timing-results" --output-directory "$WORK/figures"
python3 plot-four-fermion-timings.py --input "$WORK/native/timing-results/four/timings.csv" --output-directory "$WORK/figures"
```

The two-photon generator retains the direction drawn by RAMBO and imposes the
exact back-to-back kinematics of a two-body final state before rounding the
coordinates. The same binary64 values are supplied to all programs. The
accompanying benchmark.hpp contains this adjustment.

## Common-point catalog precision

For each x86_64 mode float, double and extended, evaluate physical and spurious forms of
eeAA, eeAAA, eeAAAA, eeee, eeeeA and eeeeAA. The timing files use the number of
external photons in their names. The annihilation points are in the physical
timing folder, and the four-fermion points are in four. The photon-free
six-fermion process is eeeeee and uses form common.

```sh
python3 run.py catalog --repository "$REPO" --spinas "$SPINAS" --output "$WORK/x86" --arch x86_64 --mode extended --form spurious --code eeAAAA --points "$WORK/native/timing-results/physical/timings-points-N4.csv" --result "$WORK/eeAAAA-spurious-extended.csv"
python3 run.py six-points --repository "$REPO" --spinas "$SPINAS" --output "$WORK/x86" --arch x86_64 --result "$WORK/six-points.csv"
python3 run.py catalog --repository "$REPO" --spinas "$SPINAS" --output "$WORK/x86" --arch x86_64 --mode extended --form common --code eeeeee --points "$WORK/six-points.csv" --result "$WORK/six-extended.csv"
```

Add --low-energy to six-points for the independent 1.5 to 6 GeV control. The
fixed-reference command accepts an independent MadGraph shared library prepared
for that process with m = 0.0005 GeV, e = 0.31333, zero widths and only particle
PDGs 11 and 22 allowed. The four-fermion external PDGs are 11,-11,11,-11 followed
by any photons. The six-fermion leg order is 11,-11,-11,11,-11,11.
The references divide the squared spin sum by 4 N! for one and two fermion
pairs, and by 16 for three pairs. The fixed-reference helper compares every
fixed-photon-helicity sum to the MadGraph complete sum.

```sh
python3 run.py fixed-reference --repository "$REPO" --spinas "$SPINAS" --output "$WORK/native" --code eeAAAA --points "$WORK/native/timing-results/physical/timings-points-N4.csv" --mg-library "$MG_EEAAAA_LIBRARY" --result "$WORK/mg-eeAAAA.csv"
```

## Five through eight photons

Use the points and rates from the all-positive amplitude checks. For N=5,6,7
the mass is 1 GeV and for N=8 it is 1.5 GeV. All use e = 1/3, centre-of-mass
energies from 10 to 100 GeV and seed 2026111900 + N. The four-momentum and
MadGraph files are read directly from their gzip archives. The physical
amplitude uses collected_physical_amplitude in all-positive-formulas.hpp.
Sum the four massive spins with all outgoing photons positive, using the raw
spin sum throughout. At eight photons, --restore runs the separately reported
test in which the extended-precision code enforces the kinematic constraints.

```sh
python3 run.py high --repository "$REPO" --spinas "$SPINAS" --output "$WORK/x86" --arch x86_64 --mode extended --photons 8 --points "$GENERAL/positive-N8-points.csv.gz" --values "$GENERAL/positive-N8-values.csv.gz" --result "$WORK/N8-extended.csv"
```

## Original model-default eight-photon sample

Use the 100,000-point seed 1794448410592767000 with matching native-validation
MadGraph rates. The original generated physical and spurious graphs are
distributed with tests/benchmarks/reproduction/generated-precision-evidence.zip.
Build the requested target using replay-generated-precision.py from that
directory. Run replay-public.py for each graph and target with the generated
executable and extracted fixture. It verifies every input bit, keeps contiguous
point IDs, writes resumable 500-point chunks, and joins all 100,000 points.
The original and adjusted momenta must be analyzed separately. At adjusted
momenta compare both formulas at the same new point.

```sh
python3 replay-public.py --executable "$BUILD/spurious-extended" --fixture "$BUILD/fixture" --input "$PUBLIC/spurious-8-points.csv" --output "$WORK/full-spurious-extended" --form spurious --mode extended
```

For the common-point comparison, put the eight output directories under
`$WORK/public-replay/MODE/FORM`, where MODE is native, double, extended or
restored, and FORM is physical or spurious. The summary checks the point IDs
in every stream and compares every native spurious rate bit-for-bit with
the independently regenerated original evaluation. It reports the two-form
difference at the adjusted momenta separately.

```sh
python3 summarize-model-default.py --replays "$WORK/public-replay" --madgraph-rates "$PUBLIC/spurious-8/rates.csv" --output "$WORK/public-comparison.json"
python3 verify-results.py
```

## Verified reuse of intermediate values

The extended-significand subset evaluator stores repeated momentum dot products,
spinor ratios, emission factors and subset leading products. It evaluates every
contributing sum and product in its original order. Each saved spin component
retains the same arithmetic. The supplied unmodified and cached drivers give
identical eight-photon rates and largest spin-component differences on the
timing-control points, including their constraint-restored versions. The cache
reduced the measured CPU time from 9.94 s to 2.95 s on 64 original eight-photon
points. This small run measures the cost of the optimization. The comparisons
reported in the paper each use 100,000 points. For parallel execution of
high-cached.cpp the QED_FIRST_POINT and QED_LAST_POINT environment variables
select inclusive original IDs. Supplying QED_LOCAL_SHARD=1 denotes an input
already sliced to that interval. Joining the slices requires consecutive IDs
1 through 100,000 with no omitted or repeated point.

For a faster model-default replay, build-graph-cache.py can process the exact
generated expression from the original fixture. It identifies the scalar shared
by the four massive-spin amplitudes and reuses identical complex-valued
subexpressions. Every node retains the operand order of the generated graph.
The builder refuses to use a graph until the new binary exactly reproduces the
archived output rates and original input bits. This check covers all 1,600
archived points for each 53-bit build, and each of the 16 original outliers for
the unchanged- and restored-momentum 64-bit builds. The 100,000-point study
uses the verified executable in place of the original binary. The physical
and spurious graphs have 31,159 and 53,178 distinct arithmetic operations.
On the 16 unchanged outliers the physical graph took 2.97 CPU seconds in the
original extended build and 0.39 CPU seconds in the cached build. The
corresponding times for the spurious graph were 4.17 and 0.73 CPU seconds.

For example, after generating the extended-precision baseline, use the inputs,
library and verification JSON from that build.

```sh
python3 build-graph-cache.py --fixture "$BUILD/fixture" --form spurious --mode extended --library "$BUILD/spinas/extended" --arch x86_64 --driver "$REPO/tests/benchmarks/reproduction/replay-generated-precision.cpp" --reference "$BUILD/spurious-extended.json" --output "$WORK/cached-spurious-extended"
python3 replay-public.py --executable "$WORK/cached-spurious-extended/extended" --fixture "$BUILD/fixture" --input "$PUBLIC/spurious-8-points.csv" --output "$WORK/full-spurious-extended" --form spurious --mode extended
```

The compact records under results/ contain per-family and per-precision
maxima, counts above tolerance, worst point IDs and input/output digests.
The larger per-point files can be regenerated from the recorded seeds,
original graphs and commands above. summary-catalog/ retains separate
helicity-relative and full-rate-normalized errors. summary-high/ retains
the largest spin-component and rate differences. timings/ contains all nine
individual passes per implementation and multiplicity. The original
sample provenance and the generated-graph checks are recorded separately
from the recurrence comparison.

For the six-fermion process only, add --cache-spins to the catalog command to
reuse partial contractions across assignments of the external spins. The
replay keeps the original operation tree and the summation order of the 64
squared amplitudes. The underlying original process is also available by
omitting the option. The cached evaluation matched every output bit on the
separate 128-point cost controls at both energies. The 100,000-point streams
then checked a further 1,000 consecutive overlapping points before joining
the original and faster evaluations.

The final high-multiplicity replay also reuses the spin-independent two-photon
factors and each product of an emission factor with its one-photon propagator
denominator. The ordered leading products reuse their shorter prefixes. On
the same 64 eight-photon inputs, the completed extended build used 2.66 CPU
seconds for the original momenta and 2.74 seconds after constraint restoration.
The first 512 points reproduced every output bit of the earlier cached evaluator
at six and seven photons and in both eight-photon controls. The same checks
on the 24- and 53-bit eight-photon binaries reproduced the 64-point baseline.

For eeAAAA and eeeeAA the optional --cache-amplitudes switch stores the
complex amplitude for each spin and helicity assignment at the current
momenta. This lets the precision driver use the same value in the complete
spin and helicity sum and the separate fixed-helicity sums. The double input
values, complex amplitude and order of each sum are preserved. The timed
native programs use the original exports. The results on 128 points per
form and process are bit-identical with and without this cache.

To regenerate the compact precision summaries, organize outputs under one
workspace. Put the original native benchmark outputs in timing-results/.
For the six one- and two-pair families, gzip each catalog result to
catalog-results/PROCESS-FORM/MODE.csv.gz and put the fixed-reference results in
catalog-reference-values/PROCESS/rates.csv.gz. Set PROCESS to the C++ code,
FORM to physical or spurious, and MODE to float, double or extended. For
the six-fermion samples, use six/ and six-control/ for the 100 GeV and
lower-energy points. Store MODE.csv, the program's standard output in MODE.log
and the independently normalized MadGraph values in six-mg-values.csv.
Use high/N5-float.csv.gz through high/N8-extended.csv.gz, plus
high/N8-native.csv.gz and high/N8-extended-restored.csv.gz for the extra
eight-photon controls. Recompute the summaries with the following command.

```sh
python3 summarize.py --workspace "$WORK"
```

For the generated x87 graphs, --cache-divisors can reuse the compiler
runtime's common work for each complex divisor at fixed momenta. The finite
branch rescales the two components of the divisor by the same exact binary
power and stores the sum of their squares. Each quotient retains its original
ordered numerator products, sum or difference and division. Its final binary
rescaling uses the stored power of two. Exceptional inputs fall back to the
ordinary complex division. An instrumented build evaluates both methods at
each division and rejects the cache on any bit difference for the 1,600
archived inputs. The original 16 exceptional rates are checked separately,
also with restored external momenta. The physical and spurious expressions
use 266 and 1,134 distinct complex divisors, respectively.

## Current eight-photon physical export on the original spurious-form stream

The notebook now emits a shorter evaluation of the physical formula at eight
photons. Its arithmetic graph has 5,643 spin-independent assignments, compared
with 14,211 in the archived graph. The current spurious process source and
header have the same SHA-256 digests as the archived files. Their common
validation header updates the default sample count to 100,000. The MadGraph
and spinor arithmetic helpers are identical.

Unpack current-eight-photon-physical.zip to obtain the exact current physical
source, header and runtime helpers. Use the replay-precision SPINAS libraries
and original input fixture described above. The compile command builds the
unedited current expression and an evaluator that retains its exact operand
order. It checks their output rates and all input momentum bits independently
at 128 archived points and all 16 native outliers in each of three modes.
For the constraint-restored mode it also compares every projected coordinate.
The instrumented x87 build additionally checks each cached division against
the compiler runtime on all 1,600 archived points. The independent unmodified
53-bit graph uses `-O0`, the production evaluations and both independent x87
controls use `-O2`, and all Intel builds disable floating-point contraction.
The independent 53-bit control at `-O2` also reproduced every rate bit for bit.
Use `--optimize-direct-double` to reproduce this additional control.

```sh
unzip -q current-eight-photon-physical.zip -d "$WORK/exports"
python3 compile-current-physical.py --export "$WORK/exports/physical-8" --fixture "$FIXTURE" --double-library "$X86_DOUBLE_SPINAS" --extended-library "$X86_EXTENDED_SPINAS" --driver "$REPO/tests/benchmarks/reproduction/replay-generated-precision.cpp" --arch x86_64 --output "$WORK/current-physical"
python3 replay-current-physical.py --points "$PUBLIC/spurious-8-points.csv" --parameters "$FIXTURE/inputs/parameters.csv" --double "$WORK/current-physical/cached/double" --extended "$WORK/current-physical/prepared/extended" --restored "$WORK/current-physical/prepared/restored" --output "$WORK/current-physical/rates"
python3 compare-current-physical.py --current-intel "$WORK/current-physical/rates" --current-native "$PUBLIC/current-physical-spurious-seed/rates.csv" --original-controls "$WORK/public-replay" --original-madgraph "$PUBLIC/spurious-8/rates.csv" --output "$WORK/current-physical/comparison.json"
```

The current native physical calculation uses the published native exporter
and model-default campaign driver at seed 1794448410592767000. Each current
physical comparison uses exactly the original spurious-form momentum stream.
The three unchanged-input runs compare with the original binary64 MadGraph
values. The projected run compares with the spurious expression evaluated on
the same adjusted momenta. Both the original and current graph results are
preserved under results/.
