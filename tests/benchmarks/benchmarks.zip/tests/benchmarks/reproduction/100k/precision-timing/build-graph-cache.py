#!/usr/bin/env python3
"""Build the model-default eight-photon replay while preserving the emitted complex arithmetic."""
import argparse
import ast
import hashlib
import json
import re
import subprocess
from pathlib import Path


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare_graph(source, dest):
    header = (source / 'process.hpp').read_text()
    code = (source / 'process.cpp').read_text()
    assert header.count('bool momenta_ready') == code.count('momenta_ready = true;') == 1
    header = header.replace('bool momenta_ready',
        'std::vector<cdouble> replay_nodes_;\n  bool replay_cached=false;\n'
        '  cdouble replay_scalar{};\n  bool momenta_ready')
    code = code.replace('momenta_ready = true;', 'replay_cached=false; momenta_ready = true;')
    begin = code.index('return ([&] { const auto _hepcat_v1', code.index('::amp_unchecked'))
    end = code.index('}());', begin) + len('}());')
    graph = code[begin:end]
    assignments = re.findall(r'const\s+auto\s+(_hepcat_v\d+)\s*=\s*([^;]+);', graph)
    assert len(assignments) >= 2
    last_scalar = assignments[-2][0]
    spin_node = assignments[-1][0]
    last = re.search(r'\bconst\s+auto\s+' + spin_node + r'\s*=', graph)
    if not last:
        raise ValueError('Cannot locate the final spin-dependent node in the export.')
    split = last.group()
    scalar, spin = graph[:last.start()], graph[last.end():]
    assert 'ds1' not in scalar and 'ds2' not in scalar
    endpoint = r'(?:a12a\.v\(ds1, ds2\)|point_product_\d+\[\(ds1\) > 0 \? 1 : 0\]\[\(ds2\) > 0 \? 1 : 0\])'
    assert len(re.findall(endpoint, spin)) == 1 and re.search(r'\b' + last_scalar + r'\b', spin)
    node_ids, names, inputs, operations = {}, {}, [], []

    def intern(key):
        if key not in node_ids:
            idx = len(node_ids)
            node_ids[key] = idx
            if key[0] == 'input':
                inputs.append((idx, key[1]))
            else:
                operations.append((idx, *key))
        return node_ids[key]

    operators = {ast.Add: 'A', ast.Sub: 'S', ast.Mult: 'M', ast.Div: 'D'}

    def convert(node):
        if isinstance(node, ast.Name):
            if node.id.startswith('_hepcat_v'):
                return names[node.id]
            if node.id.endswith('_v'):
                expr = node.id[:-2]
                assert re.fullmatch(r'[as][\d_]+[as]', expr)
                assert re.search(r'\bsproduct\s+' + expr + r'\s*;', header)
                return intern(('input', expr + '.v()'))
            assert re.fullmatch(r't[\d_]+|parameter_factor_\d+|point_product_\d+', node.id)
            assert re.search(r'\bcdouble\s+' + node.id + r'\s*;', header)
            return intern(('input', node.id))
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
            return intern(('N', convert(node.operand), 0))
        if isinstance(node, ast.BinOp) and type(node.op) in operators:
            return intern((operators[type(node.op)], convert(node.left), convert(node.right)))
        raise ValueError('Unsupported expression: ' + ast.dump(node))

    for name, expression in assignments[:-1]:
        expression = re.sub(r'\s+', ' ', expression).strip().replace('.v()', '_v')
        names[name] = convert(ast.parse(expression, mode='eval').body)
    schedule = dest / 'schedule.inc'
    schedule.write_text('\n'.join(f"{{{i},'{op}',{left},{right}}}," for i, op, left, right in operations))
    evaluate = [
        'if (!replay_cached) {',
        f'  if(replay_nodes_.empty())replay_nodes_.resize({len(node_ids)});',
        *[f'  replay_nodes_[{i}]={expr};' for i, expr in inputs],
        '''  struct Instruction { int out; char op; int left, right; };
  static const Instruction schedule[] = {
#include "schedule.inc"
  };
  for (const auto &ins:schedule) {
    const cdouble& a=replay_nodes_[ins.left];const cdouble& b=replay_nodes_[ins.right];
    switch(ins.op) {
      case 'A': replay_nodes_[ins.out]=a+b;break;
      case 'S': replay_nodes_[ins.out]=a-b;break;
      case 'M': replay_nodes_[ins.out]=a*b;break;
      case 'D': replay_nodes_[ins.out]=a/b;break;
      case 'N': replay_nodes_[ins.out]=-a;break;
    }
  }''',
        f'  replay_scalar=replay_nodes_[{names[last_scalar]}]; replay_cached=true; }}',
        split + spin.replace(last_scalar, 'replay_scalar').replace('}());', '')]
    (dest / 'process.cpp').write_text(code[:begin] + '\n'.join(evaluate) + code[end:])
    (dest / 'process.hpp').write_text(header)
    return {'generated_graph_sha256': sha256(source / 'process.cpp'),
            'generated_header_sha256': sha256(source / 'process.hpp'),
            'scalar_assignments': len(assignments)-1, 'operands': len(inputs),
            'cached_operations': len(operations), 'schedule_sha256': sha256(schedule)}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--fixture', type=Path, required=True)
    p.add_argument('--form', choices=('physical', 'spurious'), required=True)
    p.add_argument('--mode', choices=('double', 'native', 'extended', 'restored'), required=True)
    p.add_argument('--library', type=Path, required=True, help='Isolated SPINAS build directory')
    p.add_argument('--driver', type=Path, required=True, help='replay-generated-precision.cpp')
    p.add_argument('--reference', type=Path, required=True, help='Verified original graph replay JSON')
    p.add_argument('--arch')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--compiler', default='clang++')
    p.add_argument('--cache-divisors',action='store_true',help='Cache the compiler runtime denominator scaling after verifying every quotient on the original sample.')
    a=p.parse_args()
    a.output.mkdir(parents=True, exist_ok=True)
    evidence=prepare_graph(a.fixture/'graphs'/a.form, a.output)
    compilation=a.output
    if a.cache_divisors:
        if a.mode not in ('extended','restored'):
            raise ValueError('Prepared denominator reuse was verified for the 64-bit-significand builds.')
        import importlib.util
        module=Path(__file__).with_name('prepare-divisors.py')
        spec=importlib.util.spec_from_file_location('hepcat_replay_divisors',module)
        helper=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        compilation=a.output/'prepared-divisors'
        evidence['distinct_prepared_denominators']=helper.transform(a.output,compilation)

    contract='on' if a.mode=='native' else 'off'
    command=[a.compiler,'-std=c++11','-O2','-ffp-contract='+contract,'-DWITH_LONG_DOUBLE']
    if a.arch:
        command.extend(['-arch',a.arch])
    if a.mode=='restored':
        command.append('-DHEPCAT_REPLAY_PROJECT')
    for include in [compilation,a.fixture/'support',a.fixture,a.library/'include']:
        command.append('-I'+str(include))
    exe=a.output/a.mode
    subprocess.run([*command,str(compilation/'process.cpp'),str(a.driver),
                    str(a.library/'libspinas.a'),'-o',str(exe)],check=True)
    if a.cache_divisors:
        checked=a.output/(a.mode+'-instrumented')
        trial=a.output/(a.mode+'-all-division-checks.json')
        subprocess.run([*command,'-DVERIFY_X87_DIVISIONS',str(compilation/'process.cpp'),
                        str(a.driver),str(a.library/'libspinas.a'),'-o',str(checked)],check=True)
        subprocess.run([str(checked),str(a.fixture/'inputs/points.csv'),
                        str(a.fixture/'inputs/parameters.csv'),str(trial)],check=True)
        evidence['checked_each_division_points']=len(json.loads(trial.read_text())['Rates'])
        assert evidence['checked_each_division_points']==1600
    extended=a.mode in ('extended','restored')
    points=a.fixture/'inputs'/('failed-points.csv' if extended else 'points.csv')
    out=a.output/(a.mode+'-verification.json')
    subprocess.run([str(exe),str(points),str(a.fixture/'inputs/parameters.csv'),str(out)],check=True)
    result=json.loads(out.read_text())
    reference=json.loads(a.reference.read_text())
    expected=16 if extended else 1600
    if len(result['Rates'])!=expected or result['Rates']!=reference['Rates']:
        raise ValueError('Cached and original graphs disagree. Use the original executable for this target.')
    if result['MantissaBits']!=(64 if extended else 53):
        raise ValueError('The precision of the compiled library does not match the requested target.')
    evidence.update(mode=a.mode,original_rates_reproduced=expected,reference_sha256=sha256(a.reference),
                    input_sha256=sha256(points),retained_input_bits=True)
    (a.output/(a.mode+'-evidence.json')).write_text(json.dumps(evidence,indent=2)+'\n')


if __name__=='__main__':
    main()
