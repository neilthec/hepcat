#!/usr/bin/env python3
"""Evaluate three current physical eight-photon controls on one verified 100,000-point stream."""
import argparse
import concurrent.futures
import csv
import gzip
import hashlib
import itertools
import json
import os
import struct
import subprocess
import tempfile
from decimal import Decimal
from pathlib import Path


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(data)
    return h.hexdigest()


def number_bits(value):
    return struct.pack(">d", float(value)).hex()


def offsets(points, size):
    positions = []
    with points.open("rb") as stream:
        header = next(stream)
        for part in range(100000 // size):
            positions.append(stream.tell())
            for _ in range(size * 10):
                if not stream.readline():
                    raise ValueError(f"Short input stream in chunk {part}")
        if stream.readline():
            raise ValueError("Expected precisely 100,000 ten-leg configurations")
    return header, positions


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--points", required=True, type=Path)
    parser.add_argument("--parameters", required=True, type=Path)
    parser.add_argument("--double", required=True, type=Path)
    parser.add_argument("--extended", required=True, type=Path)
    parser.add_argument("--restored", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--jobs", type=int, default=4)
    args = parser.parse_args()
    size = 500
    modes = ("double", "extended", "restored")
    args.output.mkdir(parents=True, exist_ok=True)
    import fcntl
    lock = (args.output / ".run-lock").open("w")
    fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
    if all((args.output / mode / "metadata.json").is_file() for mode in modes):
        return
    header, positions = offsets(args.points, size)
    if args.jobs < 1:
        raise ValueError("Choose at least one worker")
    for mode in modes:
        (args.output / mode).mkdir(exist_ok=True, parents=True)
    with args.parameters.open() as stream:
        parameters = list(csv.DictReader(stream))
    expected_parameters = [number_bits(float.fromhex(row[key])) for row in parameters for key in ("real", "imaginary")]

    def evaluate(job):
        part, mode = job
        target = args.output / mode / f"{part:03d}.csv"
        if target.exists():
            return
        with args.points.open("rb") as src:
            src.seek(positions[part])
            lines = list(itertools.islice(src, size * 10))
        with tempfile.TemporaryDirectory(dir=args.output) as tmp:
            tmp = Path(tmp)
            local, report = tmp / "points.csv", tmp / "result.json"
            local.write_bytes(header + b"".join(lines))
            subprocess.run([getattr(args, mode), local, args.parameters, report], check=True)
            result = json.loads(report.read_text())
            expected_bits = 53 if mode == "double" else 64
            if result["MantissaBits"] != expected_bits or result["ParameterBits"] != expected_parameters:
                raise ValueError(f"Parameter or significand mismatch in {mode}")
            if result["NormalizationBits"] != number_bits(0.25) or len(result["Rates"]) != size:
                raise ValueError(f"Normalization or result length mismatch in {mode}")
            local_rates = tmp / "rates.csv"
            with local_rates.open("w") as out:
                out.write("point,rate,maximum_input_adjustment\n")
                for index, row in enumerate(result["Rates"]):
                    point_id = part * size + index + 1
                    raw = [v.strip() for line in lines[10 * index:10 * index + 10] for v in line.split(b",")[2:]]
                    if row["Point"] != point_id or row["MomentBits"] != [number_bits(v) for v in raw]:
                        raise ValueError(f"ID or momentum bit mismatch at {mode} point {point_id}")
                    adjustment = ""
                    if mode == "restored":
                        projected = [Decimal(value) for leg in row["ProjectedMomenta"] for value in leg]
                        adjustment = str(max(abs(Decimal.from_float(float(x)) - y) for x, y in zip(raw, projected)))
                    out.write(f"{point_id},{row['Squared']},{adjustment}\n")
            os.replace(local_rates, target)

    jobs = [(part, mode) for part in range(len(positions)) for mode in modes]
    with concurrent.futures.ThreadPoolExecutor(args.jobs) as pool:
        for index, _ in enumerate(pool.map(evaluate, jobs), 1):
            if index % 30 == 0:
                print(f"Completed {index} of {len(jobs)} chunks", flush=True)
    source_hash = digest(args.points)
    for mode in modes:
        d = args.output / mode
        output = d / "rates.csv.gz"
        raw_hash = hashlib.sha256()
        rows = 0
        with gzip.open(d / "joining.gz", "wb", compresslevel=1) as target:
            for part in range(len(positions)):
                with (d / f"{part:03d}.csv").open("rb") as shard:
                    heading = next(shard)
                    if heading != b"point,rate,maximum_input_adjustment\n":
                        raise ValueError(f"Unexpected heading in part {part}")
                    if part == 0:
                        target.write(heading)
                        raw_hash.update(heading)
                    for line in shard:
                        rows += 1
                        if int(line.split(b",", 1)[0]) != rows:
                            raise ValueError(f"Nonconsecutive IDs in part {part}")
                        target.write(line)
                        raw_hash.update(line)
        if rows != 100000:
            raise ValueError(f"Incomplete {mode} result")
        os.replace(d / "joining.gz", output)
        metadata = {"points": rows, "mode": mode, "mantissa_bits": 53 if mode == "double" else 64,
                    "input_bits_verified": True, "source_points_sha256": source_hash,
                    "parameter_file_sha256": digest(args.parameters), "evaluator_sha256": digest(getattr(args, mode)),
                    "rates_uncompressed_sha256": raw_hash.hexdigest()}
        (d / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")


if __name__ == "__main__":
    main()
