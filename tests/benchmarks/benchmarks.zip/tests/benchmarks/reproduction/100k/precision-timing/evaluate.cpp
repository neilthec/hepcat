// Evaluate one generated QED representation on a common stream of saved binary64 momenta.
// Copyright (C) 2026 Neil Christensen, SPDX-License-Identifier: GPL-3.0-or-later
#include "process.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>

using Process=hepcat_generated::PROCESS;
using Value=ldouble;

int main(int argc, char** argv) {
  if (argc!=3) { std::cerr<<"evaluate points.csv results.csv\n";return 2; }
  std::ifstream input(argv[1]);
  std::ofstream output(argv[2]);
  if(!input || !output) throw std::runtime_error("Cannot open precision input or output");
  Process process;
  process.set_widths_enabled(false);
  const auto helicities=Process::helicity_configurations();
  std::string line;
  std::getline(input,line);
  output<<std::setprecision(std::numeric_limits<Value>::max_digits10)<<"point,total";
  for(std::size_t h=0;h<helicities.size();++h) output<<",h"<<h;
  output<<"\n";
  std::size_t count=0,failed=0;
  while(std::getline(input,line)){
    ++count;
    Process::Momenta point{};
    for(std::size_t leg=0;leg<point.size();++leg){
      if(leg && !std::getline(input,line)) throw std::runtime_error("Incomplete input point");
      std::istringstream row(line);std::string x;
      std::getline(row,x,',');if(std::stoul(x)!=count) throw std::runtime_error("Unexpected input point");
      std::getline(row,x,',');if(std::stoul(x)!=leg+1) throw std::runtime_error("Unexpected input leg");
      for(auto& c:point[leg]){std::getline(row,x,',');c=static_cast<Value>(std::stod(x));}
    }
    output<<count;
    try{
      process.set_momenta(point);
      auto w=process.amp2();
      if(!std::isfinite(w)) throw std::runtime_error("Nonfinite total");
      std::array<Value,Process::helicity_count> fixed{};
      if constexpr(Process::helicity_count==1) { fixed[0]=w; }
      else for(std::size_t h=0;h<helicities.size();++h){
        auto spin=helicities[h];
        std::array<std::size_t,Process::leg_count> massive{};
        std::size_t n=0;
        for(std::size_t i=0;i<spin.size();++i)if(spin[i]==0)massive[n++]=i;
        Value sum=0;
        for(std::size_t a=0;a<(std::size_t(1)<<n);++a){
          for(std::size_t k=0;k<n;++k)spin[massive[k]]= (a>>k)&1 ? 1:-1;
          sum+=std::norm(process.amp(spin));
        }
        fixed[h]=sum*(Process::symmetry_factor()/Process::incoming_spin_average());
        if (!std::isfinite(fixed[h])) throw std::runtime_error("Nonfinite fixed-helicity sum");
      }
      output<<','<<w;
      for(auto value:fixed)output<<','<<value;
    }catch(const std::exception&e){
      if(failed<5)std::cerr<<"Rejected point "<<count<<" "<<e.what()<<"\n";
      ++failed;for(std::size_t k=0;k<=helicities.size();++k) output<<",nan";
    }
    output<<"\n";
  }
  std::cout<<"Points="<<count<<" Failed="<<failed<<" Significand="<<std::numeric_limits<Value>::digits<<"\n";
  return (!input.eof() || !output || count!=100000 || failed) ? 1:0;
}
