"""Reuse the compiler runtime's denominator scaling in repeated x87 complex divisions."""
import re,sys
from pathlib import Path
def transform(src, dest):
 src,dest=Path(src),Path(dest);dest.mkdir(parents=True,exist_ok=True)
 hdr=(src/'process.hpp').read_text()
 src_cpp=(src/'process.cpp').read_text()
 token='std::vector<cdouble> replay_nodes_;'
 assert hdr.count(token)==1
 hdr=hdr.replace(token,'''struct PreparedDivisor {
    ldouble real{},imag{},norm{},scale_factor{};
    int exponent{};
    bool ordinary{};
  };
  std::vector<PreparedDivisor> replay_divisors_;
  '''+token)
 schedule=(src/'schedule.inc').read_text().splitlines();seen={};dlen=0;emit=[]
 for line in schedule:
  out,op,a,b=re.fullmatch(r"\{(\d+),'([MASND])',(\d+),(\d+)\},",line).groups();slot=-1
  if op=='D':
   if b not in seen:
    seen[b]=dlen;dlen+=1;first=1
   else:first=0
   slot=seen[b]
   if first:op='P'
  emit.append("{"+f"{out},'{op}',{a},{b},{slot}"+"},")
 (dest/'schedule.inc').write_text('\n'.join(emit))
 src_cpp=src_cpp.replace('  struct Instruction { int out; char op; int left, right; };', f'  if(replay_divisors_.empty())replay_divisors_.resize({len(seen)});\n  struct Instruction {{ int out; char op; int left, right, slot; }};')
 marker="      case 'D': replay_nodes_[ins.out]=a/b;break;"
 assert src_cpp.count(marker)==1
 src_cpp=src_cpp.replace(marker,'''      case 'P': {
        auto &den=replay_divisors_[ins.slot];
        const ldouble exponent=std::logb(std::fmax(std::fabs(b.real()),std::fabs(b.imag())));
        den.ordinary=std::isfinite(exponent);
        if(den.ordinary) {
          den.exponent=-static_cast<int>(exponent);
          den.real=std::scalbn(b.real(),den.exponent);
          den.imag=std::scalbn(b.imag(),den.exponent);
          den.norm=den.real*den.real+den.imag*den.imag;
          den.scale_factor=std::scalbn(ldouble(1),den.exponent);
          den.ordinary=std::isnormal(den.scale_factor);
        }
      }
      // Fall through to the same quotient calculation used for subsequent divisions.
      case 'D': {
        const auto &den=replay_divisors_[ins.slot];
        if(den.ordinary && std::isfinite(a.real()) && std::isfinite(a.imag())) {
          const ldouble real=(a.real()*den.real+a.imag()*den.imag)/den.norm;
          const ldouble imag=(a.imag()*den.real-a.real()*den.imag)/den.norm;
          // Multiplication by a normal power of two implements the runtime's final scalbn.
          const cdouble value(real*den.scale_factor,imag*den.scale_factor);
          if(std::isfinite(value.real()) && std::isfinite(value.imag())) {
#ifdef VERIFY_X87_DIVISIONS
            const auto original=a/b;
            if(std::memcmp(&original,&value,10) || original.imag()!=value.imag() ||
               std::signbit(original.imag())!=std::signbit(value.imag()))
              throw std::runtime_error("x87 division mismatch");
#endif
            replay_nodes_[ins.out]=value;break;
          }
        }
        replay_nodes_[ins.out]=a/b;break;
      }''')
 (dest/'process.hpp').write_text(hdr)
 (dest/'process.cpp').write_text('#include <cstring>\n'+src_cpp)
 return len(seen)
if __name__=='__main__':print(transform(*sys.argv[1:]))
