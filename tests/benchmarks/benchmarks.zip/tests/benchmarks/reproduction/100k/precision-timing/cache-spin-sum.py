"""Schedule each partial spin contraction once per distinct assignment of its spin labels."""
import argparse,ast,json,re
from pathlib import Path
from collections import Counter
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('source',type=Path,help='Directory containing an exported process.cpp and process.hpp')
parser.add_argument('destination',type=Path)
opts=parser.parse_args()
src=opts.source;dest=opts.destination;dest.mkdir(exist_ok=True,parents=True)
text=(src/'process.cpp').read_text();header=(src/'process.hpp').read_text()
cls=re.search(r'cdouble (\w+)::amp_unchecked',text).group(1)
lo=text.index('cdouble '+cls+'::amp_unchecked');start=text.index('{',lo)+1;end=text.index('\n}',start)
original=text[start:end];expr=' '.join(original.split())
pat=r'point_product_(\d+)\[\(ds(\d+)\) > 0 \? 1 : 0\]\[\(ds(\d+)\) > 0 \? 1 : 0\]'
expr=re.sub(pat,lambda m:'product_'+m[1]+'_'+m[2]+'_'+m[3],expr)
expr=re.sub(r'point_denominator_(\d+)\.divide\(',r'divide_\1(',expr)
defs=re.findall(r'const cdouble (spin_factor_\d+) = ([^;]+);',expr)
names={};ids={};ops=[];dep=[];complexval=[]
def intern(key,labels,ctype):
 if key not in ids:
  ids[key]=len(ops);ops.append(key);dep.append(tuple(sorted(set(labels))));complexval.append(ctype)
 return ids[key]
def decode(n):
 if isinstance(n,ast.Name):
  name=n.id
  if name in names:return names[name]
  if name.startswith('product_'):
   _,num,a,b=name.split('_');return intern(('read',num,a,b),[int(a),int(b)],True)
  assert re.search(r'\b(cdouble|ldouble) '+name+';',header),name
  return intern(('const',name),[],bool(re.search(r'\bcdouble '+name+';',header)))
 if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):
  a=decode(n.operand);return intern(('-',a),dep[a],complexval[a])
 if isinstance(n,ast.Call) and n.func.id.startswith('divide_'):
  a=decode(n.args[0]);return intern(('d'+n.func.id[7:],a),dep[a],True)
 if isinstance(n,ast.BinOp):
  a=decode(n.left);b=decode(n.right);op={ast.Add:'+',ast.Sub:'-',ast.Mult:'*',ast.Div:'/'}[type(n.op)]
  return intern((op,a,b),[*dep[a],*dep[b]],complexval[a] or complexval[b])
 raise ValueError(ast.dump(n))
for name,ex in defs:names[name]=decode(ast.parse(ex,mode='eval').body)
result=decode(ast.parse(expr.split('return ',1)[1].removesuffix(';'),mode='eval').body)
uses=Counter();grow=set()
for i,key in enumerate(ops):
 if key[0] in ('const','read'):continue
 for ch in key[1:]:
  uses[ch]+=1
  if len(dep[ch])<len(dep[i]):grow.add(ch)
cache={i for i in range(len(ops)) if ops[i][0] not in ('const','read') and ((i in grow and len(dep[i])<=4) or uses[i]>1)}
def idx(d,index):return ']['.join(index[k] for k in d)
def emit(i,index,skip):
 k=ops[i];op=k[0]
 if i in cache and i!=skip:return 'v'+str(i)+''.join('['+index[a]+']' for a in dep[i])
 if op=='read':return 'point_product_'+k[1]+'['+index[int(k[2])]+']['+index[int(k[3])]+']'
 if op=='const':return k[1]
 if len(k)==2:
  inside=emit(k[1],index,skip)
  return '(-'+inside+')' if op=='-' else 'point_denominator_'+op[1:]+'.divide('+inside+')'
 return '('+emit(k[1],index,skip)+op+emit(k[2],index,skip)+')'
if dep[result]!=tuple(range(1,7)):
 raise ValueError('This precision replay requires one six-fermion helicity branch.')
body=['ldouble result = 0;','if (!momenta_ready) throw std::logic_error("Call set_momenta first.");','prepare_all_point_cache();']
for i in sorted(cache|{result}):
 d=dep[i];indices={k:'s'+str(k) for k in d}
 if i in cache:body.append(('cdouble ' if complexval[i] else 'ldouble ')+'v'+str(i)+'[2]'*len(d)+';')
 loops=' '.join('for(int s'+str(k)+'=0;s'+str(k)+'<2;++s'+str(k)+')' for k in d)
 ex=emit(i,indices,i)
 val='v'+str(i)+''.join('[s'+str(k)+']' for k in d)+'='+ex+';' if i in cache else 'result+=std::norm('+ex+');'
 body+=[loops+' '+val]
body+='return result;', 
anch=text.index('ldouble '+cls+'::spin_sum()');a=text.index('{',anch)+1;b=text.index('\n}',a)
(dest/'process.cpp').write_text(text[:a]+'\n'+'\n'.join(body)+text[b:])
print('nodes',len(ops),'cached',len(cache),'stack',sum(32*2**len(dep[i]) for i in cache),'total spin ops',sum(2**len(dep[i]) for i in cache),flush=True)
(dest/'cache-provenance.json').write_text(json.dumps({
 'operation_nodes':len(ops),'cached_nodes':len(cache),
 'input_process_sha256':__import__('hashlib').sha256((src/'process.cpp').read_bytes()).hexdigest(),
 'spin_order':'Original ordered massive spin loops, with -1 before +1 for each external label.'
},indent=2)+'\n')
