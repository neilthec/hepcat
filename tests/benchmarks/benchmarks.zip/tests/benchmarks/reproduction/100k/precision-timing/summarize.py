import argparse,csv,gzip,hashlib,json,math,numbers,zipfile
from pathlib import Path
from decimal import Decimal,localcontext
from itertools import zip_longest
w=Path(__file__).resolve().parent
def inputfile(p):
 p=Path(p)
 return gzip.open(p,'rt',newline='') if p.suffix=='.gz' else p.open(newline='')
def read(p):
 with inputfile(p) as f:yield from csv.DictReader(f)
def rel(a,b):
 d=max(abs(a),abs(b))
 return float(abs(a-b)/d) if d else 0.
def percentile(a,f):
 s=sorted(a);at=(len(s)-1)*f;lo=int(at);return s[lo]+(s[min(lo+1,len(s)-1)]-s[lo])*(at-lo)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 return h.hexdigest()
def opened(p):
 return p if p.is_file() else p.with_suffix(p.suffix+'.gz')
def check_existing(p):
 return p.exists() and p.stat().st_size>0
def summary_catalog():
 dest=w/'summary-catalog';dest.mkdir(exist_ok=True)
 for code in ('eeee','eeAA','eeeeA','eeAAA','eeeeAA','eeAAAA','eeeeee','six-control'):
  f=(6 if code=='six-control' else code.count('e'));n=code.count('A')
  for form in (('common',) if f==6 else ('physical','spurious')):
   for mode in ['float','double','extended']:
    label=code+'-'+form+'-'+mode;out=dest/(label+'.json')
    if out.exists():continue
    if f==6:
     d=w/('six' if code=='eeeeee' else 'six-control')
     v=opened(d/(mode+'.csv'));ref=opened(d/'six-mg-values.csv');rname='madgraph'
     if not (d/(mode+'.log')).is_file() or 'Points=100000' not in (d/(mode+'.log')).read_text(): continue
    else:
     d=w/'catalog-results'/(code+'-'+form);v=d/(mode+'.csv.gz')
     if n:
      ref=w/'catalog-reference-values'/code/'rates.csv.gz';rname='total'
     else:ref=w/'timing-results/four/timings-values-N0.csv';rname='madgraph'
    if not (check_existing(v) and check_existing(ref)):continue
    if v.suffix=='.gz' and v.with_suffix('').exists():continue
    rows=0;errors=0;full=[];failures=0;worst=0;sector=[{'max':-1.} for _ in range(2**n)]
    summed_max=0.;normalized_max=0.
    with localcontext() as cx:
     cx.prec=40
     for val,mgr in zip_longest(read(v),read(ref)):
      if val is None or mgr is None:raise ValueError((label,'length mismatch'))
      rows+=1;assert int(val['point'])==int(mgr['point'])==rows
      a,b=Decimal(val['total']),Decimal(mgr[rname])
      if not(a.is_finite() and b.is_finite()):errors+=1;continue
      dr=rel(a,b);full.append(dr);failures+=dr>1e-7
      if len(full)==1 or dr>maxerr:maxerr=dr;worst=rows
      for i,rec in enumerate(sector):
       x=Decimal(val[f'h{i}']);y=Decimal(mgr[f'h{i}']) if n else b
       if not x.is_finite() or not y.is_finite():raise ValueError('nonfinite helicity')
       delta=abs(x-y);ds=rel(x,y);total=float(delta/abs(b)) if b else 0.
       if ds>rec['max']:rec.update(max=ds,point=rows,share=float(y/b) if b else 0.,normalized=total)
       normalized_max=max(normalized_max,total)
    if rows!=100000:raise ValueError((label,rows))
    record={'code':code,'form':form,'precision':mode,'points':rows,'errors':errors,'above1e-7':failures,'full_max':max(full),'worst_point':worst,'p99':percentile(full,.99),'median':percentile(full,.5),'sectors':sector,'max_sector_difference_normalized_to_total':normalized_max,'rates_sha256':digest(v),'madgraph_sha256':digest(ref)}
    out.write_text(json.dumps(record,indent=2));print(label,'%.4g'%record['full_max'],errors,flush=True)
def summary_high():
 dest=w/'summary-high';dest.mkdir(exist_ok=True)
 for p in (w/'high').glob('N*.csv.gz'):
  label=p.name[:-7];out=dest/(label+'.json')
  if p.with_suffix('').exists():continue
  if out.exists():continue
  stats={k:{'max':-1,'point':None,'above1e-7':0,'above1e-12':0} for k in ['p_mg','s_mg','p_s','complex','adjust']}
  skipped=0;rows=0
  for rows,r in enumerate(read(p),1):
   assert int(r['point'])==rows
   a,b=Decimal(r['physical']),Decimal(r['spurious'])
   if not(a.is_finite() and b.is_finite()):skipped+=1;continue
   measurements={'p_s':rel(a,b),'complex':float(r['complex_difference']),'adjust':float(r['max_input_adjustment'])}
   if r['madgraph']:
    mg=Decimal(r['madgraph']);measurements.update(p_mg=rel(a,mg),s_mg=rel(b,mg))
   for k,x in measurements.items():
    rec=stats[k];rec['above1e-7']+=x>1.e-7;rec['above1e-12']+=x>1.e-12
    if x>rec['max']:rec.update(max=x,point=rows)
  if rows!=100000:raise ValueError((label,rows))
  data={'name':label,'points':rows,'nonfinite':skipped,'stats':stats,'rates_sha256':digest(p)}
  out.write_text(json.dumps(data,indent=2));print(label,'%.4g'%stats['s_mg']['max'],skipped,flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Recompute catalog and high-multiplicity precision summaries.')
    parser.add_argument('--workspace',type=Path,required=True)
    args=parser.parse_args()
    w=args.workspace.resolve()
    summary_catalog()
    summary_high()

