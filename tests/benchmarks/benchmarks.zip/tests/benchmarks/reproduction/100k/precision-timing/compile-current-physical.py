#!/usr/bin/env python3
"""Compile and independently check the current physical eight-photon graph for the full replay."""
import argparse
import concurrent.futures
import importlib.util
import itertools
import json
import subprocess
from pathlib import Path


def module(filename):
    source = Path(__file__).with_name(filename)
    spec = importlib.util.spec_from_file_location(source.stem, source)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--export", required=True, type=Path, help="Generated current physical process directory")
    parser.add_argument("--fixture", required=True, type=Path, help="Original replay fixture with input coordinates")
    parser.add_argument("--double-library", required=True, type=Path)
    parser.add_argument("--extended-library", required=True, type=Path)
    parser.add_argument("--driver", required=True, type=Path, help="replay-generated-precision.cpp")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--compiler", default="clang++")
    parser.add_argument("--optimize-direct-double", action="store_true",
                        help="Apply -O2 to the separate direct 53-bit control as well")
    parser.add_argument("--arch", help="On macOS select x86_64 for the x87 extended target")
    args = parser.parse_args()
    dest = args.output
    dest.mkdir(parents=True, exist_ok=True)
    cached, prepared = dest / "cached", dest / "prepared"
    cached.mkdir(exist_ok=True)
    cache = module("build-graph-cache.py")
    schedule = cache.prepare_graph(args.export, cached)
    schedule["distinct_divisors"] = module("prepare-divisors.py").transform(cached, prepared)
    if schedule["generated_graph_sha256"] != "1b50f9a385e5231d4983b3e3b4adbbc46c5a1791b81751b3c9b143f2aa75f3d7":
        raise ValueError("The source differs from the current physical export used in the paper.")
    (dest / "cache.json").write_text(json.dumps(schedule, indent=2) + "\n")
    points = dest / "points-128.csv"
    with (args.fixture / "inputs/points.csv").open() as coordinates, points.open("w") as output:
        output.writelines(itertools.islice(coordinates, 1281))
    def build(job):
        mode, kind = job
        source = {"direct": args.export, "cached": cached, "prepared": prepared, "instrumented": prepared}[kind]
        target = dest / kind
        target.mkdir(exist_ok=True)
        library = args.double_library if mode == "double" else args.extended_library
        flags = [args.compiler, "-std=c++11", "-O2", "-ffp-contract=off", "-DWITH_LONG_DOUBLE"]
        if args.arch:
            flags += ["-arch", args.arch]
        if kind == "instrumented":
            flags.append("-DVERIFY_X87_DIVISIONS")
        for include in (source, args.export, args.fixture, library / "include"):
            flags.append("-I" + str(include))
        obj = target / (mode + ".o")
        direct_control = mode == "double" and kind == "direct" and not args.optimize_direct_double
        graph_flags = [*flags, "-O0"] if direct_control else flags
        subprocess.run([*graph_flags, "-c", source / "process.cpp", "-o", obj], check=True)
        for name in ([mode, "restored"] if mode == "extended" else [mode]):
            projection = ["-DHEPCAT_REPLAY_PROJECT"] if name == "restored" else []
            subprocess.run([*flags, *projection, args.driver, obj, library / "libspinas.a",
                            "-o", target / name], check=True)
    with concurrent.futures.ThreadPoolExecutor(3) as workers:
        list(workers.map(build, [("double", "direct"), ("extended", "direct"), ("double", "cached"),
                                 ("extended", "prepared"), ("extended", "instrumented")]))
    def evaluate(kind, mode, source, name):
        directory = dest / kind
        output = directory / (mode + "-" + name + ".json")
        subprocess.run([directory / mode, source, args.fixture / "inputs/parameters.csv", output], check=True)
        return json.loads(output.read_text())
    checks = []
    for mode in ("double", "extended", "restored"):
        for source, name in ((points, "128"), (args.fixture / "inputs/failed-points.csv", "outliers")):
            direct = evaluate("direct", mode, source, name)
            reused = evaluate("cached" if mode == "double" else "prepared", mode, source, name)
            if direct != reused or direct["MantissaBits"] != (53 if mode == "double" else 64):
                raise ValueError(f"Current graph and cached outputs differ in {mode} on sample {name}")
            flags = "-O0" if mode == "double" and not args.optimize_direct_double else "-O2"
            checks.append({"mode": mode, "points": len(direct["Rates"]), "inputs_sha256": cache.sha256(source),
                           "direct_current_graph_optimization": flags,
                           "input_bits_and_rate_exact": True})
    instrumented = evaluate("instrumented", "extended", args.fixture / "inputs/points.csv", "1600")
    if len(instrumented["Rates"]) != 1600:
        raise ValueError("Incomplete instrumented division check")
    record = {"comparisons": checks, "division_check_points": 1600,
              "source_sha256": schedule["generated_graph_sha256"], "header_sha256": schedule["generated_header_sha256"],
              "schedule_sha256": cache.sha256(cached / "schedule.inc"),
              "prepared_schedule_sha256": cache.sha256(prepared / "schedule.inc")}
    (dest / "verification.json").write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
