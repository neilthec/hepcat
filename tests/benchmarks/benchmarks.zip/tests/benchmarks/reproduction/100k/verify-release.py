"""Audit the distributed QED study files, sample sizes, and catalog comparison totals."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent


def read(file):
    return json.loads(file.read_text())

files = read(root / "file-hashes.json")
for name, checksum in files.items():
    path = (root / name).resolve()
    if not path.is_relative_to(root) or hashlib.sha256(path.read_bytes()).hexdigest() != checksum:
        raise ValueError(f"File checksum differs: {name}")
index = read(root / "summary.json")
for study in index["studies"]:
    minimum = study["smallest_sample_points"]
    if minimum < 100000 or study["points_across_samples"] < minimum * study["sample_count"]:
        raise ValueError(f'Incomplete sample in {study["study"]}')
    result = root / study["results"]
    if result.is_file() and hashlib.sha256(result.read_bytes()).hexdigest() != study["results_sha256"]:
        raise ValueError(f'Study result differs for {study["study"]}')
    if not result.exists():
        raise ValueError(f'Missing result for {study["study"]}')
catalog = read(root / "catalog/results.json")
rows = catalog["catalog"]
if len(rows) != 14 or any(row["ch_points"] != [100000] * 3 or row["mg_errors"] or row["ch_errors"] for row in rows):
    raise ValueError("Incomplete external-reference catalog")
for key, count in (("ch_mismatches", catalog["ch_over_tolerance"]), ("mg_mismatches", catalog["mg_over_tolerance"]), ("mg_points", catalog["mg_compared"])):
    if sum(row[key] for row in rows) != count:
        raise ValueError(f"Inconsistent catalog total for {key}")
for record in read(root / "all-positive/results.json")["current"]:
    if record["compared"] < 100000 or record["evaluation_errors"] or len(record["exceptions"]) != record["above_tolerance"]:
        raise ValueError(f'Incomplete notebook export: {record["photons"]} photons, {record["form"]}')
for n in (5, 6):
    exact = read(root / f"catalog/off-cut-{n}.json")
    charts = exact["charts"]
    if len(charts) != 4 or any(chart["physical_cuts_nonzero"] != 2**n-2 or
            any(chart["signed_differences_" + form] != [0]*4 for form in ("physical", "spurious"))
            for chart in charts):
        raise ValueError(f"Exact Feynman comparison differs at {n} photons")
subprocess.run([sys.executable, str(root / "general/verify.py")], check=True)
subprocess.run([sys.executable, str(root / "precision-timing/verify-results.py")], check=True)
print(f'Verified {len(files)} files and {len(index["studies"])} QED studies.')
