"""Compile the four restored QED process exports and check both reference generators."""

# Copyright (C) 2026 Neil Christensen
# SPDX-License-Identifier: GPL-3.0-or-later

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import subprocess
from tempfile import TemporaryDirectory


def run(command, directory, log, accepted=(0,)):
    with log.open("w") as stream:
        completed = subprocess.run(command, cwd=directory, stdout=stream, stderr=subprocess.STDOUT)
    if completed.returncode not in accepted:
        raise subprocess.CalledProcessError(completed.returncode, command)


def check_project(directory, spinas, points, seed):
    name = directory.name
    print(f"Checking {directory.parent.name}/{name}", flush=True)
    build = directory / "build"
    run(["cmake", "-S", ".", "-B", str(build), f"-DSPINAS_ROOT={spinas}",
         "-DHEPCAT_PREPARE_MADEVENT=OFF"], directory, directory / "configure.log")
    targets = [f"{name}_validate_{backend}" for backend in ("calchep", "madgraph")]
    run(["cmake", "--build", str(build), "--parallel", "2", "--target", *targets],
        directory, directory / "compile.log")
    args = ["--points", str(points), "--seed", str(seed)]
    with TemporaryDirectory(prefix="mixed-reference-", dir=directory) as temporary:
        report = Path(temporary) / "madgraph.json"
        with ThreadPoolExecutor(max_workers=2) as executor:
            tasks = [
                executor.submit(run, [str(build / targets[0]), *args], directory,
                                directory / "calchep.log", (0, 1)),
                executor.submit(run, [str(build / targets[1]), *args, "--report", str(report)],
                                directory, directory / "madgraph.log", (0, 1)),
            ]
            for task in tasks:
                task.result()
        result = summarize(directory, report, points, seed)
        report.replace(directory / "madgraph.json")
        return result


def summarize(directory, report, points, seed):
    name = directory.name
    ch = (directory / "calchep.log").read_text()
    count = re.search(r"Points requested/generated/compared: (\d+)/(\d+)/(\d+)", ch)
    discrepancies = re.search(r"Mismatches/errors: (\d+)/(\d+)", ch)
    if not count or set(map(int, count.groups())) != {points} or not discrepancies or int(discrepancies[2]):
        raise ValueError(f"Incomplete CalcHEP run for {directory}")
    maximum = re.search(r"Maximum relative/absolute error: ([^/]+)/", ch)
    mg = json.loads(report.read_text())
    rows = mg["Rows"]
    photons = name.count("A")
    expected = 2**photons
    unique = {tuple(row["Helicities"]) for row in rows}
    if (mg["Seed"] != seed or len(rows) != expected or len(unique) != expected
            or not all(row["RequestedPoints"] == row["GeneratedPoints"] == row["ComparedPoints"] == points
                       and row["EvaluationErrors"] == 0 for row in rows)):
        raise ValueError(f"Incomplete MadGraph run for {directory}")
    # Both the target and its opposite-helicity partner were replaced.
    affected = [row for row in rows if sum(h > 0 for h in row["Helicities"]) in {1, photons-1}]
    return {"pole_form": directory.parent.name, "photons": photons, "seed": seed,
            "relative_tolerance": 1e-7, "points": points, "calchep_spin_summed_points": points,
            "calchep_max_relative": float(maximum.group(1)),
            "madgraph_assignments": len(rows), "madgraph_assignment_points": len(rows) * points,
            "restored_mixed_assignments": len(affected),
            "madgraph_max_relative_restored_mixed": max(row["MaximumRelativeError"] for row in affected),
            "madgraph_max_relative": max(row["MaximumRelativeError"] for row in rows),
            "mismatches": int(discrepancies[1]) + sum(row["Mismatches"] for row in rows),
            "calchep_mismatches": int(discrepancies[1]),
            "madgraph_mismatches": sum(row["Mismatches"] for row in rows),
            "evaluation_errors": 0,
            "exported_cpp_sha256": hashlib.sha256((directory / "process.cpp").read_bytes()).hexdigest()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="HEPCAT_MIXED_OUTPUT used in the Wolfram export")
    parser.add_argument("--spinas", type=Path, required=True, help="SPINAS installation directory")
    parser.add_argument("--points", type=int, default=100000)
    parser.add_argument("--seed", type=int, default=861811)
    args = parser.parse_args()
    if args.points < 1:
        parser.error("--points must be positive")
    output = args.output.resolve()
    results = []
    for n in (3, 4):
        for form in ("physical", "spurious"):
            result = check_project(output / form / ("ee" + "A"*n), args.spinas.resolve(),
                                   args.points, args.seed)
            results.append(result)
            (output / "mixed-results.json").write_text(json.dumps(results, indent=2) + "\n")
            print(result, flush=True)
    raise SystemExit(1 if any(row["mismatches"] for row in results) else 0)
