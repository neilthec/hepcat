(* Check the two printed pole forms for three- and four-photon mixed helicities
   and export complete processes for the independent numerical checks.
   Run from a HEPCAT checkout with the paths listed in README.md. *)

(*
HEPCAT - High Energy Physics Constructive Amplitude Tool

Copyright (C) 2026 Neil Christensen

This file is part of HEPCAT.

HEPCAT is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HEPCAT is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HEPCAT.  If not, see <https://www.gnu.org/licenses/>.
*)
requiredPath[variableName_] := Module[{value = Environment[variableName]},
 If[!StringQ[value] || StringLength[value] == 0, Print["Set ", variableName]; Quit[2]];
 ExpandFileName[value]
];
root = ExpandFileName[Replace[Environment["HEPCAT_ROOT"], Except[_String] :> Directory[]]];
spinas = requiredPath["SPINAS_ROOT"];
calchep = requiredPath["CALCHEP_ROOT"];
mg = requiredPath["MADGRAPH_ROOT"];
output = requiredPath["HEPCAT_MIXED_OUTPUT"];
If[!FileExistsQ[FileNameJoin[{root, "source", "HEPCAT.wl"}]],
 Print["Run from the HEPCAT checkout or set HEPCAT_ROOT."]; Quit[2]];
If[!DirectoryQ[output], CreateDirectory[output, CreateIntermediateDirectories -> True]];
Get[FileNameJoin[{root,"source","HEPCAT.wl"}]];
$HistoryLength = 0;
mdl = ReadModel[FileNameJoin[{root,"models"}], 3];
fm = ReadModel[FileNameJoin[{root,"tests","reference-models","calchep"}], 2];
mm = ModelParameter[mdl,"Me"];
ee = ModelParameter[mdl,"EE"];

(* Spinor products, ordered chains and physical fermion denominators appearing in the paper. *)
spin[t_,k_]:=Spinor[If[k<=2,"Spin","Helicity"],t,k];
ag[i_,j_]:=SpinorChain[spin["Angle",i],spin["Angle",j]];
sq[i_,j_]:=SpinorChain[spin["Square",i],spin["Square",j]];
x[i_,p_,j_]:=SpinorChain[spin["Angle",i],Mom[p],spin["Square",j]];
ac[h_]:=SpinorChain[spin["Angle",h],Mom[1],Mom[2],spin["Angle",h]];
rt[k_]:=SpinorChain[spin["Square",k],Mom[1],Mom[2],spin["Square",k]];
den[i_,j_]:=Total[SpinorChain[spin["Square",i],Mom[1],Mom[#],spin["Square",j]]& /@ {i,5}];
t[p_,a__]:=PropDen[Mom[Multiparticle@@Sort[{p,a}]],mm];
s345=PropDen[Mom[Multiparticle[3,4,5]],0]; ww[h_]:=ag[1,h]ag[2,h]; zz=ag[1,2];

(* Three photons. *)
fphys=2 Sqrt[2]ee^3/(mm t[1,3]t[1,4]t[1,5])(
  mm^2 sq[3,4]^2/t[2,5]((t[1,5]+t[2,5])ww[5]+zz ac[5])
  +x[5,1,4]rt[3]/t[2,3](zz x[5,1,4]-sq[4,5]ww[5])
  +x[5,1,3]rt[4]/t[2,4](zz x[5,1,3]-sq[3,5]ww[5]));
fspur=2 Sqrt[2]ee^3/mm Total[Function[ij,With[{i=First[ij],j=Last[ij]},(1+t[1,i]/t[1,5]+t[2,j]/t[2,5])(
 x[5,1,i]x[5,2,j]/(t[1,i]t[2,j]ag[5,3]ag[5,4]) (ww[5]-zz x[5,1,i]x[5,2,j]/den[i,j])-
 mm^2 zz sq[i,j]^4/(s345 sq[i,5]sq[5,j]den[i,j]))]]/@{{3,4},{4,3}}];
(* Four photons. The three cyclic choices of j,b,c give six
   physical-pole terms and the two terms in the common numerator. *)
cycles = {{3,4,5},{4,5,3},{5,3,4}};
common = t[1,3]t[1,4]t[1,5]t[1,6];
spinTerm[j_] := sq[j,6]ww[6] - zz x[6,1,j];
physicalTerms[j_,b_,c_] := (
 mm sq[b,c]^2 x[6,1,j]spinTerm[j]/(t[1,j]t[1,6]t[2,b]t[2,c]t[1,j,6])
 - mm sq[b,c]^2 x[6,2,j](sq[j,6]ww[6]+zz x[6,2,j])/(t[1,b]t[1,c]t[2,6]t[2,j]t[1,b,c]));
firstNumerator[j_,b_,c_] := sq[b,c]^2 rt[j] t[2,b]t[2,c];
secondNumerator[j_,b_,c_] := t[2,j] x[6,1,j]spinTerm[j] rt[b]rt[c];
numerator = (mm^2((t[1,6]+t[2,6])ww[6]+zz ac[6]) Total[firstNumerator @@@ cycles]
 - t[2,6] Total[secondNumerator @@@ cycles]);
sphys = 4ee^4 (Total[physicalTerms @@@ cycles]
 + numerator/(mm common t[2,6]t[2,3]t[2,4]t[2,5]));

(* Three positive photons are partitioned among the two line endpoints. *)
js[a_,{}]=1;
js[a_,{i_}]:=x[6,a,i]/(ag[6,i]t[a,i]);
js[a_,{i_,j_}]:=(x[6,a,i]x[6,a,j]/(ag[6,i]ag[6,j])-mm^2 sq[i,j]^2/t[a,i,j])/(t[a,i]t[a,j]);
js[a_,{3,4,5}]:=Total[Function[ijk,With[{i=ijk[[1]],j=ijk[[2]],k=ijk[[3]]},js[a,{i,j}] (x[6,a,k]+ag[6,i]sq[i,k]+ag[6,j]sq[j,k])/ag[6,k]]]/@{{3,4,5},{4,5,3},{5,3,4}}]/t[a,3,4,5];
sspur=4ee^4/mm Total[Function[l,With[{r=Complement[{3,4,5},l]},(-1)^Length[r]js[1,l]js[2,r](zz (x[6,1,3]+Total[(ag[6,#]sq[#,3])&/@l])/sq[6,3]+ww[6])]]/@Subsets[{3,4,5}]];
(* Swapping angle and square spinors reverses the helicities. Rotate
   the labels to put the one positive photon at leg 3 in the parity partner. *)
partner[expression_,n_] := Module[{photonLabels,rot,move},
 photonLabels=Range[3,n+2]; rot=AssociationThread[photonLabels,RotateLeft[photonLabels]];
 move[i_Integer]:=Lookup[rot,i,i];
 expression /. {Spinor[k_,c:("Angle"|"Square"),i_Integer] :> Spinor[k,If[c==="Angle","Square","Angle"],move[i]],
   Mom[Multiparticle[indices__Integer]] :> Mom[Multiparticle@@Sort[move/@{indices}]],
   Mom[i_Integer] :> Mom[move[i]]}];
(* The same sample seed is used for the printed expression and its parity partner.
   Compare all massive-spin components directly with the signed Feynman sum. *)
signedResults = {};
checkFeynman[expression_,legs_,label_] := Module[{masses,channels,input,diagrams,report,record},
 masses = Thread[(Mass /@ Range[Length[legs]]) -> Join[{mm,mm},ConstantArray[0,Length[legs]-2]]];
 channels = FactorizationAmplitudeChannels[legs,mdl];
 input = ConstructiveDiagrams`Private`residueSimpleInputs[{masses,expression},channels,mdl];
 diagrams = DiagramAmplitudes[CreateDiagrams[legs,fm]];
 report = ConstructiveDiagrams`Private`amplitudeFeynmanReport[input,diagrams,mdl,3,956433+Length[legs]-2,
    ModelParameterRules[mdl],ModelParameterRules[fm],100,0];
 record = <|"pole_form"->label,"particles"->legs,"status"->report["Status"],
    "signed_ratio"->report["OverallSign"],"completed_points"->report["CompletedSamples"]|>;
 AppendTo[signedResults,record];
 Export[FileNameJoin[{output,"signed-checks.json"}],signedResults,"RawJSON"];
 If[record["status"]=!="PASS" || record["signed_ratio"]=!=1 || record["completed_points"]=!=3,
   Print["Signed Feynman comparison did not pass: ",record]; Quit[3]]
];
Do[
 model=ReadModel[FileNameJoin[{root,"models"}],modelID]; n=photonCount;
 proc="ee"<>StringRepeat["A",n]; preference=If[modelID==3,"physical","spurious"];
 target=FileNameJoin[{output,preference,proc}];
 If[FileExistsQ[FileNameJoin[{target,"manifest.json"}]],Print[target," already exists. Choose a new output directory."];Quit[2]];
 literal=Switch[{n,modelID},{3,3},fphys,{3,4},fspur,{4,3},sphys,{4,4},sspur];
 labels=Join[{"e","E"},ConstantArray["A.+",n-1],{"A.-"}];
 checkFeynman[literal,labels,preference];
 labels=Join[{"e","E","A.+"},ConstantArray["A.-",n-1]];
 checkFeynman[partner[literal,n],labels,preference];
 literal=literal /. p_ModelParameter :> ModelParameter[model,ModelParameterName[p]];
 entries=Table[
   legs=Join[{"e","E"},ConstantArray["A.+",n-neg],ConstantArray["A.-",neg]];
   amp=Which[neg==1,literal,neg==n-1,partner[literal,n],True,
       LookupAmplitude[MapIndexed[{#1,First[#2]}&,legs],model,False,{s1,s2,s3,s4}]];
   If[FreeQ[amp,_SpinorChain]||!FreeQ[amp,_Failure|_Missing|$Failed],Print["Invalid amplitude ",legs];Quit[3]];
   {legs,amp},{neg,0,n}];
 procOut=WriteSPINASProcess[target,{"e","E"}->ConstantArray["A",n],entries,model,
    "ProcessName"->proc,"Precision"->"LongDouble","SPINASDirectory"->spinas,
    "CalcHEPDirectory"->calchep,"CalcHEPModel"->{FileNameJoin[{root,"tests","reference-models","calchep"}],2},
    "CalcHEPAllowedParticles"->{11,22},"MadGraphDirectory"->mg,"MadGraphModel"->"sm-full",
    "MadGraphAllowedParticles"->{11,22},"Build"->False];
 If[FailureQ[procOut]||procOut===$Failed,Print[procOut];Quit[4]];
 manifest=Import[FileNameJoin[{target,"manifest.json"}],"RawJSON"];
 If[!AllTrue[{"CalcHEPValidation","MadGraphValidation"},manifest[#]["Status"]==="AVAILABLE"&],Print["Reference backend missing"];Quit[5]];
 Print["Exported ",preference," ",proc],
 {photonCount,{3,4}},{modelID,{3,4}}];
