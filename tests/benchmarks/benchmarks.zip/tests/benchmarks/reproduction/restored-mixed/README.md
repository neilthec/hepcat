# Mixed-helicity five- and six-point formulas

This check evaluates both printed pole forms for an electron, a positron and three or four photons. At each multiplicity one photon has the opposite helicity. The Wolfram script implements the displayed spinor expressions, reverses the helicities to obtain the parity partner, and compares both with independent Feynman diagrams on three exact phase-space configurations. The signed amplitude must agree for every massive-spin component.

For the numerical comparison, the script exports four complete processes. Each uses the printed formula, its parity partner and all their photon permutations. The other helicity sectors come from the corresponding QED model. CalcHEP checks the squared matrix element summed over spins and helicities. MadGraph checks each photon-helicity assignment separately, with the massive spins summed. The four exports therefore share some coordinates and physical helicity assignments.

## Run

Start at the root of the unpacked HEPCAT checkout, with the benchmark material extracted. Set the installation paths for SPINAS, CalcHEP and MadGraph. The SPINAS directory must include its compiled library. MadGraph needs Python 3.10 or later and a Fortran compiler. Use an empty directory for the generated processes.

```sh
export HEPCAT_ROOT="$PWD"
export SPINAS_ROOT=/path/to/spinas
export CALCHEP_ROOT=/path/to/calchep
export MADGRAPH_ROOT=/path/to/MG5_aMC
export HEPCAT_MIXED_OUTPUT="$(mktemp -d)"
check=tests/benchmarks/reproduction/restored-mixed
wolframscript -file "$check/export-printed-mixed.wl"
python3 "$check/verify-printed-mixed.py" "$HEPCAT_MIXED_OUTPUT" --spinas "$SPINAS_ROOT"
```

The driver defaults to 100,000 points per process and helicity assignment with seed 861811. Pass `--points` or `--seed` to change the numerical sample. Each generator uses relative tolerance `1e-7`. The Wolfram run writes `signed-checks.json`. The Python run writes `mixed-results.json` and saves `calchep.log` and `madgraph.json` under each process directory.

On the 100,000-point catalog sample, the four-photon spurious form has 50 fixed-helicity MadGraph differences above tolerance. The driver writes every completed report and returns a nonzero exit code when it observes a discrepancy. The [current catalog records](../100k/catalog/README.md) identify the affected helicities and give the precision retests.

The earlier bundled `results.json` includes the signed checks, the process summaries, the complete CalcHEP results and the MadGraph results for every labeled helicity assignment. Absolute build paths and the generator build logs are omitted from the bundled data.
