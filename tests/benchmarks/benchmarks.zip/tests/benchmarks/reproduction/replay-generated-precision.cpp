// Controlled arithmetic replay of an existing HEPCAT-generated process graph.
// CSV fields are parsed FIRST as binary64, then promoted to ldouble.
// The default preserves all inputs. HEPCAT_REPLAY_PROJECT enables the separate
// documented changed-kinematics control, used only for form-to-form comparison.
/*
HEPCAT - High Energy Physics Constructive Amplitude Tool

Copyright (C) 2026 Neil Christensen

This file is part of HEPCAT.

HEPCAT is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HEPCAT is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HEPCAT.  If not, see <https://www.gnu.org/licenses/>.
*/

#include "process.hpp"
#include "replay-config.hpp"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <map>
#include <vector>
#include <string>
#include <limits>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <stdexcept>

namespace {
std::vector<std::string> split(const std::string& line) {
  std::vector<std::string> out; std::istringstream in(line); std::string field;
  while(std::getline(in,field,',')) out.push_back(field);
  return out;
}
double exact64(const std::string& value) {
  char* end=nullptr;const double number=std::strtod(value.c_str(),&end);
  if(end==value.c_str()||(*end!='\0'&&*end!='\r')||!std::isfinite(number))
    throw std::runtime_error("Invalid finite binary64 input field");
  return number;
}
std::string bits64(double value) {
  std::uint64_t bits;std::memcpy(&bits,&value,sizeof(bits));std::ostringstream out;
  out<<std::hex<<std::setw(16)<<std::setfill('0')<<bits;return out.str();
}
std::string real_string(ldouble value) {
  std::ostringstream out;out<<std::setprecision(std::numeric_limits<ldouble>::max_digits10)<<value;return out.str();
}
#ifdef HEPCAT_REPLAY_PROJECT
ldouble spatial_norm2(const std::array<ldouble,4>& p) {
  return std::fma(p[1],p[1],std::fma(p[2],p[2],p[3]*p[3]));
}
ReplayProcess::Momenta project_true64(const ReplayProcess::Momenta& original,ldouble mass) {
  auto p=original;std::array<ldouble,4> total={};
  for(std::size_t leg=2;leg<p.size();++leg){p[leg][0]=std::sqrt(spatial_norm2(p[leg]));for(std::size_t u=0;u<4;++u)total[u]+=p[leg][u];}
  const ldouble invariant=total[0]*total[0]-spatial_norm2(total);
  if(!(invariant>0))throw std::runtime_error("Photon total not timelike");
  const ldouble invariant_mass=std::sqrt(invariant);ldouble rest_energy=0;
  for(std::size_t leg=2;leg<p.size();++leg){const auto old=p[leg];ldouble dot=0;for(std::size_t u=1;u<4;++u)dot=std::fma(total[u],old[u],dot);const ldouble shift=dot/(invariant_mass*(total[0]+invariant_mass))-old[0]/invariant_mass;for(std::size_t u=1;u<4;++u)p[leg][u]=old[u]+total[u]*shift;p[leg][0]=std::sqrt(spatial_norm2(p[leg]));rest_energy+=p[leg][0];}
  const ldouble energy=original[0][0]+original[1][0];if(!(energy>2*mass)||!(rest_energy>0))throw std::runtime_error("Bad projected energy");
  const ldouble scale=energy/rest_energy;for(std::size_t leg=2;leg<p.size();++leg)for(std::size_t u=0;u<4;++u)p[leg][u]*=scale;
  const ldouble beam=energy/2,momentum=std::sqrt((beam-mass)*(beam+mass));p[0]={{beam,0,0,momentum}};p[1]={{beam,0,0,-momentum}};return p;
}

#endif

struct SavedPoint {
  ReplayProcess::Momenta momenta={};std::array<bool,ReplayProcess::leg_count> seen={};
  std::vector<std::string> bits;
};
}
int main(int argc,char** argv) {
 try {
  if(argc!=4)throw std::runtime_error("Use replay-generated points.csv parameters.csv output.json");
  std::ifstream parameters(argv[2]);if(!parameters)throw std::runtime_error("Missing parameter CSV");
  std::string line;std::getline(parameters,line);ReplayProcess::Parameters values={};
  std::vector<bool> seen_parameters(values.size(),false);std::vector<std::string> parameter_bits;
  while(std::getline(parameters,line)) {
   if(line.empty())continue;auto f=split(line);if(f.size()!=3)throw std::runtime_error("Bad parameter row");
   const std::size_t i=std::stoull(f[0]);if(i>=values.size()||seen_parameters[i])throw std::runtime_error("Bad parameter index");
   const double re=exact64(f[1]),im=exact64(f[2]);values[i]=cdouble(static_cast<ldouble>(re),static_cast<ldouble>(im));
   parameter_bits.push_back(bits64(re));parameter_bits.push_back(bits64(im));seen_parameters[i]=true;
  }
  for(bool seen:seen_parameters)if(!seen)throw std::runtime_error("Incomplete parameter vector");
  std::ifstream input(argv[1]);if(!input)throw std::runtime_error("Missing momentum CSV");
  std::getline(input,line);if(!line.empty()&&line.back()=='\r')line.pop_back();
  if(line!="point,leg,E,px,py,pz")throw std::runtime_error("Bad momentum header");
  std::map<std::size_t,SavedPoint> points;
  while(std::getline(input,line)) {
   if(line.empty())continue;auto f=split(line);if(f.size()!=6)throw std::runtime_error("Bad momentum row");
   const std::size_t point=std::stoull(f[0]),leg=std::stoull(f[1]);
   if(leg<1||leg>ReplayProcess::leg_count||points[point].seen[leg-1])throw std::runtime_error("Bad leg index");
   for(std::size_t mu=0;mu<4;++mu){const double x=exact64(f[mu+2]);points[point].momenta[leg-1][mu]=static_cast<ldouble>(x);points[point].bits.push_back(bits64(x));}
   points[point].seen[leg-1]=true;
  }
  ReplayProcess process(values);process.set_widths_enabled(false);
  hepcat_spinas::MadGraphConfiguration config;
  config.spin2.assign(std::begin(replay_spin2),std::end(replay_spin2));
  const double normalization64=exact64(replay_normalization_binary64);
  config.normalization=static_cast<ldouble>(normalization64);
  std::ofstream out(argv[3]);if(!out)throw std::runtime_error("Cannot write replay JSON");
  out<<"{\"MantissaBits\":"<<std::numeric_limits<ldouble>::digits<<",\"LDoubleBytes\":"<<sizeof(ldouble)
#ifdef HEPCAT_REPLAY_PROJECT
     <<",\"InputPolicy\":\"Binary64 first; separate changed-kinematics projection control\",\"ParameterBits\":[";
#else
     <<",\"InputPolicy\":\"Parse binary64 then promote; no kinematic projection\",\"ParameterBits\":[";
#endif
  for(std::size_t i=0;i<parameter_bits.size();++i){if(i)out<<',';out<<'"'<<parameter_bits[i]<<'"';}
  out<<"],\"NormalizationBits\":\""<<bits64(normalization64)<<"\",\"Rates\":[";bool first=true;
  for(const auto& entry:points) {
   for(bool seen:entry.second.seen)if(!seen)throw std::runtime_error("Incomplete point");
   #ifdef HEPCAT_REPLAY_PROJECT
   const auto projected=project_true64(entry.second.momenta,process.masses()[0]);
   process.set_momenta(projected);
#else
   process.set_momenta(entry.second.momenta);
#endif
   ReplayProcess::Spins spins={};
   std::copy(std::begin(replay_helicities),std::end(replay_helicities),spins.begin());
   const ldouble rate=config.normalization*hepcat_spinas::madgraph_detail::sum_massive_spins(process,config,spins,0,
      [&](const ReplayProcess::Spins& state){return hepcat_spinas::madgraph_detail::squared_amplitude(process,state,0);});
   if(!std::isfinite(rate))throw std::runtime_error("Nonfinite replay amplitude");
   if(!first)out<<',';first=false;out<<"{\"Point\":"<<entry.first<<",\"Squared\":\""<<real_string(rate)<<"\",\"MomentBits\":[";
   for(std::size_t i=0;i<entry.second.bits.size();++i){if(i)out<<',';out<<'"'<<entry.second.bits[i]<<'"';}
   out<<"]";
#ifdef HEPCAT_REPLAY_PROJECT
   out<<",\"ProjectedMomenta\":[";
   for(std::size_t l=0;l<projected.size();++l){if(l)out<<',';out<<'[';
    for(std::size_t u=0;u<4;++u){if(u)out<<',';out<<'"'<<real_string(projected[l][u])<<'"';}out<<']';}
   out<<"]";
#endif
   out<<"}";
  }
  out<<"]}\n";return 0;
 }catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
}
