"""Compare the published and QED complex spin tensors at random scattering momenta."""
# Copyright (C) 2026 Neil Christensen
# SPDX-License-Identifier: GPL-3.0-or-later

import argparse
from functools import reduce
from itertools import product
import json
import math
import operator
from pathlib import Path

import numpy as np


J = np.array([[0, -1], [1, 0]])
L = -J
SPINS = np.array(list(product(range(2), repeat=4))).T


def directions(rng, count):
    cosine = rng.uniform(-1, 1, count)
    phi = rng.uniform(0, 2 * np.pi, count)
    sine = np.sqrt((1 - cosine) * (1 + cosine))
    return np.column_stack((sine * np.cos(phi), sine * np.sin(phi), cosine))


def momenta(rng, count, mass, photons):
    """Two massive incoming particles and a two-body decay of the outgoing pair."""
    energy = mass * np.exp(rng.uniform(np.log(8), np.log(80), count))
    half = energy / 2
    incoming = np.zeros((count, 4))
    incoming[:, 0] = half
    incoming[:, 3] = np.sqrt((half - mass) * (half + mass))
    other = incoming.copy()
    other[:, 3] *= -1
    if photons:
        pair_mass = rng.uniform(2 * mass, energy)
        photon_energy = (energy - pair_mass) * (energy + pair_mass) / (2 * energy)
        photon = np.column_stack((photon_energy, directions(rng, count) * photon_energy[:, None]))
        pair_energy = energy - photon_energy
    else:
        pair_mass = energy
    pair_half = pair_mass / 2
    relative = directions(rng, count) * np.sqrt((pair_half - mass) * (pair_half + mass))[:, None]
    legs = [incoming, other]
    for rest in (relative, -relative):
        if photons:
            pair_momentum = -photon[:, 1:]
            projection = np.sum(pair_momentum * rest, axis=1) / pair_mass
            boosted_energy = pair_energy / 2 + projection
            boosted_space = rest + pair_momentum * (0.5 + projection / (pair_energy + pair_mass))[:, None]
            legs.append(-np.column_stack((boosted_energy, boosted_space)))
        else:
            legs.append(-np.column_stack((pair_half, rest)))
    if photons:
        legs.append(-photon)
    return legs


def minkowski(p, q):
    return p[:, 0] * q[:, 0] - np.sum(p[:, 1:] * q[:, 1:], axis=1)


def sigma(p):
    time, x, y, z = p.T
    return np.stack((time + z, x - 1j * y, x + 1j * y, time - z), axis=1).reshape(-1, 2, 2)


def adj(m):
    return np.stack((m[:, 1, 1], -m[:, 0, 1], -m[:, 1, 0], m[:, 0, 0]), axis=1).reshape(-1, 2, 2)


def photon_angle(momentum):
    # Choose the larger diagonal entry as pivot. The two charts differ by a phase.
    energy, x, y, z = -momentum.T
    north = z >= 0
    pivot = np.sqrt(energy + np.abs(z))
    return np.stack((np.where(north, pivot, (x - 1j * y) / pivot),
                     np.where(north, (x + 1j * y) / pivot, pivot)), axis=1)


def freeze(node):
    return tuple(map(freeze, node)) if isinstance(node, list) else node


class Chart:
    def __init__(self, legs, mass, charge):
        self.legs, self.mass, self.charge = legs, mass, charge
        self.values, self.sums = {}, {}
        self.spinors = {"Angle": [], "Square": []}
        for i, p in enumerate(legs):
            if i < 4:
                angle = np.broadcast_to(np.eye(2) * math.sqrt(mass), (len(p), 2, 2))
                square = (L @ adj(sigma(p)) @ angle.swapaxes(1, 2) / mass).swapaxes(1, 2)
            else:
                angle = photon_angle(p)[:, None, :]
                square = -angle.conjugate()
            self.spinors["Angle"].append(angle)
            self.spinors["Square"].append(square)

    def momentum(self, labels):
        if labels not in self.sums:
            self.sums[labels] = sum(self.legs[i - 1] for i in labels)
        return self.sums[labels]

    def chain(self, left, i, insertions, right, j):
        row = self.spinors[left][i - 1]
        if left == "Angle":
            row = row @ J
        for n, labels in enumerate(insertions):
            matrix = sigma(self.momentum(labels))
            row = row @ (matrix if (left == "Angle") == (n % 2 == 0) else adj(matrix))
        column = self.spinors[right][j - 1].swapaxes(1, 2)
        if right == "Square":
            column = L @ column
        entries = row @ column
        return entries[:, SPINS[i - 1] if i <= 4 else 0, SPINS[j - 1] if j <= 4 else 0].reshape(len(row), -1)

    def evaluate(self, node):
        if node == "mass":
            return self.mass
        if node == "charge":
            return self.charge
        if isinstance(node, int):
            return node
        if node in self.values:
            return self.values[node]
        op, *args = node
        if op == "chain":
            value = self.chain(*args)
        elif op == "prop":
            p = self.momentum(args[0])
            value = (minkowski(p, p) - self.evaluate(args[1]) ** 2)[:, None]
        elif op == "dot":
            value = minkowski(self.momentum(args[0]), self.momentum(args[1]))[:, None]
        else:
            values = [self.evaluate(x) for x in args]
            operation = {"pow": operator.pow, "add": operator.add, "mul": operator.mul,
                         "div": operator.truediv, "complex": complex}[op]
            value = reduce(operation, values)
        self.values[node] = value
        return value


def run(formulas, mass, charge, photons, points, seed, batch, tolerance):
    rng = np.random.default_rng(seed)
    maximum, worst, failures, nonfinite = 0.0, None, 0, 0
    kin_max = 0.0
    for start in range(0, points, batch):
        count = min(batch, points - start)
        legs = momenta(rng, count, mass, photons)
        energy = legs[0][:, 0] + legs[1][:, 0]
        conserved = np.max(np.abs(sum(legs)), axis=1) / energy
        shells = [np.abs(minkowski(p, p) - (mass ** 2 if i < 4 else 0)) / energy ** 2
                  for i, p in enumerate(legs)]
        kin_max = max(kin_max, float(np.maximum.reduce([conserved, *shells]).max()))
        chart = Chart(legs, mass, charge)
        with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
            a, b = [chart.evaluate(formulas[key]) for key in ("candidate", "published")]
            difference = np.max(np.abs(a - b), axis=1)
            scale = np.max(np.maximum(np.abs(a), np.abs(b)), axis=1)
            errors = np.divide(difference, scale, out=difference.copy(), where=scale != 0)
        finite = np.isfinite(errors)
        nonfinite += int(np.count_nonzero(~finite))
        failures += int(np.count_nonzero((~finite) | (errors > tolerance)))
        if finite.any():
            peak = int(np.argmax(np.where(finite, errors, -1)))
            if float(errors[peak]) > maximum:
                maximum = float(errors[peak])
                worst = {"point": start + peak + 1, "all_incoming_momenta": [v[peak].tolist() for v in legs]}
    return {"photons": photons, "mass": mass, "charge": charge, "seed": seed, "points": points,
            "spin_components_per_point": 16, "maximum_relative_tensor_difference": maximum,
            "above_tolerance_or_nonfinite": failures, "nonfinite": nonfinite, "worst_point": worst,
            "maximum_scaled_kinematic_residual": kin_max,
            "passed": failures == 0 and kin_max < 1e-12}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("formulas", type=Path, help="JSON written by four-fermion-literature-validation.wl")
    parser.add_argument("output", type=Path)
    parser.add_argument("--points", type=int, default=100_000)
    parser.add_argument("--batch", type=int, default=256)
    parser.add_argument("--seed", type=int, default=261119)
    args = parser.parse_args()
    if min(args.points, args.batch) < 1:
        parser.error("points and batch must be positive")
    expressions = [{k: freeze(v) for k, v in item.items()} for item in json.loads(args.formulas.read_text())]
    report = {"tolerance": 1e-7, "batch": args.batch, "numpy": np.__version__, "runs": []}
    for photons, formulas in enumerate(expressions):
        for i, (mass, charge) in enumerate(((1, 1/3), (2/5, 2/7), (7/3, -1/4))):
            result = run(formulas, mass, charge, photons, args.points, args.seed + 10 * photons + i,
                         args.batch, report["tolerance"])
            report["runs"].append(result)
            args.output.write_text(json.dumps(report, allow_nan=False, indent=2) + "\n")
            print(photons, i, result["maximum_relative_tensor_difference"],
                  result["above_tolerance_or_nonfinite"], flush=True)
    return 0 if all(r["passed"] for r in report["runs"]) else 1


if __name__ == "__main__":
    raise SystemExit(main())
