"""Check safe, portable restoration of the publication validation bundles."""

# HEPCAT - High Energy Physics Constructive Amplitude Tool
#
# Copyright (C) 2026 Neil Christensen
#
# This file is part of HEPCAT.
#
# HEPCAT is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# HEPCAT is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with HEPCAT.  If not, see <https://www.gnu.org/licenses/>.

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
import warnings
import zipfile

PATH = Path(__file__).resolve().parents[1] / "run-checks.py"
SPEC = importlib.util.spec_from_file_location("publication_bootstrap", PATH)
BOOTSTRAP = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BOOTSTRAP)


def archive(path, files, *, overrides=None, extra=None, symlink=None):
    rows = []
    for name, content in files.items():
        row = {"path": name, "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()}
        row.update((overrides or {}).get(name, {}))
        rows.append(row)
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
        bundle.writestr(BOOTSTRAP.MANIFEST, json.dumps({"files": rows}))
        for name, content in files.items():
            if name == symlink:
                entry = zipfile.ZipInfo(name)
                entry.external_attr = (stat.S_IFLNK | 0o777) << 16
                bundle.writestr(entry, content)
            else:
                bundle.writestr(name, content)
        if extra:
            bundle.writestr(*extra)


class PublicationBootstrapTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="hepcat-publication-checks-")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name) / "relocated checkout without Git"
        self.root.mkdir()
        (self.root / "tests").mkdir()
        shutil.copy2(PATH, self.root / "tests/run-checks.py")
        self.files = {
            "tests/checks/run-wolfram-tests.py": b'TEST_SUITES = ("example.wl",)\nINTEGRATION_TEST_SUITES = ("integration.wl",)\n',
            "tests/checks/example.wl": b'Print["example"];\n',
            "tests/checks/test_small.py": b'import unittest\nclass Smoke(unittest.TestCase):\n def test_small(self): self.assertEqual(2+2,4)\n',
        }
        self.make_all()

    def make_all(self):
        archive(self.root / BOOTSTRAP.BUNDLES[0][0], self.files)
        archive(self.root / BOOTSTRAP.BUNDLES[1][0], {"tests/benchmarks/example.py": b"# benchmark source\n"})
        archive(self.root / BOOTSTRAP.BUNDLES[2][0], {"Documentation/English/example.nb": b"Notebook[{}]", "PacletInfo.wl": b"PacletObject[<||>]"})

    def invoke(self, *args):
        return subprocess.run([sys.executable, str(self.root / "tests/run-checks.py"), *args],
                              cwd=self.temporary.name, text=True, capture_output=True, timeout=20)

    def test_relocated_checkout_unpacks_without_git_or_original_paths(self):
        result = self.invoke("--unpack-only")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("6 restored", result.stdout)
        self.assertEqual((self.root / "tests/checks/example.wl").read_bytes(), self.files["tests/checks/example.wl"])
        self.assertTrue((self.root / "PacletInfo.wl").is_file())
        self.assertFalse((self.root / ".git").exists())
        second = self.invoke("--unpack-only")
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertIn("0 restored, 6 unchanged", second.stdout)

    def test_list_is_read_only_and_distinguishes_opt_in_suites(self):
        result = self.invoke("--list")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Default Wolfram suites (1)", result.stdout)
        self.assertIn("Opt-in integration suites (1)", result.stdout)
        self.assertFalse((self.root / "tests/checks/example.wl").exists())

    def test_python_only_runs_tests_without_a_wolfram_installation(self):
        result = self.invoke("--python-only", "--kernel", "/definitely/missing/kernel")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("Ran 1 test", result.stderr)
        self.assertNotIn("Running Wolfram suites", result.stdout)

    def test_changed_user_file_is_preserved_before_other_members_are_installed(self):
        target = self.root / "tests/checks/example.wl"
        target.write_text("User's edits")
        result = self.invoke("--unpack-only")
        self.assertEqual(result.returncode, 1)
        self.assertIn("Preserving changed local file", result.stderr)
        self.assertEqual(target.read_text(), "User's edits")
        self.assertFalse((self.root / "tests/checks/run-wolfram-tests.py").exists())
        self.assertFalse((self.root / "tests/benchmarks/example.py").exists())

    def test_all_bundle_hashes_are_checked_before_any_install(self):
        archive(self.root / BOOTSTRAP.BUNDLES[1][0], {"tests/benchmarks/example.py": b"damaged"},
                overrides={"tests/benchmarks/example.py": {"sha256": "0" * 64}})
        result = self.invoke("--unpack-only")
        self.assertEqual(result.returncode, 1)
        self.assertIn("SHA256 mismatch", result.stderr)
        self.assertFalse((self.root / "tests/checks/example.wl").exists())

    def test_traversal_absolute_and_backslash_paths_are_rejected(self):
        for name in ("../outside", "/outside", "tests/checks/../outside", "tests\\checks\\outside"):
            with self.subTest(name=name):
                archive(self.root / BOOTSTRAP.BUNDLES[1][0], {name: b"invalid"})
                with self.assertRaisesRegex(ValueError, "Unsafe archive path"):
                    BOOTSTRAP.unpack_bundles(self.root)
                self.assertFalse((self.root / "tests/checks/example.wl").exists())

    def test_symlinks_in_archive_or_destination_are_rejected(self):
        name = "tests/benchmarks/link"
        archive(self.root / BOOTSTRAP.BUNDLES[1][0], {name: b"/outside"}, symlink=name)
        with self.assertRaisesRegex(ValueError, "Unsupported archive member"):
            BOOTSTRAP.unpack_bundles(self.root)
        self.make_all()
        outside = Path(self.temporary.name) / "outside"
        outside.mkdir()
        (self.root / "Documentation").rename(self.root / "documentation-bundle-source")
        (self.root / "Documentation").symlink_to(outside, target_is_directory=True)
        shutil.copy2(self.root / "documentation-bundle-source/HEPCAT-Documentation.zip", outside)
        with self.assertRaisesRegex(ValueError, "symbolic link"):
            BOOTSTRAP.unpack_bundles(self.root)
        self.assertFalse((outside / "English").exists())

    def test_unlisted_and_out_of_scope_members_are_rejected(self):
        for files, extra, message in [
            ({"source/HEPCAT.wl": b"overwrite"}, None, "outside its bundle scope"),
            ({"tests/benchmarks/ok.py": b"ok"}, ("unexpected", b"bad"), "Undeclared archive members"),
        ]:
            with self.subTest(message=message):
                archive(self.root / BOOTSTRAP.BUNDLES[1][0], files, extra=extra)
                with self.assertRaisesRegex(ValueError, message):
                    BOOTSTRAP.unpack_bundles(self.root)

    def test_missing_bundle_and_invalid_timeout_have_actionable_errors(self):
        (self.root / BOOTSTRAP.BUNDLES[1][0]).unlink()
        result = self.invoke("--unpack-only")
        self.assertEqual(result.returncode, 1)
        self.assertIn("bundle is missing", result.stderr)
        result = self.invoke("--timeout", "nan")
        self.assertEqual(result.returncode, 2)
        self.assertIn("finite and positive", result.stderr)


if __name__ == "__main__":
    unittest.main()
