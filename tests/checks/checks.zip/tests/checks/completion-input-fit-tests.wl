(* Small input-derived completion proposals are hypotheses, not identities.
   Every accepted proposal must satisfy the full independent residue checks. *)

(*
HEPCAT - High Energy Physics Constructive Amplitude Tool

Copyright (C) 2026 Neil Christensen

This file is part of HEPCAT.

HEPCAT is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HEPCAT is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HEPCAT.  If not, see <https://www.gnu.org/licenses/>.
*)


root = DirectoryName[DirectoryName[DirectoryName[$InputFileName]]];
Global`$HEPCATpath = FileNameJoin[{root, "source"}];
Get[FileNameJoin[{$HEPCATpath, "HEPCAT.wl"}]];
Get[FileNameJoin[{root, "tests", "checks", "fixtures", "QED-5-point-residues.wl"}]];
checks = 0; failures = {};
SetAttributes[check, HoldRest];
check[name_, value_] := (checks++;
  If[!TrueQ[value], AppendTo[failures, name]; Print["FAIL: ", name]]);
ciZero[value_] := Together[value] === 0;
ciCanonical[value_, n_Integer : 4] :=
  ConstructiveDiagrams`Private`residueCanonicalPropagators[value, Range[n]];
(* Deliberately asymmetric overlap targets test fitting before Bose projection. *)
ciSettings[opts___] := Normal[Join[<|"Samples" -> 1, "ValidationSamples" -> 1,
  "RandomSeed" -> 11807, "TimeConstraint" -> 30, "MaxCorrectionTerms" -> 32,
  "ProgressReporting" -> False, "ReturnDetails" -> True,
  "BoseSymmetryGroups" -> {}|>, Association[{opts}]]];
ciFactor[input_, channels_, model_, opts___] := CompleteFactorization[
  input, channels, model, Sequence @@ ciSettings[opts]];
ciPass[report_] := AssociationQ[report] &&
  AllTrue[Lookup[report, "Channels", {}], #["Status"] === "PASS" &];
ciComplete[report_] := AssociationQ[report] && report["Status"] === "COMPLETE";
ciAttempts[report_] := Lookup[report, "InputFitAttempts", {}];
ciAttemptSpaces[report_] := Lookup[ciAttempts[report], "Mode", {}];

(* A real cubic scalar model supplies three independent simple poles. The
   overlapping records deliberately share exactly one signed, weighted term. *)
ciScalarModel = {{{"Scalar", "s", "s", 1, 0, ciMass, 0, 1, 1, "", ""}},
  {{"s", "s", "s", "", ciCoupling, 1}}, {}, {}};
ciScalarPairs = DiagramAmplitudes[CreateDiagrams[ConstantArray["s", 4], ciScalarModel]];
ciScalarChannels = FactorizationAmplitudeChannels[ConstantArray["s", 4], ciScalarModel];
ciScalarTerms = Last /@ ciScalarPairs;
ciScalarTree = Total[ciScalarTerms];
ciExternalRules = Thread[(Mass /@ Range[4]) -> ConstantArray[ciMass, 4]];
ciRules = {ciMass -> 1, ciCoupling -> 2, ciContact -> 7};
ciPair[expression_] := {ciExternalRules, expression};
ciA = ciScalarTerms[[1]]; ciB = ciScalarTerms[[2]]; ciC = ciScalarTerms[[3]];
ciOverlapInput = ciPair /@ {ciA + ciB, ciB + ciC};
ciNormalized[input_] := ConstructiveDiagrams`Private`completionNormalizeInput[
  input, ciScalarChannels, ciScalarModel];
ciProposal[input_, opts___] := ConstructiveDiagrams`Private`completionInputProposals[
  ciNormalized[input], opts];
ciDirection[proposal_, mode_] := Lookup[SelectFirst[proposal["Proposals"],
  #["Mode"] === mode &, <||>], "Direction", Missing["NoProposal"]];
(* The conservative timeout fallback retains one correlated input core
   without expanding inverse-propagator polynomials or freeing bare contacts. *)
ciCoreD1=PropDen[Mom[Multiparticle[1,3]],ciCoreMass];ciCoreD2=PropDen[Mom[Multiparticle[1,4]],ciCoreMass];
ciCoreNormalize[expressions_List]:=<|"ExternalMassRules"->{Mass[1]->ciCoreMass,Mass[2]->ciCoreMass,Mass[3]->0,Mass[4]->0},"Records"->(<|"Expression"->#|>&/@expressions),"Expression"->Total[expressions]|>;
ciCoreCollect[expressions_List]:=ConstructiveDiagrams`Private`completionCorrelatedInputProposals[ciCoreNormalize[expressions],2];
ciCoreReport=ciCoreCollect[{ciCoreContact}];check["bare contact remains fixed",ciCoreReport["Status"]==="AVAILABLE"&&ciCoreReport["RegularExpression"]===ciCoreContact&&ciCoreReport["Proposals"]==={}];
ciCoreReport=ciCoreCollect[{ciCoreA/ciCoreD1}];check["one pole remains one correlated direction",ciCoreReport["Status"]==="AVAILABLE"&&ciCoreReport["RegularExpression"]===0&&Length[ciCoreReport["Proposals"]]===1&&ciCoreReport["Proposals"][[1]]["Direction"]===ciCoreA/ciCoreD1&&ciCoreReport["Proposals"][[1]]["ColumnMode"]==="WholeCorrelatedColumn"];
ciCoreReport=ciCoreCollect[{ciCoreContact+ciCoreA/ciCoreD1+ciCoreB/ciCoreD2}];check["explicit additive contact remains fixed",ciCoreReport["RegularExpression"]===ciCoreContact&&ciCoreReport["Proposals"][[1]]["Direction"]===ciCoreA/ciCoreD1+ciCoreB/ciCoreD2];
ciCoreExpression=(ciCoreContact+ciCoreA/ciCoreD1)(ciCoreOtherContact+ciCoreB/ciCoreD2);ciCoreReport=ciCoreCollect[{ciCoreExpression}];check["contact inside factored product remains fixed",ciCoreReport["RegularExpression"]===ciCoreContact ciCoreOtherContact&&ciCoreReport["Proposals"][[1]]["Direction"]===ciCoreExpression-ciCoreContact ciCoreOtherContact];
check["factored product is not expanded",Head[First[ciCoreReport["PoleBearingByRecord"]]]===Plus&&LeafCount[First[ciCoreReport["PoleBearingByRecord"]]]<60];
ciCoreReport=ciCoreCollect[{ciCoreContact+ciCoreA/ciCoreD1,-ciCoreContact+ciCoreB/ciCoreD2}];check["individual regular records retained",ciCoreReport["RegularByRecord"]==={ciCoreContact,-ciCoreContact}&&ciCoreReport["RegularExpression"]===0&&Length[ciCoreReport["RecordCertificates"]]===2];
ciCoreReport=ciCoreCollect[{(ciCoreContact+ciCoreA/ciCoreD1)^10000}];check["large power stays one bounded whole column",ciCoreReport["Status"]==="AVAILABLE"&&ciCoreReport["RegularExpression"]===ciCoreContact^10000&&Length[ciCoreReport["Proposals"]]===1&&LeafCount[ciCoreReport["Proposals"][[1]]["Direction"]]<50];
ciCoreReport=ciCoreCollect[{ciCoreA/ciCoreD1^2}];check["higher inverse powers retained without dropping pole obligations",ciCoreReport["Status"]==="AVAILABLE"&&ciCoreReport["Proposals"][[1]]["Direction"]===ciCoreA/ciCoreD1^2];
ciCoreReport=ciCoreCollect[{ciCoreContact/ciCoreOpaqueDenominator+ciCoreA/(ciCoreD1 ciCoreOpaqueDenominator)}];check["non-propagator inverse constants stay in fixed regular part",ciCoreReport["RegularExpression"]===ciCoreContact/ciCoreOpaqueDenominator];
ciCoreReport=ciCoreCollect[{(ciCoreContact+ciCoreNumeratorCoefficient ciCoreD1)/ciCoreD2}];check["unmatched positive numerator propagator rejected",ciCoreReport["Status"]==="UNRESOLVED"&&ciCoreReport["Reason"]==="PositiveOrUnmappedInputPropagator"];
ciCoreReport=ciCoreCollect[{(ciCoreContact+ciCoreNumeratorCoefficient ciCoreD1)/ciCoreD1}];check["unexpanded numerator propagator rejected conservatively",ciCoreReport["Status"]==="UNRESOLVED"];
ciCoreReport=ciCoreCollect[{ciCoreD1/ciCoreD1}];check["already canceled propagator is an ordinary contact",ciCoreReport["Status"]==="AVAILABLE"&&ciCoreReport["RegularExpression"]===1&&ciCoreReport["Proposals"]==={}];
ciCoreReport=ciCoreCollect[{(1+1/ciCoreD1)^-1}];check["rational inverse-variable dependence rejected",ciCoreReport["Status"]==="UNRESOLVED"&&ciCoreReport["Reason"]==="UnsupportedInversePropagatorDependence"];
ciCoreReport=ciCoreCollect[{Sqrt[1+1/ciCoreD1]}];check["noninteger inverse-variable power rejected",ciCoreReport["Status"]==="UNRESOLVED"];
ciCoreReport=ciCoreCollect[{ciCoreOpaqueFunction[1/ciCoreD1]}];check["opaque dependence on inverse variables rejected",ciCoreReport["Status"]==="UNRESOLVED"];
ciCoreReport=ciCoreCollect[{ciCoreContact ciCoreD1}];check["positive propagator alone rejected",ciCoreReport["Status"]==="UNRESOLVED"];
ciCoreReport=ConstructiveDiagrams`Private`completionCorrelatedInputProposals[KeyDrop[ciCoreNormalize[{ciCoreA/ciCoreD1}],"Expression"],2];check["missing global expression rejected",ciCoreReport["Status"]==="UNRESOLVED"];
ciCoreReport=ConstructiveDiagrams`Private`completionCorrelatedInputProposals[<|"Expression"->ciCoreA/ciCoreD1,"Records"->{ciCoreA/ciCoreD1}|>,2];check["malformed records rejected",ciCoreReport["Status"]==="UNRESOLVED"];
ciCoreReport=ConstructiveDiagrams`Private`completionCorrelatedInputProposals[ciCoreNormalize[{ciCoreA/ciCoreD1}],0];check["zero budget never returns ciCoreA partial available core",ciCoreReport["Status"]==="UNRESOLVED"&&!ciCoreReport["CoreDecompositionComplete"]];
ciCoreNormalized=ciCoreNormalize[{ciCoreContact+ciCoreA/ciCoreD1,ciCoreB/ciCoreD2}];ciCoreSaved=ciCoreNormalized;ciCoreReport=ConstructiveDiagrams`Private`completionCorrelatedInputProposals[ciCoreNormalized,2];check["source inputs remain unchanged",SameQ[ciCoreNormalized,ciCoreSaved]];
check["every record roundtrip and exact decomposition certified",AllTrue[ciCoreReport["RecordCertificates"],#["InverseReplacementRoundtripExact"]&&#["OriginalEqualsRegularPlusCore"]&]];
check["regular part has no propagator",FreeQ[ciCoreReport["RegularExpression"],_PropDen]];
check["overlap coverage remains explicitly incomplete",ciCoreReport["CoreDecompositionComplete"]&&ciCoreReport["OverlapComplete"]===False&&ciCoreReport["OverlapEnumeration"]==="NotAttempted"];
check["ordinary timeout provenance retained",ciCoreReport["OrdinaryCollectorStatus"]==="UNRESOLVED"&&ciCoreReport["OrdinaryCollectorDiagnostics"]=!={}];
check["temporary formal inverse variables do not escape",Cases[ciCoreReport,s_Symbol/;StringStartsQ[SymbolName[ciCoreSymbol],"formalInputInverse"],Infinity]==={}];
ciCoreTrace=Trace[ConstructiveDiagrams`Private`completionCorrelatedInputProposals[ciCoreNormalize[{(ciCoreContact+ciCoreA/ciCoreD1)(ciCoreOtherContact+ciCoreB/ciCoreD2)}],2],HoldPattern[Expand[___]|ExpandAll[___]|ReduceSpinorProducts[___]|ConstructiveDiagrams`Private`completionCanonicalReduce[___]],TraceInternal->False];check["no expansion or spinor-reduction calls",ciCoreTrace==={}];
ciCoreBad=ciCoreNormalize[{ciCoreA/ciCoreD1}];ciCoreBad["Expression"]=ciCoreBad["Expression"]+ciCoreInjectedContact;ciCoreReport=ConstructiveDiagrams`Private`completionCorrelatedInputProposals[ciCoreBad,2];check["injected global contact rejected",ciCoreReport["Status"]==="UNRESOLVED"&&ciCoreReport["Reason"]==="GlobalExpressionDoesNotMatchRecords"];
ciCoreBad=ciCoreNormalize[{ciCoreA/ciCoreD1}];ciCoreBad["Expression"]=ciCoreBad["Expression"]+ciCoreInjectedPole/ciCoreD2;ciCoreReport=ConstructiveDiagrams`Private`completionCorrelatedInputProposals[ciCoreBad,2];check["injected global pole rejected",ciCoreReport["Status"]==="UNRESOLVED"&&ciCoreReport["Reason"]==="GlobalExpressionDoesNotMatchRecords"];

ciCoreManyRecords = ciCoreNormalize[Table[(ciCoreIndex + 1)/(ciCoreD1 ciCoreD2) +
  (-1)^ciCoreIndex ciCoreContact, {ciCoreIndex, 24}]];
ciCoreManyResult = ConstructiveDiagrams`Private`completionCorrelatedInputProposals[ciCoreManyRecords, 2];
check["all24 generic records admit the conservative core",
  ciCoreManyResult["Status"] === "AVAILABLE" && Length[ciCoreManyResult["RecordCertificates"]] === 24];
check["canceled explicit regular records remain exactly accounted for",
  ciCoreManyResult["RegularExpression"] === 0 &&
    ciCoreManyResult["RegularByRecord"] === Table[(-1)^ciCoreIndex ciCoreContact, {ciCoreIndex, 24}]];
check["a many-record input remains one exact correlated direction",
  Length[ciCoreManyResult["Proposals"]] === 1 &&
    ciCoreManyResult["Proposals"][[1]]["Direction"] === ciCoreManyRecords["Expression"]];

ciProposals = ciProposal[ciOverlapInput];
check["bounded proposal collection is available for ordinary diagram records",
  ciProposals["Status"] === "AVAILABLE" &&
    Lookup[ciProposals["Proposals"], "Mode"] === {"InputRescaling", "InputOverlap"}];
check["the first proposal preserves the entire pole-bearing input",
  ciZero[ciCanonical[ciDirection[ciProposals, "InputRescaling"] -
    (ciA + 2 ciB + ciC)]] && ciProposals["RegularExpression"] === 0];
check["the overlap proposal forms a union of complete signed terms across records",
  ciZero[ciCanonical[ciDirection[ciProposals, "InputOverlap"] - ciScalarTree]] &&
    Lookup[Last[ciProposals["Proposals"]], "RepeatedTermGroups"] === 1 &&
    Lookup[Last[ciProposals["Proposals"]], "RemovedCopies"] === 1];
ciOneRecord = ciProposal[{ciPair[ciA + 2 ciB + ciC]}];
check["multiplicity inside one diagram is never reinterpreted as an overlap",
  Lookup[ciOneRecord["Proposals"], "Mode"] === {"InputRescaling"} &&
    ciZero[ciCanonical[ciDirection[ciOneRecord, "InputRescaling"] - (ciA + 2 ciB + ciC)]]];
ciPlainProposals = ciProposal[ciA + 2 ciB + ciC];
check["a plain summed expression does not invent cross-diagram provenance",
  Lookup[ciPlainProposals["Proposals"], "Mode"] === {"InputRescaling"}];
ciContactProposals = ciProposal[ciPair /@ {ciA + ciB + ciContact, ciB + ciC + ciContact}];
check["repeated explicit regular terms keep their original multiplicity",
  ciContactProposals["RegularExpression"] === 2 ciContact &&
    ciZero[ciCanonical[ciDirection[ciContactProposals, "InputOverlap"] - ciScalarTree]]];
ciDistinctProposals = ciProposal[ciPair /@ {ciA + ciB, ciA + 2 ciB + ciC}];
check["overlap comparison includes the full signed coefficient rather than a stripped monomial",
  ciZero[ciCanonical[ciDirection[ciDistinctProposals, "InputOverlap"] -
    (ciA + 3 ciB + ciC)]]];
ciBoundedProposals = ciProposal[ciOverlapInput, 1];
check["an exceeded proposal collection bound is reported without truncating terms",
  ciBoundedProposals["Status"] === "UNRESOLVED" &&
    ciBoundedProposals["Proposals"] === {} && ciBoundedProposals["Diagnostics"] =!= {}];
check["a zero input supplies no nonzero input direction",
  ciProposal[0]["Proposals"] === {}];
ciSavedOverlap = ciOverlapInput; ciSavedModel = ciScalarModel;
ciOverlap = ciFactor[ciOverlapInput, ciScalarChannels, ciScalarModel,
  "ParameterRules" -> ciRules];
check["an input overlap proposal solves all three physical poles simultaneously",
  ciComplete[ciOverlap] && ciOverlap["CorrectionSpace"] === "InputOverlap" &&
    ciZero[ciCanonical[ciOverlap["Amplitude"] - ciScalarTree]]];
check["overlap repair is reported rather than presented as an algebraic identity",
  ciAttempts[ciOverlap] =!= {} && MemberQ[ciAttemptSpaces[ciOverlap], "InputOverlap"] &&
    ciPass[ciOverlap["ValidationReport"]]];
check["a rejected global fit is recorded before a successful overlap fit",
  ciAttemptSpaces[ciOverlap] === {"InputRescaling", "InputOverlap"} &&
    First[ciAttempts[ciOverlap]]["Status"] === "UNRESOLVED" &&
    Last[ciAttempts[ciOverlap]]["Status"] === "COMPLETE" &&
    Last[ciAttempts[ciOverlap]]["NormalizationFactor"] === 1];
check["the overlap shortcut does not mutate the diagram records or model",
  ciOverlapInput === ciSavedOverlap && ciScalarModel === ciSavedModel &&
    ciZero[ciCanonical[ciOverlap["OriginalExpression"] - (ciA + 2 ciB + ciC)]]];

ciDoubleBChannels = ReplacePart[ciScalarChannels,
  {2, -1} -> 2 Last[ciScalarChannels[[2]]]];
ciLegitimate = ciFactor[ciOverlapInput, ciDoubleBChannels, ciScalarModel,
  "ParameterRules" -> ciRules];
check["a repeated term is retained when the original physical amplitude already passes",
  ciComplete[ciLegitimate] && ciLegitimate["CorrectionSpace"] === "NotRequired" &&
    ciAttempts[ciLegitimate] === {} &&
    ciZero[ciCanonical[ciLegitimate["Amplitude"] - (ciA + 2 ciB + ciC)]]];

ciNegativeChannels = ReplacePart[ciScalarChannels, {2, -1} -> -Last[ciScalarChannels[[2]]]];
ciNegative = ciFactor[ciPair /@ {ciA - ciB, -ciB + ciC},
  ciNegativeChannels, ciScalarModel, "ParameterRules" -> ciRules];
check["shared negative terms retain their actual sign in an overlap candidate",
  ciComplete[ciNegative] && ciNegative["CorrectionSpace"] === "InputOverlap" &&
    ciZero[ciCanonical[ciNegative["Amplitude"] - (ciA - ciB + ciC)]]];
ciWeighted = ciFactor[ciPair /@ {ciA + 2 ciB, 2 ciB + ciC},
  ciDoubleBChannels, ciScalarModel, "ParameterRules" -> ciRules];
check["an exact repeated weighted term retains its coefficient",
  ciComplete[ciWeighted] && ciWeighted["CorrectionSpace"] === "InputOverlap" &&
    ciZero[ciCanonical[ciWeighted["Amplitude"] - (ciA + 2 ciB + ciC)]]];
ciTripleBChannels = ReplacePart[ciScalarChannels, {2, -1} -> 3 Last[ciScalarChannels[[2]]]];
ciDifferentWeights = ciFactor[ciPair /@ {ciA + ciB, 2 ciB + ciC},
  ciTripleBChannels, ciScalarModel, "ParameterRules" -> ciRules];
check["different signed or weighted terms are not treated as identical occurrences",
  ciComplete[ciDifferentWeights] && ciDifferentWeights["CorrectionSpace"] === "NotRequired" &&
    ciZero[ciCanonical[ciDifferentWeights["Amplitude"] - (ciA + 3 ciB + ciC)]]];

ciRescale = ciFactor[2 ciScalarTree + ciContact, ciScalarChannels, ciScalarModel,
  "ParameterRules" -> ciRules];
check["input rescaling changes only pole-bearing terms and preserves an explicit contact",
  ciComplete[ciRescale] && ciRescale["CorrectionSpace"] === "InputRescaling" &&
    ciZero[ciCanonical[ciRescale["Amplitude"] - ciScalarTree - ciContact]]];
check["a successful scalar input fit retains its independently checked affine family",
  ciRescale["FreeParameters"] === {} && ciRescale["RemainingBasis"] === {} &&
    ciZero[ciRescale["FamilyAmplitude"] - ciRescale["Amplitude"]] &&
    ciPass[ciRescale["ValidationReport"]]];
ciRescaleSolution = ciRescale["ConstraintData"]["LinearSolution"]["SolutionRules"];
check["input-fit coefficients reconstruct the amplitude from the retained regular seed",
  ciRescale["ConstraintData"]["FitSeed"] === ciContact && Length[ciRescaleSolution] === 1 &&
    ciZero[ciCanonical[ciRescale["ConstraintData"]["FitSeed"] +
      ((First /@ ciRescaleSolution) /. ciRescaleSolution).ciRescale["CorrectionBasis"] -
      ciRescale["Amplitude"]]]];
ciOpposite = ciFactor[-ciScalarTree, ciScalarChannels, ciScalarModel,
  "ParameterRules" -> ciRules];
check["a uniform opposite sign is fitted from physical data rather than presumed",
  ciComplete[ciOpposite] && ciOpposite["CorrectionSpace"] === "InputRescaling" &&
    ciZero[ciCanonical[ciOpposite["Amplitude"] - ciScalarTree]]];
ciZeroThirdChannels = ReplacePart[ciScalarChannels, {3, -1} -> 0];
ciArbitraryFactor = ciFactor[7 (ciA + ciB)/3, ciZeroThirdChannels, ciScalarModel,
  "ParameterRules" -> ciRules, "MaxCorrectionTerms" -> 1];
check["an arbitrary rational input normalization is derived from all supplied residues",
  ciComplete[ciArbitraryFactor] && ciArbitraryFactor["CorrectionSpace"] === "InputRescaling" &&
    Last[ciAttempts[ciArbitraryFactor]]["NormalizationFactor"] === 3/7 &&
    ciZero[ciCanonical[ciArbitraryFactor["Amplitude"] - ciA - ciB]]];
ciZeroThirdCut = ConstructiveDiagrams`Private`canonicalPhysicalCut[
  List @@ ciScalarChannels[[3, -3]], Range[4]];
ciZeroThirdRow = SelectFirst[ciArbitraryFactor["ValidationReport"]["Channels"],
  #["Cut"] === ciZeroThirdCut &, <||>];
check["a declared zero-residue channel remains in independent input-fit validation",
  Length[ciArbitraryFactor["ValidationReport"]["Channels"]] === 3 &&
    ciPass[ciArbitraryFactor["ValidationReport"]] && ciZeroThirdRow["Status"] === "PASS" &&
    AllTrue[Flatten[{ciZeroThirdRow["CalculatedResidue"], ciZeroThirdRow["ExpectedResidue"]}], ciZero]];

(* A single scalar rescaling cannot repair different wrong channel weights.
   Rejected proposals must leave the existing general reconstruction available. *)
ciNonuniform = ciFactor[ciA + 3 ciB + 2 ciC, ciScalarChannels, ciScalarModel,
  "ParameterRules" -> ciRules];
check["a failed global fit falls through to the general correction space",
  ciComplete[ciNonuniform] && ciNonuniform["CorrectionSpace"] =!= "InputRescaling" &&
    ciNonuniform["CorrectionSpace"] =!= "InputOverlap" &&
    ciZero[ciCanonical[ciNonuniform["Amplitude"] - ciScalarTree]]];
ciFromZero = ciFactor[0, ciScalarChannels, ciScalarModel, "ParameterRules" -> ciRules];
check["a zero seed still uses channel reconstruction instead of a meaningless rescaling",
  ciComplete[ciFromZero] && ciFromZero["CorrectionSpace"] =!= "InputRescaling" &&
    ciZero[ciCanonical[ciFromZero["Amplitude"] - ciScalarTree]]];
ciExplicit = ciFactor[2 ciScalarTree, ciScalarChannels, ciScalarModel,
  "ParameterRules" -> ciRules, "CorrectionBasis" -> {ciScalarTree}];
check["an explicit correction basis bypasses input-derived proposal fitting",
  ciComplete[ciExplicit] && ciAttempts[ciExplicit] === {} &&
    ciExplicit["CorrectionSpace"] === "SuppliedTerms" &&
    ciZero[ciCanonical[ciExplicit["Amplitude"] - ciScalarTree]]];
ciNoReferences = ciFactor[2 ciScalarTree, ciScalarChannels, ciScalarModel,
  "ParameterRules" -> ciRules, "ChannelReferences" -> None];
check["literal channel mode bypasses the automatic input-fit stage",
  ciComplete[ciNoReferences] && ciAttempts[ciNoReferences] === {} &&
    !MemberQ[{"InputRescaling", "InputOverlap"}, ciNoReferences["CorrectionSpace"]] &&
    ciZero[ciCanonical[ciNoReferences["Amplitude"] - ciScalarTree]]];
ciNoBasis = ciFactor[2 ciScalarTree, ciScalarChannels, ciScalarModel,
  "ParameterRules" -> ciRules, "CorrectionBasis" -> {}];
check["an explicit empty correction basis is not silently replaced by an input fit",
  AssociationQ[ciNoBasis] && ciNoBasis["Status"] === "UNRESOLVED" &&
    ciAttempts[ciNoBasis] === {} &&
    ciZero[ciCanonical[ciNoBasis["Amplitude"] - 2 ciScalarTree]]];
ciDisabled = ciFactor[2 ciScalarTree, ciScalarChannels, ciScalarModel,
  "ParameterRules" -> ciRules, "InputReweighting" -> None];
check["the user can disable input reweighting while retaining general completion",
  ciComplete[ciDisabled] && ciAttempts[ciDisabled] === {} &&
    !MemberQ[{"InputRescaling", "InputOverlap"}, ciDisabled["CorrectionSpace"]] &&
    ciZero[ciCanonical[ciDisabled["Amplitude"] - ciScalarTree]]];
check["unsupported input reweighting settings are rejected",
  Quiet[CompleteFactorization[ciScalarTree, ciScalarChannels, ciScalarModel,
    "InputReweighting" -> True]] === $Failed];

ciParameterDependent = ciFactor[(1 + ciMass) ciScalarTree,
  ciScalarChannels, ciScalarModel, "ParameterRules" -> ciRules,
  "ValidationParameterRules" -> {{ciMass -> 2, ciCoupling -> 3, ciContact -> 7}}];
check["a coefficient fitted at one mass cannot bypass additional parameter validation",
  AssociationQ[ciParameterDependent] &&
    ciParameterDependent["CorrectionSpace"] =!= "InputRescaling" &&
    (!ciComplete[ciParameterDependent] ||
      ciZero[ciCanonical[ciParameterDependent["Amplitude"] - ciScalarTree]])];
check["the parameter-dependent input-fit rejection exposes its failed held-out validation",
  AnyTrue[ciAttempts[ciParameterDependent],
    #["Mode"] === "InputRescaling" && #["Status"] === "UNRESOLVED" &&
      StringContainsQ[Lookup[#, "Reason", ""], "validation"] &&
      Length[Lookup[#, "ValidationReports", {}]] >= 2 &]];
ciTiny = ciFactor[ciOverlapInput, ciScalarChannels, ciScalarModel,
  "ParameterRules" -> ciRules, "TimeConstraint" -> 0.000001];
check["an exhausted clock never promotes an unvalidated input proposal to success",
  AssociationQ[ciTiny] && ciTiny["Status"] === "UNRESOLVED" &&
    ciZero[ciCanonical[ciTiny["Amplitude"] - (ciA + 2 ciB + ciC)]] &&
    Lookup[ciTiny, "Diagnostics", {}] =!= {}];
ciTimedProposal = Block[
  {ConstructiveDiagrams`Private`completionResidueConstraints =
    Function[Pause[1]; <|"Status" -> "UNRESOLVED"|>]},
  ConstructiveDiagrams`Private`completionFitInputProposal[
    First[ciProposals["Proposals"]], 0, ciNormalized[ciOverlapInput],
    1, 1, 11807, ciRules, {ciRules}, 0.02, Automatic, False]];
check["an interrupted input fit retains the original amplitude with an honest timeout reason",
  ciTimedProposal["Status"] === "UNRESOLVED" &&
    StringContainsQ[ciTimedProposal["Reason"], "time"] &&
    ciZero[ciCanonical[ciTimedProposal["Amplitude"] - (ciA + 2 ciB + ciC)]] &&
    ciTimedProposal["ValidationReports"] === {}];

(* Independent five-point QED examples exercise the actual six physical
   channels, including complete implicit massive-spin component checks. *)
ciQEDRules = {prElectronMass -> 1, prElectricCharge -> 1};
ciQEDOffCutZero[expression_] := AllTrue[
  Flatten[Table[prMapOnChart[expression, prDoubleChart[coords[[1]], coords[[2]], s1, s2]],
    {coords, {{1/7, 2/9}, {2/5, 3/11}}}, {s1, 2}, {s2, 2}]], ciZero];
ciQEDDoubled = ciFactor[2 prH, prChannels, prFixtureModel,
  "ParameterRules" -> ciQEDRules, "Samples" -> 2, "ValidationSamples" -> 2,
  "TimeConstraint" -> 60, "MaxCorrectionTerms" -> 1];
check["the doubled known QED amplitude is repaired by a one-direction input fit",
  ciComplete[ciQEDDoubled] && ciQEDDoubled["CorrectionSpace"] === "InputRescaling" &&
    Last[ciAttempts[ciQEDDoubled]]["NormalizationFactor"] === 1/2 &&
    ciQEDOffCutZero[ciQEDDoubled["Amplitude"] - prH]];
check["the QED rescaling succeeds before constructing channel continuations",
  Length[ciQEDDoubled["CorrectionBasis"]] === 1 &&
    ciQEDDoubled["ChannelContinuations"] === <||>];
check["the QED input fit checks every original physical channel independently",
  Length[ciQEDDoubled["ValidationReport"]["Channels"]] === 6 &&
    ciPass[ciQEDDoubled["ValidationReport"]]];
ciQEDRaw = DiagramAmplitudes[CreateDiagrams[prParticles, prModel]];
ciQEDPrepared = PrepareAmplitudes[ciQEDRaw, prModel,
  "PolePreference" -> "AllPhysical", "MaxSteps" -> 0,
  "TimeConstraint" -> 20, "ReferenceTimeConstraint" -> 5,
  "ProgressReporting" -> False];
ciQEDNormalized = ConstructiveDiagrams`Private`completionNormalizeInput[
  ciQEDPrepared, prChannels, prFixtureModel];
ciQEDCanonical[value_] := ConstructiveDiagrams`Private`completionCanonicalReduce[
  value, ciQEDNormalized["ExternalMassRules"]];
check["the six actual prepared physical-reference diagrams sum algebraically to twice H",
  ciZero[ciQEDCanonical[ciQEDNormalized["Expression"] - 2 prH]]];
ciQEDProposals = ConstructiveDiagrams`Private`completionInputProposals[ciQEDNormalized];
ciQEDOverlap = SelectFirst[ciQEDProposals["Proposals"],
  #["Mode"] === "InputOverlap" &, <||>];
check["the real diagram overlap has three repeated groups and removes three duplicate copies",
  ciQEDOverlap["RepeatedTermGroups"] === 3 && ciQEDOverlap["RemovedCopies"] === 3 &&
    ciZero[ciQEDCanonical[ciQEDOverlap["Direction"] - prH]]];
ciQEDCompleted = ciFactor[ciQEDPrepared, prChannels, prFixtureModel,
  "ParameterRules" -> ciQEDRules, "Samples" -> 2, "ValidationSamples" -> 2,
  "TimeConstraint" -> 90, "MaxCorrectionTerms" -> 1];
check["six real prepared diagram records admit a validated small input completion",
  Length[ciQEDPrepared] === 6 && ciComplete[ciQEDCompleted] &&
    ciQEDCompleted["CorrectionSpace"] === "InputRescaling" &&
    Last[ciAttempts[ciQEDCompleted]]["NormalizationFactor"] === 1/2 &&
    ciQEDOffCutZero[ciQEDCompleted["Amplitude"] - prH]];
check["the actual six-diagram repair uses one direction and no channel continuation construction",
  Length[ciQEDCompleted["CorrectionBasis"]] === 1 &&
    ciQEDCompleted["ChannelContinuations"] === <||>];
check["the prepared-diagram result passes all six held-out physical residues",
  Length[ciQEDCompleted["ValidationReport"]["Channels"]] === 6 &&
    ciPass[ciQEDCompleted["ValidationReport"]]];

(* ::Section:: *)
(* Exact bounded representative selection within a previously certified
   family. These portable fixtures exercise affine geometry, not a new
   physical interaction or a process-specific amplitude target. *)
ciFPChoose[c_,d_List,f_List,s_:2] := ConstructiveDiagrams`Private`completionChooseFamilyPoint[c,d,f,s];
ciFPCore=Spinor["Spin","Upper","Angle",1,-1/2];
ciFPPole=PropDen[Mom[Multiparticle[1,3]],ciFPMass];
ciFPA=SpinorChain[ciFPCore,Spinor["Helicity","Angle",3]]/ciFPPole;
ciFPB=SpinorChain[ciFPCore,Spinor["Helicity","Angle",4]]/ciFPPole;
ciFPC=SpinorChain[ciFPCore,Spinor["Helicity","Angle",5]]/ciFPPole;
ciFPBase=2ciFPA+ciFPB;ciFPDirs={ciFPA-ciFPB};ciFPFree={ciFPCoordinate};ciFPSaved={ciFPBase,ciFPDirs,ciFPFree};
ciFPResult=ciFPChoose[ciFPBase,ciFPDirs,ciFPFree];
check["a simpler complete family point is chosen",ciFPResult["Status"]==="IMPROVED" && ConstructiveDiagrams`Private`preparationBetterQ[ciFPResult["RankAfter"],ciFPResult["RankBefore"]]];
check["reported coordinates reconstruct the result exactly",Expand[ciFPResult["Amplitude"]-ciFPBase-ciFPResult["Values"].ciFPDirs]===0];
check["rebasing preserves the entire original affine family",Expand[ciFPResult["Amplitude"]+ciFPFree.ciFPDirs-(ciFPBase+(ciFPFree+ciFPResult["Values"]).ciFPDirs)]===0];
check["input directions and fixed spin indices are unchanged",{ciFPBase,ciFPDirs,ciFPFree}===ciFPSaved && !FreeQ[ciFPResult["Amplitude"],ciFPCore] && ciFPResult["DirectionsRetained"]===1];
check["several deterministic orders are tried",Length[ciFPResult["OrdersTried"]]===6];
ciFPContact=SpinorChain[Spinor["Helicity","Angle",6],Spinor["Helicity","Angle",7]];
ciFPRegular[expr_] := With[{e=Expand[expr]},Total[Select[If[Head[e]===Plus,List@@e,{e}],FreeQ[Denominator[#],_PropDen]&]]];
ciFPContactDirs={ciFPA-ciFPB+ciFPContact,ciFPContact};ciFPContactCoords={ciFPContactX,ciFPContactY};
ciFPWithContact=ciFPChoose[ciFPBase+ciFPContact,ciFPContactDirs,ciFPContactCoords];
check["regular input coefficients are preserved while pole-bearing terms simplify",ciFPWithContact["Status"]==="IMPROVED" && Expand[ciFPRegular[ciFPWithContact["Amplitude"]]-ciFPContact]===0 && ciFPWithContact["ProtectedRegularMonomials"]===1];
check["contact directions remain available in the rebased complete family",ciFPWithContact["DirectionsRetained"]===2 && Expand[ciFPWithContact["Amplitude"]+ciFPContactCoords.ciFPContactDirs-(ciFPBase+ciFPContact+(ciFPContactCoords+ciFPWithContact["Values"]).ciFPContactDirs)]===0];
ciFPOnlyContact=ciFPChoose[(ciFPBase*ciFPPole),{(ciFPA-ciFPB)*ciFPPole},ciFPFree];
check["a pole-free amplitude is not changed merely to shrink it",ciFPOnlyContact["Status"]==="UNCHANGED" && ciFPOnlyContact["Amplitude"]===ciFPBase*ciFPPole];
ciFPNoNewContact=ciFPChoose[ciFPBase,{ciFPA-ciFPB+ciFPContact},ciFPFree];
check["a zero regular coefficient is also protected",ciFPNoNewContact["Amplitude"]===ciFPBase && ciFPRegular[ciFPNoNewContact["Amplitude"]]===0 && ciFPNoNewContact["Values"]==={0}];

ciFPStable=ciFPChoose[ciFPA,{ciFPB},ciFPFree];
check["an already smaller point is retained",ciFPStable["Status"]==="UNCHANGED" && ciFPStable["Amplitude"]===ciFPA && ciFPStable["Values"]==={0}];
check["an empty direction list is harmless",ciFPChoose[ciFPA,{},{}]["Amplitude"]===ciFPA];
check["mismatched coordinate lists are rejected conservatively",ciFPChoose[ciFPBase,ciFPDirs,{}]["Amplitude"]===ciFPBase];
check["repeated coordinates are rejected conservatively",ciFPChoose[ciFPBase,{ciFPA,ciFPB},{ciFPCoordinate,ciFPCoordinate}]["Amplitude"]===ciFPBase];
check["an invalid clock leaves the candidate unchanged",ciFPChoose[ciFPBase,ciFPDirs,ciFPFree,0]["Amplitude"]===ciFPBase];
check["inexact coefficients are not treated as exact relations",ciFPChoose[0.1ciFPA+ciFPB,ciFPDirs,ciFPFree]["Amplitude"]===0.1ciFPA+ciFPB];
check["coordinate dependent directions do not enter affine selection",ciFPChoose[ciFPBase,{ciFPCoordinate*ciFPA},ciFPFree]["Amplitude"]===ciFPBase];
ciFPHuge=(ciFPA+ciFPB)^1000000;
{ciFPHugeSeconds,ciFPHugeResult}=AbsoluteTiming[ciFPChoose[ciFPHuge,ciFPDirs,ciFPFree]];
check["prospective expansion guard runs before expression ranking",ciFPHugeResult["Amplitude"]===ciFPHuge && StringContainsQ[ciFPHugeResult["Reason"],"expansion"] && ciFPHugeSeconds<1];
ciFPPole=PropDen[Mom[Multiparticle[1,3]],ciFPMass];
ciFPProtected=ciFPChoose[ciFPBase/ciFPPole,{(ciFPA-ciFPB)/ciFPPole},ciFPFree];
check["selection preserves original propagators and coefficients",Cases[ciFPProtected["Amplitude"],_PropDen,Infinity]==={ciFPPole} && Expand[ciFPProtected["Amplitude"]-ciFPBase/ciFPPole-ciFPProtected["Values"].{(ciFPA-ciFPB)/ciFPPole}]===0];
ciFPModelMass1=ModelParameter["Me","one","Real"];ciFPModelMass2=ModelParameter["Me","two","Real"];
ciFPLocal=ciFPChoose[2ciFPModelMass1 ciFPA+ciFPModelMass2 ciFPB,{ciFPModelMass1 ciFPA-ciFPModelMass2 ciFPB},ciFPFree];
check["distinct model local parameters remain independent monomials",Expand[ciFPLocal["Amplitude"]-(2ciFPModelMass1 ciFPA+ciFPModelMass2 ciFPB)-ciFPLocal["Values"].{ciFPModelMass1 ciFPA-ciFPModelMass2 ciFPB}]===0 && Length[ciFPLocal["Values"]]===1];
DownValues[ciFPRankOriginal]=DownValues[ConstructiveDiagrams`Private`preparationRank]/.ConstructiveDiagrams`Private`preparationRank->ciFPRankOriginal;
ciFPRankCount=0;
ciFPEarlyTimeout=Block[{ConstructiveDiagrams`Private`preparationRank},
 ConstructiveDiagrams`Private`preparationRank[expr_]:=(Pause[1];ciFPRankOriginal[expr]);
 ciFPChoose[ciFPBase,ciFPDirs,ciFPFree,0.02]];
check["a timeout before any complete point retains the original",ciFPEarlyTimeout["Amplitude"]===ciFPBase && ciFPEarlyTimeout["Values"]==={0} && TrueQ[ciFPEarlyTimeout["TimedOut"]]];
ciFPCompletedTimeout=Block[{ConstructiveDiagrams`Private`preparationRank},
 ConstructiveDiagrams`Private`preparationRank[expr_]:=(ciFPRankCount++;If[ciFPRankCount===3,Pause[1]];ciFPRankOriginal[expr]);
 ciFPChoose[ciFPBase,ciFPDirs,ciFPFree,0.1]];
check["a later timeout retains one complete improved point atomically",ciFPCompletedTimeout["Status"]==="IMPROVED" && TrueQ[ciFPCompletedTimeout["TimedOut"]] && Expand[ciFPCompletedTimeout["Amplitude"]-ciFPBase-ciFPCompletedTimeout["Values"].ciFPDirs]===0];

(* The public stage keeps the full residue-invisible scalar contact family;
   point selection changes neither the fitting space nor the known seed term. *)
check["compact representative selection is enabled by default",
  ("RepresentativeSelection" /. Options[CompleteFactorization]) === Automatic];
check["unsupported representative selection settings are rejected",
  Quiet[CompleteFactorization[ciScalarTree, ciScalarChannels, ciScalarModel,
    "RepresentativeSelection" -> True]] === $Failed];
ciFPContactAuto = ciFactor[ciScalarTree + ciContact, ciScalarChannels, ciScalarModel,
  "CorrectionBasis" -> {1}, "ParameterRules" -> ciRules];
ciFPContactNone = ciFactor[ciScalarTree + ciContact, ciScalarChannels, ciScalarModel,
  "CorrectionBasis" -> {1}, "ParameterRules" -> ciRules,
  "RepresentativeSelection" -> None];
check["automatic and disabled selection preserve explicit regular input in a public scalar family",
  AllTrue[{ciFPContactAuto, ciFPContactNone},
    ciComplete[#] && ciZero[ciCanonical[#["Amplitude"] - ciScalarTree - ciContact]] &]];
check["both public representative modes retain every contact direction and coherent family",
  AllTrue[{ciFPContactAuto, ciFPContactNone},
    #["RemainingBasis"] === {1} && Length[#["FreeParameters"]] === 1 &&
      ciZero[ciCanonical[#["FamilyAmplitude"] - #["Amplitude"] -
        #["FreeParameters"].#["RemainingBasis"]]] &]];
check["both public representative modes retain independently passing physical checks",
  AllTrue[{ciFPContactAuto, ciFPContactNone}, ciPass[#["ValidationReport"]] &]];
check["the public disabled option skips point selection without removing its affine freedom",
  ciFPContactNone["RepresentativeSelection"]["Status"] === "UNCHANGED" &&
    Length[ciFPContactNone["FreeParameters"]] === 1 &&
    ciFPContactAuto["RepresentativeSelection"]["ProtectedRegularMonomials"] >= 1];
ciFPCleanupGuard = Block[
  {ConstructiveDiagrams`Private`completionExternalReduce = Function[{value, massRules},
    value + SpinorChain[Spinor["Spin", "Angle", 1], Mom[2], Mom[3],
      Spinor["Spin", "Angle", 4]]]},
  ciFactor[ciScalarTree + ciContact, ciScalarChannels, ciScalarModel,
    "CorrectionBasis" -> {1}, "ParameterRules" -> ciRules,
    "RepresentativeSelection" -> None]];
check["optional cleanup cannot replace a validated point or direction with a worse finite expression",
  ciComplete[ciFPCleanupGuard] && ciFPCleanupGuard["RemainingBasis"] === {1} &&
    ciZero[ciCanonical[ciFPCleanupGuard["Amplitude"] - ciScalarTree - ciContact]]];

check["the complete input-fit regression inventory ran", checks === 102];
Print[checks, " completion-input-fit checks; ", Length[failures], " failures."];
If[failures =!= {}, Print[failures]; Quit[1]];
Print["HEPCAT_TEST_COMPLETED:completion-input-fit-tests.wl"];
Quit[0];
