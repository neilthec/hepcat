(* Bounded diagram/channel preparation and simultaneous amplitude completion. *)

(*
HEPCAT - High Energy Physics Constructive Amplitude Tool

Copyright (C) 2026 Neil Christensen

This file is part of HEPCAT.

HEPCAT is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

HEPCAT is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with HEPCAT.  If not, see <https://www.gnu.org/licenses/>.
*)


root = DirectoryName[DirectoryName[DirectoryName[$InputFileName]]];
Global`$HEPCATpath = FileNameJoin[{root, "source"}];
Get[FileNameJoin[{$HEPCATpath, "HEPCAT.wl"}]];
If[AnyTrue[{PrepareAmplitudes, CompleteFactorization, CompleteHighEnergy},
    DownValues[#] === {} &], Print["Amplitude-completion APIs did not load."]; Quit[1]];
Get[FileNameJoin[{root, "tests", "checks", "fixtures", "QED-5-point-residues.wl"}]];
checks = 0; failures = {};
check[name_, value_] := (checks++;
  If[Mod[checks, 25] === 0, Print["Completed ", checks, " amplitude-completion checks."]];
  If[!TrueQ[value], AppendTo[failures, name];
  Print["FAIL: ", name]]);
acZero[expression_] := Together[expression] === 0;
acInvalid[value_] := value === $Failed || FailureQ[value];
acSettings[opts___] := Normal[Join[<|"Samples" -> 2, "ValidationSamples" -> 2,
  "RandomSeed" -> 1729, "TimeConstraint" -> 60, "MaxCorrectionTerms" -> 64,
  "ProgressReporting" -> False, "Output" -> "Details"|>, Association[{opts}]]];
(* These existing factorization-space regressions retain their unprojected
   spaces. High-energy tests share acSettings but do not take these options. *)
acFactor[input_, channels_, model_, opts___] := CompleteFactorization[
  input, channels, model, Sequence @@ acSettings["BoseSymmetryGroups" -> {}, "FermionSymmetryGroups" -> {}, opts]];
acEnergy[input_, channels_, model_, opts___] := CompleteHighEnergy[
  input, channels, model, Sequence @@ acSettings[opts]];
acCheck[expression_, channels_, model_, rules_, seed_] := CheckPhysicalResidues[
  expression, channels, model, "Output" -> "Details", "Samples" -> 3,
  "RandomSeed" -> seed, "ParameterRules" -> rules, "TimeConstraint" -> 30,
  "HighEnergyCheck" -> False, "ReferenceCheck" -> False];
acPhysicalPass[report_] := AssociationQ[report] &&
  AllTrue[report["Channels"], #["Status"] === "PASS" &];
acAllPass[report_] := AssociationQ[report] &&
  AllTrue[report["Checks"], #["Status"] === "PASS" &];
acCanonical[expression_, n_] :=
  ConstructiveDiagrams`Private`residueCanonicalPropagators[expression, Range[n]];
check["all preparation and completion stages enable progress reporting by default",
  AllTrue[{PrepareAmplitudes, CompleteFactorization, CompleteHighEnergy},
    ("ProgressReporting" /. Options[#]) === True &]];
acFormalBasis = {acFormalX + acFormalY, acFormalX - acFormalY,
  2 acFormalX, acFormalX, 3 (acFormalX + acFormalY)};
check["formal basis pruning removes only exact constant linear dependencies",
  ConstructiveDiagrams`Private`completionIndependentBasis[acFormalBasis] ===
    Take[acFormalBasis, 2]];
acSparseFormalMonomials = Array[acSparseFormalAtom, 48];
acSparseFormalBasis = Join[acSparseFormalMonomials,
  Table[acSparseFormalMonomials[[i]] + acSparseFormalMonomials[[i + 1]], {i, 47}],
  Table[(1/3 + 2 I/5) acSparseFormalMonomials[[i]] -
    7 acSparseFormalMonomials[[i + 1]], {i, 47}]];
check["sparse rectangular formal pruning preserves the exact rational complex span",
  ConstructiveDiagrams`Private`completionIndependentBasis[acSparseFormalBasis] ===
    acSparseFormalMonomials];
check["an interrupted formal pruning pass retains every original direction",
  ConstructiveDiagrams`Private`completionIndependentBasis[acFormalBasis, 0] === acFormalBasis];
acUnprovedPhysicalBasis = {MomProd[1, 2],
  (Mandelstahm[1, 2] - Mass[1]^2 - Mass[2]^2)/2};
check["formal pruning does not infer unstated physical identities between distinct monomials",
  ConstructiveDiagrams`Private`completionIndependentBasis[acUnprovedPhysicalBasis] ===
    acUnprovedPhysicalBasis];
acRealPrecisionBasis = {1. acFormalX, 1. acFormalY, 1. (acFormalX + acFormalY)};
check["formal pruning retains every direction when real coefficients are inexact",
  ConstructiveDiagrams`Private`completionIndependentBasis[acRealPrecisionBasis] ===
    acRealPrecisionBasis];
acComplexPrecisionBasis = {(1. + I) acFormalX, (1. + I) acFormalY,
  (1. + I) (acFormalX + acFormalY)};
check["formal pruning retains every direction when atomic complex coefficients are inexact",
  ConstructiveDiagrams`Private`completionIndependentBasis[acComplexPrecisionBasis] ===
    acComplexPrecisionBasis];
check["Bose state inference is automatic by default",
  ("BoseSymmetryGroups" /. Options[CompleteFactorization]) === Automatic];

(* Automatic charts use a single affine pass; opaque custom maps retain the
   exact legacy coefficient forms when that compatibility mode is requested. *)
acComponentVariables = {acComponentA, acComponentB, Unique["acUnusedComponent"]};
acComponentBracket = SpinorChain[Spinor["Spin", "Angle", 1],
  Spinor["Spin", "Angle", 2]];
acComponentChain = SpinorChain[Spinor["Helicity", "Square", 3], Mom[1],
  Spinor["Helicity", "Angle", 4]];
acComponentCoefficient = (acComponentCoupling + I acComponentOtherCoupling)
  (acComponentBracket + 3 acComponentChain)/PropDen[Mom[Multiparticle[1, 3]], prElectronMass];
acComponentTrial = (2 + 3 I) acComponentBracket +
  (acComponentA - 2 acComponentB) acComponentCoefficient +
  (acComponentA + acComponentB) SpinorTrace[Mom[1], Mom[2]];
acComponentSaved = acComponentTrial;
acComponentLegacy = Prepend[Coefficient[acComponentTrial, #] & /@ acComponentVariables,
  acComponentTrial /. Thread[acComponentVariables -> 0]];
acComponentFast = ConstructiveDiagrams`Private`completionLinearComponents[
  acComponentTrial, acComponentVariables, False];
check["single-pass affine extraction preserves complex factored spinor components exactly",
  MapThread[Expand[#1 - #2] === 0 &, {acComponentFast, acComponentLegacy}] ===
    ConstantArray[True, Length[acComponentLegacy]]];
check["canonical affine trials preserve the legacy coefficient forms in the fast path",
  With[{canonical = First[acComponentLegacy] + acComponentVariables.Rest[acComponentLegacy]},
    ConstructiveDiagrams`Private`completionLinearComponents[
      canonical, acComponentVariables, False] === acComponentLegacy]];
check["single-pass affine components reconstruct the unchanged original trial",
  acComponentTrial === acComponentSaved &&
    Expand[acComponentTrial - First[acComponentFast] -
      acComponentVariables.Rest[acComponentFast]] === 0];
check["unused fitting variables retain explicit zero components in their original positions",
  Length[acComponentFast] === Length[acComponentVariables] + 1 &&
    Last[acComponentFast] === 0];
check["single-pass extraction preserves the requested variable order",
  ConstructiveDiagrams`Private`completionLinearComponents[acComponentTrial,
    Reverse[acComponentVariables], False] === Prepend[Reverse[Rest[acComponentFast]],
      First[acComponentFast]]];
check["zero-variable trials bypass coefficient extraction without changing their form",
  ConstructiveDiagrams`Private`completionLinearComponents[acComponentTrial, {}] ===
    {acComponentTrial} &&
  ConstructiveDiagrams`Private`completionLinearComponents[acComponentTrial, {}, False] ===
    {acComponentTrial}];
check["constant-only trials pad every declared fitting variable with zero",
  ConstructiveDiagrams`Private`completionLinearComponents[
    acComponentCoefficient, acComponentVariables, False] ===
      Prepend[ConstantArray[0, Length[acComponentVariables]], acComponentCoefficient] &&
    ConstructiveDiagrams`Private`completionLinearComponents[0, acComponentVariables, False] ===
      ConstantArray[0, Length[acComponentVariables] + 1]];
acComponentNonlinear = acComponentTrial + acComponentA^2 +
  5 acComponentA acComponentB + acComponentB^3;
check["nonlinear fitting expressions retain the conservative legacy extraction",
  ConstructiveDiagrams`Private`completionLinearComponents[
    acComponentNonlinear, acComponentVariables, False] ===
      Prepend[Coefficient[acComponentNonlinear, #] & /@ acComponentVariables,
        acComponentNonlinear /. Thread[acComponentVariables -> 0]]];
acComponentNonpolynomial = Sin[acComponentA] + acComponentB acComponentCoefficient;
check["failed polynomial extraction falls back to the unchanged legacy behavior",
  Quiet[ConstructiveDiagrams`Private`completionLinearComponents[
    acComponentNonpolynomial, acComponentVariables, False]] ===
      Quiet[Prepend[Coefficient[acComponentNonpolynomial, #] & /@ acComponentVariables,
        acComponentNonpolynomial /. Thread[acComponentVariables -> 0]]]];
acComponentCustomMap = With[{special = acComponentLegacy[[2]]},
  Function[{expression, channels, poles}, If[expression === special,
    acComponentMapMarker, HoldComplete[expression]]]];
acComponentPreserved = ConstructiveDiagrams`Private`completionLinearComponents[
  acComponentTrial, acComponentVariables];
check["custom maps retain the same exact component expressions in compatibility mode",
  acComponentPreserved === acComponentLegacy &&
  (acComponentCustomMap[#, {}, {}] & /@ acComponentPreserved) ===
    (acComponentCustomMap[#, {}, {}] & /@ acComponentLegacy) &&
    acComponentCustomMap[acComponentPreserved[[2]], {}, {}] === acComponentMapMarker];

(* Preparation retains diagram-local assumptions and off-shell denominators. *)
acRules = {Mass[1] -> prElectronMass, Mass[2] -> prElectronMass, Mass[3] -> 0, Mass[4] -> 0,
  Mass[Multiparticle[1, 3]] -> prElectronMass};
acDen = PropDen[Mom[Multiparticle[1, 3]], prElectronMass];
acDiracPair = {acRules, SpinorChain[Spinor["Spin", "Angle", 1], Mom[1],
  Spinor["Spin", "Square", 2]]/acDen};
acSavedPair = acDiracPair; acSavedModel = prModel;
acPrepEvents = {};
acPrepared = PrepareAmplitudes[{acDiracPair}, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> True,
  "ProgressFunction" -> (AppendTo[acPrepEvents, #] &), "Output" -> "Details"];
check["preparation reduces an actual external Dirac chain before identity search",
  acPrepared["Status"] === "PREPARED" && acPrepared["Amplitude"] ===
    prElectronMass SpinorChain[Spinor["Spin", "Square", 1], Spinor["Spin", "Square", 2]]/acDen];
check["preparation retains original amplitudes and the supplied model",
  acPrepared["OriginalAmplitudes"] === {acSavedPair} &&
    acDiracPair === acSavedPair && prModel === acSavedModel];
check["preparation records the external mass rules separately from numerator shells",
  acPrepared["ExternalMassRules"] === Take[acRules, 4] &&
    First[acPrepared["DiagramReports"]]["InternalOnShellChannels"] === {{1, 3}}];
check["preparation does not put the physical denominator on shell",
  !FreeQ[acPrepared["Amplitude"], acDen] &&
    TrueQ[First[acPrepared["DiagramReports"]]["DenominatorsKeptOffShell"]]];
check["preparation progress callbacks receive structured live events",
  Length[acPrepEvents] >= 3 && AllTrue[acPrepEvents,
    AssociationQ[#] && ContainsAll[Keys[#], {"Stage", "Diagram", "Complexity", "Terms"}] &]];
acPreparedPairs = PrepareAmplitudes[{acDiracPair}, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> False];
check["the default preparation output remains ordinary amplitude pairs",
  acPreparedPairs === acPrepared["PreparedAmplitudes"]];
acExplicitPreparedPairs = PrepareAmplitudes[{acDiracPair}, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> False, "Output" -> "Amplitudes"];
check["explicit Amplitudes output retains compatible prepared pairs",
  acExplicitPreparedPairs === acPreparedPairs];
check["explicit Expression output remains the ordinary summed expression",
  PrepareAmplitudes[{acDiracPair}, prModel, "MaxSteps" -> 0,
    "ProgressReporting" -> False, "Output" -> "Expression"] === acPrepared["Amplitude"]];
check["detailed preparation output is opt-in by default",
  ("ReturnDetails" /. Options[PrepareAmplitudes]) === False &&
    ("Output" /. Options[PrepareAmplitudes]) === "Amplitudes"];
check["the previous preparation name delegates to the same implementation and options",
  Options[PrepareDiagramAmplitudes] === Options[PrepareAmplitudes] &&
    PrepareDiagramAmplitudes[{acDiracPair}, prModel, "MaxSteps" -> 0,
      "ProgressReporting" -> False] === acPreparedPairs];
check["ReturnDetails False returns ordinary prepared pairs",
  PrepareAmplitudes[{acDiracPair}, prModel, "MaxSteps" -> 0,
    "ProgressReporting" -> False, "ReturnDetails" -> False] === acPreparedPairs];
acReturnDetails = PrepareAmplitudes[{acDiracPair}, prModel, "MaxSteps" -> 0,
  "ProgressReporting" -> False, "ReturnDetails" -> True];
check["ReturnDetails True exposes the retained inputs and preparation history",
  AssociationQ[acReturnDetails] && acReturnDetails["Amplitude"] === acPrepared["Amplitude"] &&
    acReturnDetails["OriginalAmplitudes"] === {acDiracPair} &&
    First[acReturnDetails["DiagramReports"]]["Reductions"] =!= {}];
check["ReturnDetails True takes precedence over legacy Output choices",
  AssociationQ[PrepareAmplitudes[{acDiracPair}, prModel, "MaxSteps" -> 0,
    "ProgressReporting" -> False, "ReturnDetails" -> True, "Output" -> "Amplitudes"]]];
acXiPair = {acRules, SpinorChain[Spinor["Xi", "Angle", 71],
  Spinor["Helicity", "Angle", 3]]/
    (SpinorChain[Spinor["Xi", "Angle", 72], Spinor["Helicity", "Angle", 3]] acDen)};
acXiPrepared = Last[First[PrepareAmplitudes[{acXiPair}, prModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False]]];
check["explicit None preserves distinct reference spinors during preparation",
  Sort[DeleteDuplicates[Cases[acXiPrepared, Spinor["Xi", kind_, id_] :> {kind, id}, Infinity]]] ===
    {{"Angle", 71}, {"Angle", 72}} &&
    ReduceSpinorProducts[acXiPrepared - Last[acXiPair]] === 0];
acReferencePrepare[pairs_, choice_, opts___] := PrepareAmplitudes[pairs, prModel,
  opts, "PolePreference" -> choice, "MaxSteps" -> 0,
  "ProgressReporting" -> False, "Output" -> "Details"];
acReferenceAssignments[report_] := First[report["DiagramReports"]]["PolePreference"]["Assignments"];
acReferenceRatio[kind_, id_, leg_, momentum_] := SpinorChain[
  Spinor["Xi", kind, id], Mom[momentum],
  Spinor["Helicity", If[kind === "Angle", "Square", "Angle"], leg]]/
    SpinorChain[Spinor["Xi", kind, id], Spinor["Helicity", kind, leg]];
acReferenceRules = {Mass[1] -> prElectronMass, Mass[2] -> prElectronMass,
  Mass[3] -> 0, Mass[4] -> 0, Mass[5] -> 0,
  Mass[Multiparticle[1, 3]] -> prElectronMass};
acReferenceRaw = acReferenceRatio["Angle", 10, 5, 1] *
  acReferenceRatio["Angle", 11, 3, 1] acReferenceRatio["Square", 12, 4, 2]/acDen;
acReferencePair = {acReferenceRules, acReferenceRaw};
acReferenceSpurious = acReferencePrepare[{acReferencePair}, "AllSpurious"];
acReferenceCyclic = acReferencePrepare[{acReferencePair}, "Cyclic"];
acReferenceCycle = {Spinor["Xi", "Angle", 10] -> Spinor["Helicity", "Angle", 3],
  Spinor["Xi", "Angle", 11] -> Spinor["Helicity", "Angle", 4],
  Spinor["Xi", "Square", 12] -> Spinor["Helicity", "Square", 5]};
check["cyclic reference choices follow diagram-local vertex order rather than sorted particle labels",
  Sort[({#["Leg"], #["Target"]} &) /@ acReferenceAssignments[acReferenceCyclic]] ===
    {{3, 4}, {4, 5}, {5, 3}}];
(* Test the substitution stage itself. Later preparation may use diagram-local
   shell identities, and ordinary RSP is not a complete equality prover. *)
acReferenceCyclicStage = SelectFirst[
  First[acReferenceCyclic["DiagramReports"]]["Reductions"],
  #["Operation"] === "PolePreference" &]["After"];
check["massless reference substitution preserves both angle and square chirality",
  acReferenceCyclic["Status"] === "PREPARED" &&
    FreeQ[acReferenceCyclic["Amplitude"], Spinor["Xi", ___]] &&
    ReduceSpinorProducts[acReferenceCyclicStage -
      (acReferenceRaw /. acReferenceCycle)] === 0];
check["the prepared cyclic numerator agrees independently on its declared cut",
  And @@ Flatten[Table[Together[prMapOnChart[
    (acReferenceCyclic["Amplitude"] - (acReferenceRaw /. acReferenceCycle)) /. acDen -> 1,
    prChart[{1, 3}, acReferenceCutVariable, firstSpin, secondSpin]] /.
      acReferenceCutVariable -> 0] === 0, {firstSpin, 2}, {secondSpin, 2}]]];
acReferenceAutomatic = acReferencePrepare[{acReferencePair}, Automatic];
check["Automatic keeps a no-worse supported physical or spurious reference assignment",
  acReferenceAutomatic["Status"] === "PREPARED" &&
    !ConstructiveDiagrams`Private`preparationBetterQ[
      ConstructiveDiagrams`Private`preparationRank[acReferenceSpurious["Amplitude"]],
      ConstructiveDiagrams`Private`preparationRank[acReferenceAutomatic["Amplitude"]]] &&
    AllTrue[acReferenceAssignments[acReferenceAutomatic],
      MemberQ[{"AllSpurious", "AllPhysical"}, #["Mode"]] &] &&
    FreeQ[acReferenceAutomatic["Amplitude"], Spinor["Xi", ___]] &&
    And @@ Flatten[Table[Together[prMapOnChart[
      (acReferenceAutomatic["Amplitude"] - First[acReferenceAutomatic["DiagramReports"]]["PolePreference"]["Expression"]) /. acDen -> 1,
      prChart[{1, 3}, acReferenceCutVariable, firstSpin, secondSpin]] /.
        acReferenceCutVariable -> 0] === 0, {firstSpin, 2}, {secondSpin, 2}]]];
check["the default reference-spinor choice is Automatic",
  ("PolePreference" /. Options[PrepareAmplitudes]) === Automatic];
acReferenceAlias = acReferencePrepare[{acReferencePair}, "Cyclic"];
check["Cyclic retains the deterministic forward reference assignment",
  acReferenceAlias["Amplitude"] === acReferenceCyclic["Amplitude"]];
check["optimized AllSpurious is no more complex than the fixed cyclic assignment",
  SpinorExpressionComplexity[acReferenceSpurious["Amplitude"]] <=
    SpinorExpressionComplexity[acReferenceCyclic["Amplitude"]] &&
    AllTrue[acReferenceAssignments[acReferenceSpurious], #["Mode"] === "AllSpurious" &] &&
    FreeQ[acReferenceSpurious["Amplitude"], Spinor["Xi", ___]]];
acReferenceReverse = acReferencePrepare[{acReferencePair}, "ReverseCyclic"];
check["the reverse cyclic choice takes the previous distinct massless external leg",
  Sort[({#["Leg"], #["Target"]} &) /@ acReferenceAssignments[acReferenceReverse]] ===
    {{3, 5}, {4, 3}, {5, 4}}];
acReferenceShared = acReferencePrepare[{acReferencePair}, "Xi"];
check["Xi chooses a shared generic reference without changing its chirality",
  Sort[DeleteDuplicates[Cases[acReferenceShared["Amplitude"],
    Spinor["Xi", kind_, id_] :> {kind, id}, Infinity]]] ===
      {{"Angle", 0}, {"Square", 0}}];
acReferenceIndependent = acReferencePrepare[{acReferencePair}, "IndependentXi"];
check["IndependentXi records one generic reference per external massless leg",
  Sort[({#["Leg"], #["Target"]} &) /@ acReferenceAssignments[acReferenceIndependent]] ===
    {{3, 3}, {4, 4}, {5, 5}} &&
    Sort[DeleteDuplicates[Cases[acReferenceIndependent["Amplitude"],
      Spinor["Xi", _, id_] :> id, Infinity]]] === {3, 4, 5}];
check["reference selection occurs between spin contraction and spinor-product reduction",
  With[{operations = Lookup[First[acReferenceSpurious["DiagramReports"]]["Reductions"], "Operation"]},
    ContainsAll[operations, {"ReduceSpinContractions", "PolePreference", "ReduceSpinorProducts"}] &&
      FirstPosition[operations, "ReduceSpinContractions"][[1]] <
        FirstPosition[operations, "PolePreference"][[1]] <
        FirstPosition[operations, "ReduceSpinorProducts"][[1]]]];
check["reference preparation retains its original input and off-shell physical denominator",
  acReferenceSpurious["OriginalAmplitudes"] === {acReferencePair} &&
    !FreeQ[acReferenceSpurious["Amplitude"], acDen] &&
    First[acReferenceSpurious["DiagramReports"]]["DenominatorsKeptOffShell"] === True];
acReferenceBlockedPairs = {acReferencePair,
  {Append[Take[acReferenceRules, 5], Mass[Multiparticle[3, 4]] -> 0], 1}};
acReferenceBlocked = acReferencePrepare[acReferenceBlockedPairs, "AllSpurious"];
check["a massless bracket belonging to a certified physical channel is not called spurious",
  SelectFirst[acReferenceAssignments[acReferenceBlocked], #["Leg"] === 3 &]["Target"] === 5];

(* Physical reference choices are certified by other supplied diagram cuts. *)
acReferenceExternal = Take[acRules, 4];
acReferencePhysicalPairs = {
  {Append[acReferenceExternal, Mass[Multiparticle[1, 3]] -> prElectronMass],
    acReferenceRatio["Angle", 31, 3, 1]/acDen},
  {Append[acReferenceExternal, Mass[Multiparticle[1, 4]] -> prElectronMass],
    acReferenceRatio["Square", 32, 4, 1]/PropDen[Mom[Multiparticle[1, 4]], prElectronMass]}};
acReferencePhysical = acReferencePrepare[acReferencePhysicalPairs, "AllPhysical"];
acPhysicalAssignments = Flatten[Lookup[
  Lookup[acReferencePhysical["DiagramReports"], "PolePreference"], "Assignments"], 1];
check["physical reference choices use other certified poles rather than each diagram's own cut",
  acReferencePhysical["Status"] === "PREPARED" &&
    Sort[({#["Leg"], #["Target"]} &) /@ acPhysicalAssignments] === {{3, 2}, {4, 2}} &&
    AllTrue[acPhysicalAssignments, #["Mode"] === "AllPhysical" &]];
check["physical choices replace Xi by opposite-chirality spinors and momentum insertions",
  FreeQ[acReferencePhysical["Amplitude"], Spinor["Xi", ___]] &&
    !FreeQ[First[acReferencePhysical["DiagramReports"]]["PolePreference"]["Expression"],
      SpinorChain[Spinor["Helicity", "Square", 3], Mom[2], Mom[1],
        Spinor["Helicity", "Square", 3]]] &&
    !FreeQ[Last[acReferencePhysical["DiagramReports"]]["PolePreference"]["Expression"],
      SpinorChain[Spinor["Helicity", "Angle", 4], Mom[2], Mom[1],
        Spinor["Helicity", "Angle", 4]]]];
check["only the newly inserted auxiliary self-sandwiches become certified physical denominators",
  And @@ MapThread[Function[{pair, auxiliary},
      !FreeQ[Last[pair], auxiliary]],
    {acReferencePhysical["PreparedAmplitudes"],
      {PropDen[Mom[Multiparticle[2, 3]], prElectronMass], PropDen[Mom[Multiparticle[2, 4]], prElectronMass]}}] &&
    And @@ MapThread[Function[{pair, originalDenominator}, !FreeQ[Last[pair], originalDenominator]],
      {acReferencePhysical["PreparedAmplitudes"],
        {acDen, PropDen[Mom[Multiparticle[1, 4]], prElectronMass]}}]];
acReferenceUncertified = acReferencePrepare[{First[acReferencePhysicalPairs]}, "AllPhysical"];
check["unsupported physical reference choices remain partial instead of inventing a pole",
  acReferenceUncertified["Status"] === "PARTIAL" &&
    First[acReferenceUncertified["DiagramReports"]]["PolePreference"]["Status"] === "UNRESOLVED"];
acReferenceSingleExternal = Join[Thread[(Mass /@ Range[4]) -> ConstantArray[prElectronMass, 4]],
  {Mass[5] -> 0}];
acReferenceSinglePairs = {
  {Append[acReferenceSingleExternal, Mass[Multiparticle[1, 5]] -> prElectronMass],
    acReferenceRatio["Angle", 41, 5, 3]/PropDen[Mom[Multiparticle[1, 5]], prElectronMass]},
  {Append[acReferenceSingleExternal, Mass[Multiparticle[2, 5]] -> prElectronMass],
    acReferenceRatio["Square", 42, 5, 4]/PropDen[Mom[Multiparticle[2, 5]], prElectronMass]}};
acReferenceSingle = acReferencePrepare[acReferenceSinglePairs, Automatic];
check["Automatic falls back to certified physical references when only one external leg is massless",
  acReferenceSingle["Status"] === "PREPARED" &&
    Flatten[Lookup[Lookup[acReferenceSingle["DiagramReports"], "PolePreference"], "Assignments"], 1][[All, "Target"]] ===
      {2, 1} && FreeQ[acReferenceSingle["Amplitude"], Spinor["Xi", ___]]];
acReferenceSingleSpurious = acReferencePrepare[acReferenceSinglePairs, "AllSpurious"];
check["AllSpurious falls back to eligible physical references without leaving Xi",
  acReferenceSingleSpurious["Status"] === "PREPARED" &&
    Lookup[Flatten[Lookup[Lookup[acReferenceSingleSpurious["DiagramReports"],
      "PolePreference"], "Assignments"], 1], "Mode"] === {"AllPhysical", "AllPhysical"} &&
    FreeQ[acReferenceSingleSpurious["Amplitude"],
      Spinor["Xi", ___] | Indeterminate | ComplexInfinity | _DirectedInfinity]];
acReferenceThreeNullRules = Take[acReferenceRules, 5];
acReferenceFallbackPair = {acReferenceThreeNullRules,
  acReferenceRatio["Angle", 43, 3, 1] acReferenceRatio["Square", 44, 5, 2]};
acReferenceFallbackInventory = {acReferenceFallbackPair,
  {Append[acReferenceThreeNullRules, Mass[Multiparticle[3, 5]] -> 0], 0},
  {Append[acReferenceThreeNullRules, Mass[Multiparticle[4, 5]] -> 0], 0},
  {Append[acReferenceThreeNullRules, Mass[Multiparticle[1, 5]] -> prElectronMass], 0}};
acReferenceFallback = acReferencePrepare[acReferenceFallbackInventory, "AllSpurious"];
check["AllSpurious uses a physical fallback only on legs without spurious choices",
  acReferenceFallback["Status"] === "PREPARED" &&
    Sort[Lookup[acReferenceAssignments[acReferenceFallback], {"Leg", "Mode"}]] ===
      {{3, "AllSpurious"}, {5, "AllPhysical"}} &&
    FreeQ[acReferenceFallback["Amplitude"], Spinor["Xi", ___]]];
check["an unavailable constructive reference cannot reuse its own cut or return Xi",
  FailureQ[PrepareAmplitudes[Take[acReferenceSinglePairs, 1], prModel,
    "PolePreference" -> "AllSpurious", "ProgressReporting" -> False]] &&
    FailureQ[PrepareAmplitudes[Take[acReferenceSinglePairs, 1], prModel,
      "PolePreference" -> "AllSpurious", "Output" -> "Expression",
      "ProgressReporting" -> False]]];
check["unsupported reference choices are rejected before preparation",
  acInvalid[Quiet[PrepareAmplitudes[{acReferencePair}, prModel,
    "PolePreference" -> "Random", "ProgressReporting" -> False]]]];

(* Reference-dependent toy numerators isolate assignment optimization. They are
   not assertions that arbitrary Xi-dependent inputs are physical amplitudes. *)
acOptimizedSpuriousRatio = SpinorChain[Spinor["Xi", "Angle", 61],
    Spinor["Helicity", "Angle", 5]]/
  SpinorChain[Spinor["Xi", "Angle", 61], Spinor["Helicity", "Angle", 3]];
acOptimizedSpuriousPair = {acReferenceRules, (1 + acOptimizedSpuriousRatio)/acDen};
acOptimizedCyclic = acReferencePrepare[{acOptimizedSpuriousPair}, "Cyclic"];
acOptimizedSpurious = acReferencePrepare[{acOptimizedSpuriousPair}, "AllSpurious"];
check["AllSpurious tests a noncyclic reference that reduces the actual numerator",
  acOptimizedSpurious["Status"] === "PREPARED" &&
    acOptimizedSpurious["Amplitude"] === 1/acDen &&
    First[acReferenceAssignments[acOptimizedSpurious]]["Target"] === 5 &&
    First[acReferenceAssignments[acOptimizedCyclic]]["Target"] === 4 &&
    SpinorExpressionComplexity[acOptimizedSpurious["Amplitude"]] <
      SpinorExpressionComplexity[acOptimizedCyclic["Amplitude"]]];
acOptimizedSpuriousAgain = acReferencePrepare[{acOptimizedSpuriousPair}, "AllSpurious"];
check["optimized reference selection is deterministic on repeated identical input",
  acOptimizedSpuriousAgain["Amplitude"] === acOptimizedSpurious["Amplitude"] &&
    acReferenceAssignments[acOptimizedSpuriousAgain] ===
      acReferenceAssignments[acOptimizedSpurious]];
check["reference optimization retains the original pair and its off-shell physical pole",
  acOptimizedSpurious["OriginalAmplitudes"] === {acOptimizedSpuriousPair} &&
    acOptimizedSpurious["PreparedAmplitudes"][[1, 1]] === First[acOptimizedSpuriousPair] &&
    !FreeQ[acOptimizedSpurious["Amplitude"], acDen]];
acReferenceSearch[report_] := First[report["DiagramReports"]]["PolePreference"]["Search"];
check["reference optimization has finite default choices and an automatic shared time sub-budget",
  ("MaxReferenceChoices" /. Options[PrepareAmplitudes]) === Automatic &&
    acOptimizedSpurious["Options"]["MaxReferenceChoices"] === 64 &&
    acOptimizedSpurious["ResourcePolicy"]["Requested"]["MaxReferenceChoices"] === Automatic &&
    ("ReferenceTimeConstraint" /. Options[PrepareAmplitudes]) === Automatic];
check["optimized reference details expose actual reduction scores and a bounded search inventory",
  With[{reference = First[acOptimizedSpurious["DiagramReports"]]["PolePreference"]},
    ContainsAll[Keys[reference], {"ReducedExpression", "ReducedRank", "Search", "Alternatives"}] &&
      reference["ReducedExpression"] === 1/acDen &&
      reference["ReducedRank"][[1]] === SpinorExpressionComplexity[reference["ReducedExpression"]] &&
      reference["Search"]["AvailableChoices"] === 2 &&
      reference["Search"]["CompletedChoices"] === reference["Search"]["TriedChoices"] &&
      TrueQ[reference["Search"]["Exhaustive"]] &&
      OrderedQ[Lookup[reference["Alternatives"], "Rank"]]]];
acOptimizedSpuriousLimited = acReferencePrepare[{acOptimizedSpuriousPair}, "AllSpurious",
  "MaxReferenceChoices" -> 1];
check["a reference-choice cap retains a valid best-so-far assignment without claiming exhaustive search",
  acOptimizedSpuriousLimited["Status"] === "PREPARED" &&
    acReferenceSearch[acOptimizedSpuriousLimited]["TriedChoices"] === 1 &&
    acReferenceSearch[acOptimizedSpuriousLimited]["CompletedChoices"] === 1 &&
    !TrueQ[acReferenceSearch[acOptimizedSpuriousLimited]["Exhaustive"]] &&
    acReferenceSearch[acOptimizedSpuriousLimited]["AvailableChoices"] === 2 &&
    FreeQ[acOptimizedSpuriousLimited["Amplitude"], Spinor["Xi", ___]]];
acLargeReferenceChoices = Table[Table[
  <|"Leg" -> leg, "Mode" -> "AllSpurious", "Target" -> target|>,
  {target, 10}], {leg, 10}];
acLargeReferencePlan = TimeConstrained[
  ConstructiveDiagrams`Private`preparationReferenceSelections[acLargeReferenceChoices, 3],
  2, $TimedOut];
check["a small reference cap never materializes the exponentially large Cartesian product",
  AssociationQ[acLargeReferencePlan] &&
    acLargeReferencePlan["AvailableChoices"] === 10^10 &&
    Length[acLargeReferencePlan["Selections"]] === 3 &&
    Length[DeleteDuplicates[acLargeReferencePlan["Selections"]]] === 3 &&
    First[acLargeReferencePlan["Selections"]] === First /@ acLargeReferenceChoices &&
    AllTrue[acLargeReferencePlan["Selections"], Function[selection,
      And @@ MapThread[MemberQ, {acLargeReferenceChoices, selection}]]]];
acOptimizedSharedLegPair = {acReferenceRules,
  (1 + acOptimizedSpuriousRatio + SpinorChain[Spinor["Xi", "Square", 65],
      Spinor["Helicity", "Square", 5]]/
    SpinorChain[Spinor["Xi", "Square", 65], Spinor["Helicity", "Square", 3]])/acDen};
acOptimizedSharedLeg = acReferencePrepare[{acOptimizedSharedLegPair}, "AllSpurious"];
check["different Xi labels and chiralities for one photon share one reference choice",
  acOptimizedSharedLeg["Amplitude"] === 1/acDen &&
    Length[acReferenceAssignments[acOptimizedSharedLeg]] === 2 &&
    DeleteDuplicates[({#["Leg"], #["Target"], #["Mode"]} &) /@
      acReferenceAssignments[acOptimizedSharedLeg]] === {{3, 5, "AllSpurious"}} &&
    acReferenceSearch[acOptimizedSharedLeg]["AvailableChoices"] === 2];

acOptimizedPhysicalExternal = Join[
  Thread[(Mass /@ Range[4]) -> ConstantArray[prElectronMass, 4]], {Mass[5] -> 0}];
acOptimizedPhysicalDen = PropDen[Mom[Multiparticle[1, 5]], prElectronMass];
acOptimizedPhysicalPair = {
  Append[acOptimizedPhysicalExternal, Mass[Multiparticle[1, 5]] -> prElectronMass],
  (1 + acReferenceRatio["Angle", 62, 5, 3])/acOptimizedPhysicalDen};
acOptimizedPhysicalPairs = Join[{acOptimizedPhysicalPair}, Table[{
  Append[acOptimizedPhysicalExternal, Mass[Multiparticle[leg, 5]] -> prElectronMass], 1}, {leg, {2, 3}}]];
acOptimizedPhysical = acReferencePrepare[acOptimizedPhysicalPairs, "AllPhysical"];
acOptimizedPhysicalLimited = acReferencePrepare[acOptimizedPhysicalPairs, "AllPhysical",
  "MaxReferenceChoices" -> 1];
check["AllPhysical compares allowed targets instead of always taking the first massive particle",
  acOptimizedPhysical["Status"] === "PREPARED" &&
    First[acReferenceAssignments[acOptimizedPhysical]]["Target"] === 3 &&
    First[acReferenceAssignments[acOptimizedPhysicalLimited]]["Target"] === 2 &&
    First[acOptimizedPhysical["DiagramReports"]]["PreparedExpression"] ===
      1/acOptimizedPhysicalDen &&
    SpinorExpressionComplexity[First[acOptimizedPhysical["DiagramReports"]]["PreparedExpression"]] <
      SpinorExpressionComplexity[First[acOptimizedPhysicalLimited["DiagramReports"]]["PreparedExpression"]]];
check["optimized physical references retain each original diagram's own shell context",
  First /@ acOptimizedPhysical["PreparedAmplitudes"] === First /@ acOptimizedPhysicalPairs &&
    First[acOptimizedPhysical["DiagramReports"]]["InternalOnShellChannels"] === {{1, 5}} &&
    !FreeQ[First[acOptimizedPhysical["DiagramReports"]]["PreparedExpression"], acOptimizedPhysicalDen]];

acOptimizedMixedRatio = acReferenceRatio["Angle", 64, 4, 2];
acOptimizedMixedPair = {acReferenceRules,
  (1 + acReferenceWeightA acOptimizedSpuriousRatio +
    acReferenceWeightB acOptimizedMixedRatio)/acDen};
acOptimizedMixedPairs = Join[{acOptimizedMixedPair}, Table[{
  Append[Take[acReferenceRules, 5], Mass[Multiparticle[2, leg]] -> prElectronMass], 1}, {leg, {3, 4}}]];
acOptimizedMixed = acReferencePrepare[acOptimizedMixedPairs, "Mixed"];
acOptimizedMixedSpurious = acReferencePrepare[acOptimizedMixedPairs, "AllSpurious"];
acOptimizedMixedPhysical = acReferencePrepare[acOptimizedMixedPairs, "AllPhysical"];
check["Mixed can choose a genuinely mixed assignment after reducing the whole numerator",
  acOptimizedMixed["Status"] === "PREPARED" &&
    First[acOptimizedMixed["DiagramReports"]]["PreparedExpression"] === 1/acDen &&
    Sort[Lookup[acReferenceAssignments[acOptimizedMixed], "Mode"]] ===
      {"AllPhysical", "AllSpurious"} &&
    First[acOptimizedMixedSpurious["DiagramReports"]]["PreparedExpression"] =!= 1/acDen &&
    First[acOptimizedMixedPhysical["DiagramReports"]]["PreparedExpression"] =!= 1/acDen];
acOptimizedAllSpuriousMixed = acReferencePrepare[{acOptimizedSpuriousPair}, "Mixed"];
check["Mixed also permits an all-spurious winner when that is best",
  acOptimizedAllSpuriousMixed["Amplitude"] === 1/acDen &&
    First[acReferenceAssignments[acOptimizedAllSpuriousMixed]]["Mode"] === "AllSpurious"];
acOptimizedAllPhysicalMixed = acReferencePrepare[acOptimizedPhysicalPairs, "Mixed"];
check["Mixed also permits an all-physical winner when no spurious partner exists",
  First[acOptimizedAllPhysicalMixed["DiagramReports"]]["PreparedExpression"] ===
    1/acOptimizedPhysicalDen &&
    First[acReferenceAssignments[acOptimizedAllPhysicalMixed]]["Mode"] === "AllPhysical"];
acOptimizedPhysicalCompetitionPairs = {
  {acReferenceRules, (1 + acReferenceRatio["Angle", 66, 3, 2])/acDen},
  {Append[Take[acReferenceRules, 5], Mass[Multiparticle[2, 3]] -> prElectronMass], 1}};
acOptimizedPhysicalCompetition = acReferencePrepare[acOptimizedPhysicalCompetitionPairs, "Mixed"];
check["Mixed can prefer an all-physical winner even when spurious partners are available",
  First[acOptimizedPhysicalCompetition["DiagramReports"]]["PreparedExpression"] === 1/acDen &&
    First[acReferenceAssignments[acOptimizedPhysicalCompetition]]["Mode"] === "AllPhysical" &&
    First[acReferenceAssignments[acOptimizedPhysicalCompetition]]["Target"] === 2];
check["a new reference mode does not change an input with no Xi spinors",
  PrepareAmplitudes[{acDiracPair}, prModel, "PolePreference" -> "Mixed",
    "MaxSteps" -> 0, "ProgressReporting" -> False] === acPreparedPairs];
check["an infinite reference sub-budget remains valid for an input with no Xi spinors",
  PrepareAmplitudes[{acDiracPair}, prModel, "PolePreference" -> "Mixed",
    "ReferenceTimeConstraint" -> Infinity, "MaxSteps" -> 0,
    "ProgressReporting" -> False] === acPreparedPairs];
acReferenceOptimizationEvents = {};
acReferenceProgress = PrepareAmplitudes[{acOptimizedSpuriousPair}, prModel,
  "PolePreference" -> "AllSpurious", "MaxSteps" -> 0,
  "ProgressReporting" -> True, "ProgressFunction" -> (AppendTo[acReferenceOptimizationEvents, #] &),
  "ReturnDetails" -> True];
acReferenceChoosingEvents = Select[acReferenceOptimizationEvents,
  Lookup[#, "Operation", ""] === "Choosing references" &];
check["reference optimization reports live tried-choice counts and best known complexity",
  acReferenceChoosingEvents =!= {} &&
    AllTrue[acReferenceChoosingEvents,
      ContainsAll[Keys[#], {"Completed", "Total", "Complexity", "Terms"}] &&
        #["Completed"] <= #["Total"] &] &&
    OrderedQ[Lookup[acReferenceChoosingEvents, "Completed"]] &&
    Last[acReferenceChoosingEvents]["Completed"] ===
      acReferenceSearch[acReferenceProgress]["TriedChoices"]];
acReferencePostSelectionPaused = False;
acReferencePostSelectionTimed = PrepareAmplitudes[{acOptimizedSpuriousPair}, prModel,
  "PolePreference" -> "AllSpurious", "MaxSteps" -> 0,
  "ReferenceTimeConstraint" -> Infinity, "TimeConstraint" -> 1,
  "ProgressReporting" -> True, "ReturnDetails" -> True,
  "ProgressFunction" -> (If[Lookup[#, "Operation", ""] === "ReduceSpinorProducts",
    acReferencePostSelectionPaused = True; Pause[1.1]] &)];
check["an overall timeout after reference selection retains the completed reduced winning trial",
  TrueQ[acReferencePostSelectionPaused] &&
    acReferencePostSelectionTimed["Status"] === "PARTIAL" &&
    acReferencePostSelectionTimed["Amplitude"] === acOptimizedSpurious["Amplitude"] &&
    acReferenceAssignments[acReferencePostSelectionTimed] ===
      acReferenceAssignments[acOptimizedSpurious] &&
    With[{diagram = First[acReferencePostSelectionTimed["DiagramReports"]]},
      diagram["StopReason"] === "TimeConstraint" &&
        diagram["PreparedExpression"] === diagram["PolePreference"]["ReducedExpression"] &&
        MemberQ[Lookup[diagram["Reductions"], "Operation"], "RetainedReferenceTrial"]] &&
    !FreeQ[acReferencePostSelectionTimed["Amplitude"], acDen]];
acReferenceSubTimed = acReferencePrepare[{acOptimizedSpuriousPair}, "AllSpurious",
  "ReferenceTimeConstraint" -> 0.000001];
check["reference sub-timeouts retain a valid fallback or an honestly partial original input",
  acReferenceSubTimed["OriginalAmplitudes"] === {acOptimizedSpuriousPair} &&
    !TrueQ[acReferenceSearch[acReferenceSubTimed]["Exhaustive"]] &&
    acReferenceSearch[acReferenceSubTimed]["CompletedChoices"] <=
      acReferenceSearch[acReferenceSubTimed]["TriedChoices"] &&
    FreeQ[acReferenceSubTimed["Amplitude"], Indeterminate | ComplexInfinity | _DirectedInfinity] &&
    If[acReferenceSubTimed["Status"] === "PREPARED",
      FreeQ[acReferenceSubTimed["Amplitude"], Spinor["Xi", ___]] &&
        First[acReferenceSubTimed["DiagramReports"]]["PolePreference"]["Status"] === "COMPLETE" &&
        If[acReferenceSearch[acReferenceSubTimed]["CompletedChoices"] === 0,
          First[acReferenceSubTimed["DiagramReports"]]["PolePreference"]["Diagnostics"] =!= {},
          True],
      acReferenceSubTimed["Status"] === "PARTIAL"]];
acMasslessScalarModel = {{{"Scalar", "s", "s", 1, 0, 0, 0, 1, 1, "", ""}},
  {}, {}, {}};
acExternalZero = Thread[(Mass /@ Range[4]) -> ConstantArray[0, 4]];
acLocalPairs = Table[{Append[acExternalZero, Mass[Multiparticle[1, 2]] -> mass],
  (3 + MomProd[1, 2])/PropDen[Mom[Multiparticle[1, 2]], mass]}, {mass, {1, 2}}];
acLocal = PrepareAmplitudes[acLocalPairs, acMasslessScalarModel,
  "Output" -> "Details", "MaxSteps" -> 4, "ProgressReporting" -> False];
check["the same numerator uses only its own diagram's internal mass condition",
  Last /@ acLocal["PreparedAmplitudes"] === {
    7/(2 PropDen[Mom[Multiparticle[1, 2]], 1]),
    5/PropDen[Mom[Multiparticle[1, 2]], 2]}];
check["each accepted internal-shell reduction is retained in the preparation history",
  AllTrue[acLocal["DiagramReports"], Function[report,
    AnyTrue[Join[report["Reductions"], report["IdentitySteps"]],
      TrueQ[Lookup[#, "InternalOnShellIdentity", False]] ||
        Lookup[#, "Name", None] === "OnShell" &]]]];
acLocalOff = PrepareAmplitudes[acLocalPairs, acMasslessScalarModel,
  "InternalOnShell" -> False, "MaxSteps" -> 4, "ProgressReporting" -> False,
  "Output" -> "Details"];
check["internal numerator-shell reductions can be disabled independently",
  AllTrue[Last /@ acLocalOff["PreparedAmplitudes"], !FreeQ[#, _MomProd | _SpinorChain] &] &&
    AllTrue[acLocalOff["DiagramReports"], #["InternalOnShellChannels"] === {} &&
      AllTrue[#["IdentitySteps"], #["Name"] =!= "OnShell" &] &]];
Do[
  acConflictingRules = Join[acExternalZero,
    {Mass[Multiparticle[1, 2]] -> 1, Mass[cut] -> 2}];
  check["contradictory diagram-shell masses are rejected before identity search " <> ToString[cut, InputForm],
    Quiet[PrepareAmplitudes[{{acConflictingRules,
      MomProd[1, 2]/PropDen[Mom[Multiparticle[1, 2]], 1]}}, acMasslessScalarModel,
      "PolePreference" -> None, "MaxSteps" -> 4,
      "ProgressReporting" -> False]] === $Failed],
  {cut, {Multiparticle[1, 2], Multiparticle[2, 1]}}];
check["contradictory external masses are rejected before applying external equations of motion",
  Quiet[PrepareAmplitudes[{{Append[acExternalZero, Mass[1] -> 1],
    SpinorChain[Spinor["Spin", "Angle", 1], Mom[1], Spinor["Spin", "Square", 2]]}},
    acMasslessScalarModel, "PolePreference" -> None,
    "ProgressReporting" -> False]] === $Failed];
acEquivalentShellRules = Join[acExternalZero,
  {Mass[Multiparticle[1, 2]] -> acShellParameter (acShellParameter + 1),
    Mass[Multiparticle[2, 1]] -> acShellParameter^2 + acShellParameter}];
acEquivalentShellPair = {acEquivalentShellRules,
  MomProd[1, 2]/PropDen[Mom[Multiparticle[1, 2]], acShellParameter (acShellParameter + 1)]};
acEquivalentShellPrepared = PrepareAmplitudes[{acEquivalentShellPair}, acMasslessScalarModel,
  "PolePreference" -> None, "MaxSteps" -> 0,
  "ProgressReporting" -> False, "ReturnDetails" -> True];
check["algebraically equal reversed-cut mass declarations are accepted without mutating input metadata",
  acEquivalentShellPrepared["Status"] === "PREPARED" &&
    acZero[acEquivalentShellPrepared["Amplitude"] - acShellParameter^2 (acShellParameter + 1)^2/
      (2 PropDen[Mom[Multiparticle[1, 2]], acShellParameter (acShellParameter + 1)])] &&
    First[First[acEquivalentShellPrepared["PreparedAmplitudes"]]] === acEquivalentShellRules &&
    acEquivalentShellPrepared["OriginalAmplitudes"] === {acEquivalentShellPair}];
acDuplicateExternalRules = Join[acExternalZero, {Mass[1] -> acShellParameter - acShellParameter}];
acDuplicateExternalPrepared = PrepareAmplitudes[{{acDuplicateExternalRules,
    SpinorChain[Spinor["Xi", "Square", 71], Total[Mom /@ Range[4]],
      Spinor["Xi", "Angle", 73]]}}, acMasslessScalarModel,
  "PolePreference" -> None, "InternalOnShell" -> False, "MaxSteps" -> 2,
  "ProgressReporting" -> False];
check["equivalent repeated external rules do not duplicate momenta in conservation",
  Last[First[acDuplicateExternalPrepared]] === 0 &&
    First[First[acDuplicateExternalPrepared]] === acDuplicateExternalRules];
acReorderedLocalPairs = {First[acLocalPairs], {Reverse[First[Last[acLocalPairs]]], Last[Last[acLocalPairs]]}};
acReorderedLocalPrepared = PrepareAmplitudes[acReorderedLocalPairs, acMasslessScalarModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False];
check["external rule order is immaterial while different diagrams retain their distinct internal shells",
  Last /@ acReorderedLocalPrepared === Last /@ acLocal["PreparedAmplitudes"] &&
    First /@ acReorderedLocalPrepared === First /@ acReorderedLocalPairs];

(* Declared pair masses determine scalar products without a heuristic search. *)
acDotExternal = {Mass[1] -> prElectronMass, Mass[2] -> prElectronMass,
  Mass[3] -> 0, Mass[4] -> 0, Mass[5] -> 0};
acDotRules = Append[acDotExternal, Mass[Multiparticle[2, 5]] -> prElectronMass];
acDotDen = PropDen[Mom[Multiparticle[2, 5]], prElectronMass];
acDotPair = {acDotRules, (3 + MomProd[2, 5])/acDotDen};
acDotPrepared = PrepareAmplitudes[{acDotPair}, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> False, "ReturnDetails" -> True];
check["a known internal pair removes its zero scalar product even when MaxSteps is zero",
  acDotPrepared["Status"] === "PREPARED" && acDotPrepared["Amplitude"] === 3/acDotDen];
check["deterministic pair-mass reduction is recorded as a diagram-local numerator identity",
  AnyTrue[First[acDotPrepared["DiagramReports"]]["Reductions"],
    TrueQ[Lookup[#, "InternalOnShellIdentity", False]] &&
      Lookup[#, "Before", None] =!= Lookup[#, "After", None] &]];
acDotReverse = PrepareAmplitudes[{{acDotRules,
    (3 + MomProd[5, 2])/acDotDen}}, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> False];
check["the reversed scalar-product ordering uses the same known pair mass",
  Last[First[acDotReverse]] === 3/acDotDen];
acDotReverseMass = PrepareAmplitudes[{{
    Append[acDotExternal, Mass[Multiparticle[5, 2]] -> prElectronMass], Last[acDotPair]}}, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> False];
check["reversed particle order in a declared pair mass is recognized",
  Last[First[acDotReverseMass]] === 3/acDotDen];
acDotLocalPairs = Table[{
    Append[acDotExternal, Mass[Multiparticle[2, 5]] -> mass],
    (3 + MomProd[2, 5])/PropDen[Mom[Multiparticle[2, 5]], mass]},
  {mass, {prElectronMass, 2 prElectronMass}}];
acDotLocal = PrepareAmplitudes[acDotLocalPairs, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> False];
check["identical scalar products use only each diagram's own symbolic internal mass",
  And @@ MapThread[acZero[#1 - #2] &,
    {Last /@ acDotLocal, {3/acDotDen,
      (3 + 3 prElectronMass^2/2)/PropDen[Mom[Multiparticle[2, 5]], 2 prElectronMass]}}]];
acDotUnknownPair = {acDotRules, (3 + MomProd[2, 4])/acDotDen};
acDotUnknown = PrepareAmplitudes[{acDotUnknownPair}, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> False];
check["unknown pair masses are neither assumed nor introduced into the expression",
  acZero[Last[First[acDotUnknown]] - Last[acDotUnknownPair]] &&
    FreeQ[Last[First[acDotUnknown]], Mass[_Multiparticle]]];
acDotComplementRules = Append[acDotExternal, Mass[Multiparticle[1, 3, 4]] -> prElectronMass];
acDotComplementDen = PropDen[Mom[Multiparticle[1, 3, 4]], prElectronMass];
acDotComplementPair = {acDotComplementRules, (3 + MomProd[2, 5])/acDotComplementDen};
acDotComplement = PrepareAmplitudes[{acDotComplementPair}, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> False];
check["a known larger cut determines its two-particle complement through momentum conservation",
  Last[First[acDotComplement]] === 3/acDotComplementDen];
acDotComplementOff = PrepareAmplitudes[{acDotComplementPair}, prModel,
  "MomentumConservation" -> False, "MaxSteps" -> 0, "ProgressReporting" -> False];
check["disabling momentum conservation disables inferred complementary pair masses",
  acZero[Last[First[acDotComplementOff]] - Last[acDotComplementPair]]];
acDotTripleRules = Append[Append[acDotExternal, Mass[6] -> 0],
  Mass[Multiparticle[1, 2, 3]] -> prElectronMass];
acDotTriplePair = {acDotTripleRules,
  (3 + MomProd[2, 5])/PropDen[Mom[Multiparticle[1, 2, 3]], prElectronMass]};
acDotTriple = PrepareAmplitudes[{acDotTriplePair}, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> False];
check["a three-particle cut and three-particle complement do not determine an individual pair",
  acZero[Last[First[acDotTriple]] - Last[acDotTriplePair]]];
acDotDisabled = PrepareAmplitudes[{acDotPair}, prModel,
  "InternalOnShell" -> False, "MaxSteps" -> 0, "ProgressReporting" -> False];
check["InternalOnShell False disables deterministic internal pair-mass reduction",
  acZero[Last[First[acDotDisabled]] - Last[acDotPair]]];
acDotDenominatorPair = {acDotRules,
  (3 + MomProd[2, 5])/(acDotDen (5 + MomProd[2, 5]))};
acDotDenominatorExpected = 3/(acDotDen (5 + MomProd[2, 5]));
acDotDenominatorPrepared = PrepareAmplitudes[{acDotDenominatorPair}, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> False];
check["pair-mass reductions preserve both physical propagators and other denominator factors",
  Last[First[acDotDenominatorPrepared]] === acDotDenominatorExpected];
acDotInversePair = {acDotRules, (3 + MomProd[2, 5])/(acDotDen MomProd[2, 5])};
acDotInversePrepared = PrepareAmplitudes[{acDotInversePair}, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> False];
check["an inverse scalar product is not incorrectly put on the numerator shell",
  acZero[Last[First[acDotInversePrepared]] - 3/(acDotDen MomProd[2, 5])]];
acDotNestedPair = {acDotRules,
  (3 + (1 + MomProd[2, 5])/(5 + MomProd[2, 5]))/acDotDen};
acDotNested = PrepareAmplitudes[{acDotNestedPair}, prModel,
  "MaxSteps" -> 0, "ProgressReporting" -> False];
check["nested inverse factors retain their off-shell scalar product while positive factors reduce",
  acZero[Last[First[acDotNested]] - (3 + 1/(5 + MomProd[2, 5]))/acDotDen] &&
    !FreeQ[Last[First[acDotNested]], MomProd[2, 5]]];
acDotDenominatorSearch = PrepareAmplitudes[{acDotDenominatorPair}, prModel,
  "MaxSteps" -> 4, "ProgressReporting" -> False];
check["subsequent identity search cannot reuse numerator shells inside denominators",
  Last[First[acDotDenominatorSearch]] === acDotDenominatorExpected];
Do[
  acUnknownPowerPair = {Append[acExternalZero, Mass[Multiparticle[1, 2]] -> 1],
    (3 + MomProd[1, 2]^power)^2/PropDen[Mom[Multiparticle[1, 2]], 1]};
  acUnknownPowerPrepared = PrepareAmplitudes[{acUnknownPowerPair}, acMasslessScalarModel,
    "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False];
  check["an exponent with unknown sign protects its base from internal-shell substitution " <>
      ToString[power, InputForm],
    acZero[Last[First[acUnknownPowerPrepared]] - Expand[Last[acUnknownPowerPair]]] &&
      !FreeQ[Last[First[acUnknownPowerPrepared]], MomProd[1, 2]]],
  {power, {acShellPower, -acShellPower}}];
acPositivePowerPair = {Append[acExternalZero, Mass[Multiparticle[1, 2]] -> 1],
  (3 + MomProd[1, 2]^2)^2/PropDen[Mom[Multiparticle[1, 2]], 1]};
acPositivePowerPrepared = PrepareAmplitudes[{acPositivePowerPair}, acMasslessScalarModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False];
check["nonnegative integer powers still receive diagram-local numerator shell reductions",
  Last[First[acPositivePowerPrepared]] === 169/(16 PropDen[Mom[Multiparticle[1, 2]], 1])];
acExternalUnknownPower = (3 + SpinorChain[Spinor["Spin", "Square", 1], Mom[2],
    Spinor["Spin", "Angle", 2]]^(-acShellPower))^2/acDen;
acExternalUnknownPowerPrepared = PrepareAmplitudes[{{acRules, acExternalUnknownPower}}, prModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False];
check["ordinary external spinor reduction still acts inside an unknown-sign power",
  acZero[Last[First[acExternalUnknownPowerPrepared]] - (ReduceSpinorProducts[acExternalUnknownPower] /. acRules)] &&
    FreeQ[Last[First[acExternalUnknownPowerPrepared]], SpinorChain[___, _Mom, ___]]];

(* Ordinary spinor identities also act in reciprocal factors. Internal diagram
   shells remain restricted to positive numerator factors. *)
acWholeBracket = SpinorChain[Spinor["Helicity", "Angle", 3], Spinor["Xi", "Angle", 77]];
acWholeReverseBracket = SpinorChain[Spinor["Xi", "Angle", 77], Spinor["Helicity", "Angle", 3]];
acWholeBracketPrepared = PrepareAmplitudes[{{acRules,
    acWholeBracket/(acDen acWholeReverseBracket)}}, prModel,
  "PolePreference" -> None, "InternalOnShell" -> False, "MaxSteps" -> 0,
  "ProgressReporting" -> False];
check["whole-expression reduction cancels an auxiliary bracket with its reversed denominator",
  Last[First[acWholeBracketPrepared]] === -1/acDen];
Do[
  acWholeOtherKind = If[acWholeKind === "Angle", "Square", "Angle"];
  acWholeDiracChain = SpinorChain[Spinor["Spin", acWholeOtherKind, 1], Mom[2],
    Spinor["Spin", acWholeKind, 2]];
  acWholeDiracBracket = SpinorChain[Spinor["Spin", acWholeOtherKind, 1],
    Spinor["Spin", acWholeOtherKind, 2]];
  acWholeDiracPrepared = PrepareAmplitudes[{{acRules, 1/(acDen acWholeDiracChain)}},
    prModel, "PolePreference" -> None, "InternalOnShell" -> False, "MaxSteps" -> 0,
    "ProgressReporting" -> False];
  check["external Dirac identities reduce a reciprocal chain " <> acWholeKind,
    Last[First[acWholeDiracPrepared]] === -1/(prElectronMass acDen acWholeDiracBracket)],
  {acWholeKind, {"Angle", "Square"}}];
acWholeTracePrepared = PrepareAmplitudes[{{acRules,
    1/(acDen SpinorTrace[Mom[1], Mom[1]])}}, prModel,
  "PolePreference" -> None, "InternalOnShell" -> False, "MaxSteps" -> 0,
  "ProgressReporting" -> False];
check["ordinary trace identities reduce a reciprocal trace without touching its physical pole",
  Last[First[acWholeTracePrepared]] === 1/(2 prElectronMass^2 acDen)];
acWholeShellDirac = SpinorChain[Spinor["Spin", "Square", 1], Mom[2],
  Spinor["Spin", "Angle", 2]];
acWholeShellPrepared = PrepareAmplitudes[{{acDotRules,
    (3 + MomProd[2, 5])/(acDotDen (5 + MomProd[2, 5]) acWholeShellDirac)}}, prModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False];
check["ordinary denominator spinor reduction does not apply an internal scalar shell there",
  Last[First[acWholeShellPrepared]] === -3/(prElectronMass acDotDen (5 + MomProd[2, 5])
    SpinorChain[Spinor["Spin", "Square", 1], Spinor["Spin", "Square", 2]])];
acKnownNumeratorDotCount[pair_] := Module[{declared, external, known, terms},
  external = Sort[Cases[First[pair], HoldPattern[Mass[i_Integer] -> _] :> i]];
  declared = Cases[First[pair], HoldPattern[Mass[cut_Multiparticle] -> _] :>
    Sort[List @@ cut]];
  known = Select[Join[declared, Complement[external, #] & /@ declared], Length[#] === 2 &];
  terms = If[Head[Last[pair]] === Plus, List @@ Last[pair], {Last[pair]}];
  Total[Function[term, Length[Select[Cases[Numerator[term], _MomProd, {0, Infinity}],
    Function[product, MemberQ[known, Sort[List @@ product]]]]]] /@ terms]
];
acDotQEDPairs = DiagramAmplitudes[CreateDiagrams[
  {"e", "E", "A.+", "A.+", "A.+"}, prModel]];
acDotQEDPrepared = PrepareAmplitudes[acDotQEDPairs, prModel,
  "PolePreference" -> "AllSpurious", "MaxSteps" -> 0,
  "ProgressReporting" -> False, "ReturnDetails" -> True];
(* Optimized references may avoid producing these dots at all. The explicit
   nonzero scalar-product fixtures above separately exercise their reduction. *)
check["all six actual QED diagrams exhaust their declared-pair numerator scalar products",
  acDotQEDPrepared["Status"] === "PREPARED" &&
    Length[acDotQEDPrepared["PreparedAmplitudes"]] === 6 &&
    Total[acKnownNumeratorDotCount /@ acDotQEDPrepared["PreparedAmplitudes"]] === 0];
check["scalar-product preparation retains original inputs, mass-rule scope and propagators",
  acDotQEDPrepared["OriginalAmplitudes"] === acDotQEDPairs &&
    First /@ acDotQEDPrepared["PreparedAmplitudes"] === First /@ acDotQEDPairs &&
    And @@ MapThread[ContainsAll[DeleteDuplicates[Cases[Last[#1], _PropDen, Infinity]],
        DeleteDuplicates[Cases[Last[#2], _PropDen, Infinity]]] &,
      {acDotQEDPrepared["PreparedAmplitudes"], acDotQEDPairs}]];

(* Momentum conservation belongs to preparation, with the complete declared leg
   set and strictly improving trials on the whole numerator. *)
acConservationLabels = {2, 5, 8, 11};
acConservationRules = Thread[(Mass /@ acConservationLabels) -> ConstantArray[0, 4]];
acConservationRow = MomProd[2, 5] + MomProd[2, 8] + MomProd[2, 11];
acConservationDen = PropDen[Mom[Multiparticle[2, 5]], acShellMass];
acConservationPair = {acConservationRules,
  Expand[3 + acConservationRow^2]/(acConservationDen (5 + MomProd[2, 5]))};
acConservationPrepared = PrepareAmplitudes[{acConservationPair}, acMasslessScalarModel,
  "PolePreference" -> None, "InternalOnShell" -> False, "MaxSteps" -> 4,
  "ProgressReporting" -> False, "ReturnDetails" -> True];
check["whole-numerator conservation simplifies a squared row with noncontiguous particle labels",
  acConservationPrepared["Status"] === "PREPARED" &&
    acZero[acConservationPrepared["Amplitude"] - 3/(acConservationDen (5 + MomProd[2, 5]))]];
check["whole-numerator conservation preserves physical and other inverse factors literally",
  Denominator[acConservationPrepared["Amplitude"]] ===
    Denominator[3/(acConservationDen (5 + MomProd[2, 5]))]];
check["accepted whole-numerator conservation has a strict recorded rank improvement",
  AnyTrue[First[acConservationPrepared["DiagramReports"]]["IdentitySteps"],
    Lookup[Lookup[#, "Edit", <||>], "PreparationConservation", False] === True &&
      OrderedQ[{Lookup[#, "AfterRank", Infinity], Lookup[#, "BeforeRank", -Infinity]}] &&
      Lookup[#, "AfterRank", None] =!= Lookup[#, "BeforeRank", None] &]];
acConservationOff = PrepareAmplitudes[{acConservationPair}, acMasslessScalarModel,
  "PolePreference" -> None, "InternalOnShell" -> False, "MomentumConservation" -> False,
  "MaxSteps" -> 4, "ProgressReporting" -> False, "ReturnDetails" -> True];
check["disabling preparation conservation preserves the unconserved row-square value",
  Module[{angles, squares, momenta, epsilon = {{0, 1}, {-1, 0}}, adjugate, value},
    angles = AssociationThread[acConservationLabels, {{1, 2}, {2, -1}, {3, 1}, {-2, 3}}];
    squares = AssociationThread[acConservationLabels, {{2, 3}, {-1, 2}, {1, -3}, {4, 1}}];
    momenta = AssociationThread[acConservationLabels,
      -Outer[Times, angles[#], squares[#].epsilon] & /@ acConservationLabels];
    adjugate[p_] := {{p[[2, 2]], -p[[1, 2]]}, {-p[[2, 1]], p[[1, 1]]}};
    value[expression_] := Together[expression /. {
      SpinorChain[Spinor["Helicity", kind_, i_], Spinor["Helicity", kind_, j_]] :>
        If[kind === "Angle", angles[i].epsilon.angles[j], -squares[i].epsilon.squares[j]],
      MomProd[i_, j_] :> Tr[momenta[i].adjugate[momenta[j]]]/2}];
    Total[Values[momenta]] =!= ConstantArray[0, {2, 2}] &&
      value[acConservationOff["Amplitude"] - Last[acConservationPair]] === 0 &&
      AllTrue[First[acConservationOff["DiagramReports"]]["IdentitySteps"],
        Lookup[#, "Name", None] =!= "MomentumConservation" &]]];
acConservationZeroSteps = PrepareAmplitudes[{acConservationPair}, acMasslessScalarModel,
  "PolePreference" -> None, "InternalOnShell" -> False, "MaxSteps" -> 0,
  "ProgressReporting" -> False];
check["MaxSteps zero retains basic reduction without entering conservation search",
  acZero[Last[First[acConservationZeroSteps]] - Last[acConservationPair]]];
acConservationTwice = PrepareAmplitudes[acConservationPrepared["PreparedAmplitudes"],
  acMasslessScalarModel, "PolePreference" -> None, "InternalOnShell" -> False,
  "MaxSteps" -> 4, "ProgressReporting" -> False, "ReturnDetails" -> True];
check["conservation preparation is idempotent and records no cycling edits",
  acConservationTwice["PreparedAmplitudes"] === acConservationPrepared["PreparedAmplitudes"] &&
    First[acConservationTwice["DiagramReports"]]["IdentitySteps"] === {}];
acConservationChain = SpinorChain[Spinor["Xi", "Square", 19],
  Total[Mom /@ acConservationLabels], Spinor["Xi", "Angle", 23]];
acConservationChainPrepared = PrepareAmplitudes[{{acConservationRules, acConservationChain}},
  acMasslessScalarModel, "PolePreference" -> None, "InternalOnShell" -> False,
  "MaxSteps" -> 2, "ProgressReporting" -> False];
check["preparation knows the explicit conserved external set rather than a contiguous range",
  Last[First[acConservationChainPrepared]] === 0 && ReduceSpinorProducts[acConservationChain] =!= 0];
acLinearConservationRules = Append[acConservationRules, First[acConservationRules]];
acLinearConservation[value_, conserve_] := ConstructiveDiagrams`Private`preparationConservedMomentumChains[
  value, acLinearConservationRules, conserve];
acScaledConservationChain = SpinorChain[Spinor["Xi", "Square", 19],
  (3 + acConservationCoefficient) Total[Mom /@ acConservationLabels], Spinor["Xi", "Angle", 23]];
check["a common scalar multiple of the declared total momentum vanishes with duplicate external rules",
  acLinearConservation[acScaledConservationChain, True] === 0];
check["disabling conservation preserves a nonzero linear total-momentum chain",
    acLinearConservation[acScaledConservationChain, False] === acScaledConservationChain &&
    ReduceSpinorProducts[acScaledConservationChain] =!= 0];
check["linear conservation never discards an undeclared momentum label",
  acLinearConservation[acConservationChain /. Mom[Last[acConservationLabels]] -> Mom[97], True] =!= 0];
check["linear conservation never discards unequal momentum coefficients",
    acLinearConservation[acConservationChain /. Mom[Last[acConservationLabels]] ->
      2 Mom[Last[acConservationLabels]], True] =!= 0];
acConservationOpaque = PropDen[acOpaqueConservationArgument[acConservationChain], acOpaqueConservationMass];
check["the linear total-momentum rule leaves inverse chains and original propagator arguments opaque",
  acLinearConservation[1/acConservationChain, True] === 1/acConservationChain &&
    acLinearConservation[acConservationOpaque, True] === acConservationOpaque];
acPartial = PrepareAmplitudes[acLocalPairs, acMasslessScalarModel,
  "TimeConstraint" -> 0.000001, "ProgressReporting" -> False, "Output" -> "Details"];
check["preparation timeouts retain original inputs and the last valid expression",
  acPartial["Status"] === "PARTIAL" &&
    acPartial["OriginalAmplitudes"] === acLocalPairs &&
    Length[acPartial["PreparedAmplitudes"]] === Length[acLocalPairs]];
check["empty diagram preparation stays empty",
  PrepareAmplitudes[{}, prModel, "ProgressReporting" -> False] === {}];
check["empty preparation still supports explicit summed-expression output",
  PrepareAmplitudes[{}, prModel, "ProgressReporting" -> False,
    "Output" -> "Expression"] === 0];
Do[
  check["invalid preparation input or option is rejected " <> ToString[bad, InputForm],
    acInvalid[Quiet[PrepareAmplitudes[{acDiracPair}, prModel, bad]]]],
  {bad, {"MaxSteps" -> -1, "MaxCandidates" -> 0, "InternalOnShell" -> "Maybe",
    "MaxReferenceChoices" -> 0, "MaxReferenceChoices" -> 1.5,
    "ReferenceTimeConstraint" -> 0, "ReferenceTimeConstraint" -> "Forever",
    "TimeConstraint" -> 0, "Output" -> "Everything", "ReturnDetails" -> "Yes",
    "ReturnDetails" -> 1}}
];
check["a malformed preparation model is rejected",
  acInvalid[Quiet[PrepareAmplitudes[{acDiracPair}, {}]]]];
Do[
  check["failed or nonfinite diagram expressions are rejected " <> ToString[bad, InputForm],
    acInvalid[Quiet[PrepareAmplitudes[{{acRules, bad}}, prModel,
      "MaxSteps" -> 0, "ProgressReporting" -> False]]]],
  {bad, {$Failed, Missing["DiagramFailure"], Infinity}}
];
check["nonfinite diagram mass rules are rejected",
  acInvalid[Quiet[PrepareAmplitudes[{{{Mass[1] -> Infinity}, 1}}, prModel,
    "ProgressReporting" -> False]]]];
acInvalidReduction = Block[{ConstructiveDiagrams`Private`preparationNumerators},
  ConstructiveDiagrams`Private`preparationNumerators[_, _] := $Failed;
  PrepareAmplitudes[{acDiracPair}, prModel,
    "ProgressReporting" -> False, "Output" -> "Details"]];
check["failed reductions retain the previous expression and cannot become PREPARED",
  acInvalidReduction["Status"] === "PARTIAL" &&
    acInvalidReduction["Amplitude"] === Last[acDiracPair] &&
    First[acInvalidReduction["DiagramReports"]]["StopReason"] === "InvalidReduction"];

(* Compact factorization rows retain their metadata and declare only one cut.
   Other propagators inside a lower-point amplitude never add numerator shells. *)
acChannelDen = PropDen[Mom[Multiparticle[1, 2]], 2];
acChannelUncutDen = PropDen[Mom[Multiparticle[1, 3]], 3];
acChannelRow = Join[ConstantArray[0, 4], {Multiparticle[2, 1], 2,
  -(3 + MomProd[1, 2] + MomProd[1, 3])/(acChannelDen acChannelUncutDen)}];
acChannelSavedRow = acChannelRow;
acChannelPrepared = PrepareAmplitudes[{acChannelRow}, acMasslessScalarModel,
  "PolePreference" -> None, "MaxSteps" -> 0,
  "ProgressReporting" -> False, "ReturnDetails" -> True];
acChannelExpected = -(5 + MomProd[1, 3])/(acChannelDen acChannelUncutDen);
check["compact factorization rows use only their declared cut for numerator shells",
  acChannelPrepared["Status"] === "PREPARED" &&
    acZero[acChannelPrepared["Amplitude"] - acChannelExpected] &&
    !FreeQ[acChannelPrepared["Amplitude"], MomProd[1, 3]]];
check["optional channel diagnostics identify the input representation and selected channel",
  acChannelPrepared["InputType"] === "FactorizationChannels" &&
    acChannelPrepared["ElementTypes"] === {"FactorizationChannel"} &&
    acChannelPrepared["DiagramReports"] === {} &&
    acChannelPrepared["ChannelReports"] === acChannelPrepared["ItemReports"] &&
    With[{item = First[acChannelPrepared["ItemReports"]]},
      item["InputType"] === "FactorizationChannel" && item["ItemIndex"] === 1 &&
        item["Channel"] === acChannelRow[[-3]] &&
        item["Cut"] === List @@ acChannelRow[[-3]] && item["Mass"] === 2]];
check["channel preparation preserves every metadata entry, original sign and supplied row",
  Most[First[acChannelPrepared["PreparedAmplitudes"]]] === Most[acChannelSavedRow] &&
    acChannelPrepared["OriginalAmplitudes"] === {acChannelSavedRow} &&
    acChannelRow === acChannelSavedRow];
check["the selected and all unselected propagator denominators remain off shell",
  !FreeQ[acChannelPrepared["Amplitude"], acChannelDen] &&
    !FreeQ[acChannelPrepared["Amplitude"], acChannelUncutDen] &&
    First[acChannelPrepared["ItemReports"]]["InternalOnShellChannels"] === {{1, 2}} &&
    TrueQ[First[acChannelPrepared["ItemReports"]]["DenominatorsKeptOffShell"]]];
check["channel rows are returned directly by default rather than converted to diagram pairs",
  PrepareAmplitudes[{acChannelRow}, acMasslessScalarModel,
    "PolePreference" -> None, "MaxSteps" -> 0,
    "ProgressReporting" -> False] === acChannelPrepared["PreparedAmplitudes"] &&
    PrepareAmplitudes[{acChannelRow}, acMasslessScalarModel,
      "PolePreference" -> None, "MaxSteps" -> 0,
      "ProgressReporting" -> False, "Output" -> "Expression"] ===
        acChannelPrepared["Amplitude"]];
acExistingPoleXi = Spinor["Xi", "Angle", 5];
acExistingPolePhoton = Spinor["Helicity", "Angle", 5];
acExistingPole13 = PropDen[Mom[Multiparticle[1, 3]], prElectronMass];
acExistingPole25 = PropDen[Mom[Multiparticle[2, 5]], prElectronMass];
acExistingPoleSource = SpinorChain[acExistingPoleXi, Spinor["Spin", "Angle", 1]]/
  (SpinorChain[acExistingPoleXi, acExistingPolePhoton] acExistingPole13 acExistingPole25);
acExistingPoleRows = {
  {prElectronMass, prElectronMass, 0, 0, 0, Multiparticle[1, 3], prElectronMass, acExistingPoleSource},
  {prElectronMass, prElectronMass, 0, 0, 0, Multiparticle[2, 5], prElectronMass, 0}};
acExistingPolePrepared = PrepareAmplitudes[acExistingPoleRows, prModel,
  "PolePreference" -> "AllPhysical", "MaxSteps" -> 0,
  "ProgressReporting" -> False, "ReturnDetails" -> True];
check["physical reference selection does not duplicate an uncut propagator already present in a channel",
  acExistingPolePrepared["Status"] === "PARTIAL" &&
    First[acExistingPolePrepared["ItemReports"]]["PolePreference"]["Status"] === "UNRESOLVED" &&
    !FreeQ[First[acExistingPolePrepared["PreparedAmplitudes"]], Spinor["Xi", ___]] &&
    Exponent[Denominator[First[acExistingPolePrepared["PreparedAmplitudes"]][[-1]]],
      acExistingPole25] === 1];
check["excluding existing propagators from reference choices does not declare their numerators on shell",
  First[acExistingPolePrepared["ItemReports"]]["InternalOnShellChannels"] === {{1, 3}}];
acChannelContourRow = ReplacePart[acChannelRow,
  -1 -> Last[acChannelRow]/ConstructiveDiagrams`z];
acChannelContourPrepared = PrepareAmplitudes[{acChannelContourRow}, acMasslessScalarModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False];
check["preparation does not strip the channel contour factor or add a sewing sign",
  acZero[ConstructiveDiagrams`z Last[First[acChannelContourPrepared]] - acChannelExpected] &&
    !FreeQ[Last[First[acChannelContourPrepared]], ConstructiveDiagrams`z]];
acDiracChannelRow = {prElectronMass, prElectronMass, 0, 0, Multiparticle[1, 3], prElectronMass, Last[acDiracPair]};
acDiracChannelPrepared = PrepareAmplitudes[{acDiracChannelRow}, prModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False];
check["compact channels also receive ordinary external Dirac identities",
  Last[First[acDiracChannelPrepared]] === acPrepared["Amplitude"] &&
    Most[First[acDiracChannelPrepared]] === Most[acDiracChannelRow]];
check["the legacy preparation alias accepts the same compact channel rows",
  PrepareDiagramAmplitudes[{acChannelRow}, acMasslessScalarModel,
    "PolePreference" -> None, "MaxSteps" -> 0,
    "ProgressReporting" -> False] === acChannelPrepared["PreparedAmplitudes"]];
acChannelOff = PrepareAmplitudes[{acChannelRow}, acMasslessScalarModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "InternalOnShell" -> False,
  "ProgressReporting" -> False, "ReturnDetails" -> True];
check["channel numerator shells can be disabled without discarding their metadata",
  acZero[acChannelOff["Amplitude"] - Last[acChannelRow]] &&
    Most[First[acChannelOff["PreparedAmplitudes"]]] === Most[acChannelRow] &&
    First[acChannelOff["ItemReports"]]["InternalOnShellChannels"] === {}];
acChannelProtected = ReplacePart[acChannelRow, -1 ->
  (3 + MomProd[1, 2])/(acChannelDen (5 + MomProd[1, 2]))];
acChannelProtectedPrepared = PrepareAmplitudes[{acChannelProtected}, acMasslessScalarModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False];
check["a factorization channel shell never substitutes into a reciprocal invariant",
  Last[First[acChannelProtectedPrepared]] === 5/(acChannelDen (5 + MomProd[1, 2]))];
acChannelComplementRow = ReplacePart[acChannelRow, -1 -> MomProd[3, 4]/acChannelDen];
acChannelComplement = PrepareAmplitudes[{acChannelComplementRow}, acMasslessScalarModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False];
acChannelComplementOff = PrepareAmplitudes[{acChannelComplementRow}, acMasslessScalarModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "MomentumConservation" -> False,
  "ProgressReporting" -> False];
check["a channel's complementary cut is equivalent only when momentum conservation is enabled",
  Last[First[acChannelComplement]] === 2/acChannelDen &&
    Last[First[acChannelComplementOff]] === Last[acChannelComplementRow]];
acChannelLargeDen = PropDen[Mom[Multiparticle[1, 2, 3]], 3];
acChannelLargeRow = Join[ConstantArray[0, 5], {Multiparticle[1, 2, 3], 3,
  (1 + MomProd[4, 5])/acChannelLargeDen}];
acChannelLarge = PrepareAmplitudes[{acChannelLargeRow}, acMasslessScalarModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False];
check["a larger factorization cut uses its known two-particle complement at five points",
  Most[First[acChannelLarge]] === Most[acChannelLargeRow] &&
    Last[First[acChannelLarge]] === 11/(2 acChannelLargeDen)];
acChannelSixRow = Join[ConstantArray[0, 6], {Multiparticle[1, 2, 3], 3,
  (1 + MomProd[4, 5])/acChannelLargeDen}];
acChannelSix = PrepareAmplitudes[{acChannelSixRow}, acMasslessScalarModel,
  "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False];
check["a three-by-three cut does not invent an individual pair-mass condition",
  acZero[Last[First[acChannelSix]] - Last[acChannelSixRow]] &&
    !FreeQ[Last[First[acChannelSix]], MomProd[4, 5]] &&
    Most[First[acChannelSix]] === Most[acChannelSixRow]];
acMixedPreparationInput = {First[acLocalPairs], acChannelRow};
acMixedPreparation = PrepareAmplitudes[acMixedPreparationInput, acMasslessScalarModel,
  "PolePreference" -> None, "MaxSteps" -> 0,
  "ProgressReporting" -> False, "ReturnDetails" -> True];
check["each mixed-list element retains its own input format and shell assumptions",
  First[acMixedPreparation["PreparedAmplitudes"]] === First[acLocal["PreparedAmplitudes"]] &&
    Last[acMixedPreparation["PreparedAmplitudes"]] ===
      First[acChannelPrepared["PreparedAmplitudes"]] &&
    Lookup[acMixedPreparation["ItemReports"], "InternalOnShellChannels"] ===
      {{{1, 2}}, {{1, 2}}} &&
    acMixedPreparation["OriginalAmplitudes"] === acMixedPreparationInput];
check["mixed preparation reports separate diagram and channel items without exposing extra default output",
  acMixedPreparation["InputType"] === "Mixed" &&
    acMixedPreparation["ElementTypes"] === {"Diagram", "FactorizationChannel"} &&
    Length[acMixedPreparation["DiagramReports"]] === 1 &&
    Length[acMixedPreparation["ChannelReports"]] === 1 &&
    Lookup[acMixedPreparation["ItemReports"], "ItemIndex"] === {1, 2}];
check["diagram diagnostics remain available through the legacy report-key alias",
  acPrepared["ItemReports"] === acPrepared["DiagramReports"]];
Do[
  check["malformed compact channel metadata is rejected " <> ToString[bad, InputForm],
    acInvalid[Quiet[PrepareAmplitudes[{bad}, acMasslessScalarModel,
      "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False]]]],
  {bad, {
    {0, 0, 0, 0, Multiparticle[1, 1], 2, 1},
    {0, 0, 0, 0, Multiparticle[1, 5], 2, 1},
    {0, 0, 0, 0, Multiparticle[1], 2, 1},
    {0, 0, 0, 0, Multiparticle[1, 2, 3, 4], 2, 1},
    {0, 0, 0, 0, {1, 2}, 2, 1},
    {0, 0, 0, 0, Multiparticle[1, 2], Infinity, 1},
    {0, 0, 0, Infinity, Multiparticle[1, 2], 2, 1},
    {0, 0, 0, 0, Multiparticle[1, 2], 2, $Failed},
    {0, 0, 0, 0, Multiparticle[1, 2], 2, Missing["Amplitude"]}
  }}
];
check["mixed inputs with conflicting external masses fail before any simplification",
  acInvalid[Quiet[PrepareAmplitudes[{First[acLocalPairs],
    ReplacePart[acChannelRow, 1 -> 1]}, acMasslessScalarModel,
      "PolePreference" -> None, "MaxSteps" -> 0, "ProgressReporting" -> False]]]];
check["an unknown preparation option cannot be silently ignored",
  acInvalid[Quiet[PrepareAmplitudes[{acChannelRow}, acMasslessScalarModel,
    "PolePreference" -> None, "MaxSteps" -> 0,
    "ProgressReporting" -> False, "UnknownPreparationOption" -> True]]]];
acActualPreparedChannels = PrepareAmplitudes[prChannels, prFixtureModel,
  "PolePreference" -> None, "MaxSteps" -> 0,
  "ProgressReporting" -> False, "ReturnDetails" -> True];
check["actual five-point factorization channels keep all compact channel definitions",
  acActualPreparedChannels["Status"] === "PREPARED" &&
    Length[acActualPreparedChannels["PreparedAmplitudes"]] === 6 &&
    Most /@ acActualPreparedChannels["PreparedAmplitudes"] === Most /@ prChannels &&
    acActualPreparedChannels["OriginalAmplitudes"] === prChannels &&
    And @@ MapThread[Function[{row, item},
      item["InternalOnShellChannels"] === {Sort[List @@ row[[-3]]]}],
      {prChannels, acActualPreparedChannels["ItemReports"]}]];
acActualChannelResidues = Flatten[MapThread[Function[{original, prepared}, Module[{target},
    target = SelectFirst[prElectronTargets,
      #["Cut"] === ConstructiveDiagrams`Private`canonicalPhysicalCut[
        List @@ original[[-3]], Range[5]] &];
    Table[PhysicalPoleResidue[
      (Last[original] - Last[prepared]) /. ConstructiveDiagrams`z -> 1, target,
      "KinematicMap" -> prMap[i, j], "TimeConstraint" -> 10], {i, 2}, {j, 2}]
  ]], {prChannels, acActualPreparedChannels["PreparedAmplitudes"]}], 2];
check["external reduction and a channel's own numerator shell preserve all sampled QED residues",
  Length[acActualChannelResidues] === 24 &&
    AllTrue[acActualChannelResidues,
      AssociationQ[#] && #["Status"] === "PASS" && #["PhysicalResidue"] === 0 &]];

(* Independent cubic-scalar trees expose double counting of overlapping poles. *)
Print["Checking scalar-tree completion and exact linear refinement."];
acScalarModel = {{{"Scalar", "s", "s", 1, 0, acScalarMass, 0, 1, 1, "", ""}},
  {{"s", "s", "s", "", acCubicCoupling, 1}}, {}, {}};
acSum[pairs_] := Total[(ReduceSpinContractions[Last[#]] /. First[#]) & /@ pairs];
acScalarFourPairs = DiagramAmplitudes[CreateDiagrams[ConstantArray["s", 4], acScalarModel]];
acScalarFivePairs = DiagramAmplitudes[CreateDiagrams[ConstantArray["s", 5], acScalarModel]];
acScalarFour = acSum[acScalarFourPairs]; acScalarFive = acSum[acScalarFivePairs];
acScalarKnownModel = ReplacePart[acScalarModel, 2 -> Join[acScalarModel[[2]],
  {Join[ConstantArray["s", 4], {1, acScalarFour}]}]];
acScalarFourChannels = FactorizationAmplitudeChannels[ConstantArray["s", 4], acScalarModel];
acScalarFiveChannels = FactorizationAmplitudeChannels[ConstantArray["s", 5], acScalarKnownModel];
acScalarRules = {acScalarMass -> 1, acCubicCoupling -> 2};
acFiveTargets = ConstructiveDiagrams`Private`residueSimpleInputs[
  0, acScalarFiveChannels, acScalarKnownModel]["Targets"];
acNaiveLift = Total[(#["StateSum"]/#["Propagator"]) & /@ acFiveTargets];
check["the five-scalar pilot has fifteen diagrams and ten single-pole channels",
  Length[acScalarFivePairs] === 15 && Length[acScalarFiveChannels] === 10];
check["naively summing complete single-pole lifts double counts every scalar diagram",
  acZero[acCanonical[acNaiveLift - 2 acScalarFive, 5]]];
acFour = acFactor[0, acScalarFourChannels, acScalarModel, "ParameterRules" -> acScalarRules];
check["automatic factorization completion reconstructs a four-scalar tree from zero",
  acFour["Status"] === "COMPLETE" &&
    acZero[acCanonical[acFour["Amplitude"] - acScalarFour, 4]]];
acFive = acFactor[0, acScalarFiveChannels, acScalarKnownModel, "ParameterRules" -> acScalarRules];
check["automatic completion reconstructs double-pole scalar trees without a known-answer basis",
  acFive["Status"] === "COMPLETE" &&
    acZero[acCanonical[acFive["Amplitude"] - acScalarFive, 5]]];
check["simultaneous completion avoids the naive factor-of-two overcount",
  !acZero[acFive["Amplitude"]] &&
    acZero[acCanonical[acNaiveLift - 2 acFive["Amplitude"], 5]]];
acFiveHeldOut = acCheck[acFive["Amplitude"], acScalarFiveChannels, acScalarKnownModel,
  {acScalarMass -> 2, acCubicCoupling -> 3}, 5801];
check["the scalar reconstruction survives held-out masses, couplings and cut samples",
  acPhysicalPass[acFiveHeldOut] && Length[acFiveHeldOut["Channels"]] === 10];
acInconsistent = ConstructiveDiagrams`Private`completionSolveLinear[
  {acUnknown - 1, acUnknown - 2}, {acUnknown}];
check["contradictory exact linear equations cannot produce a spurious solution",
  acInconsistent["Status"] === "INCONSISTENT"];
acLinearUnknowns = {acLinearU, acLinearV, acLinearW};
acLinearInitial = {acLinearU + 2 acLinearV - acLinearW - 3};
acLinearAdded = {acLinearV + acLinearW - 2};
acLinearFirst = ConstructiveDiagrams`Private`completionSolveLinear[
  acLinearInitial, acLinearUnknowns];
acLinearIncrement = ConstructiveDiagrams`Private`completionRefineLinear[
  acLinearFirst, acLinearAdded];
acLinearBatch = ConstructiveDiagrams`Private`completionSolveLinear[
  Join[acLinearInitial, acLinearAdded], acLinearUnknowns];
check["incremental refinement preserves the exact affine solution of a batch linear solve",
  acLinearIncrement["Status"] === "UNDERDETERMINED" &&
    acLinearIncrement["Rank"] === acLinearBatch["Rank"] &&
    acLinearIncrement["FreeParameters"] === acLinearBatch["FreeParameters"] &&
    AllTrue[(acLinearUnknowns /. acLinearIncrement["SolutionRules"]) -
      (acLinearUnknowns /. acLinearBatch["SolutionRules"]), acZero]];
acLinearFinal = ConstructiveDiagrams`Private`completionRefineLinear[
  acLinearIncrement, {acLinearW - 7}];
acLinearFinalBatch = ConstructiveDiagrams`Private`completionSolveLinear[
  Join[acLinearInitial, acLinearAdded, {acLinearW - 7}], acLinearUnknowns];
check["successive refinements compose earlier pivot rules and retain the full rank",
  acLinearFinal["Status"] === "COMPLETE" &&
    acLinearFinal["Rank"] === 3 && acLinearFinal["FreeParameters"] === {} &&
    AllTrue[(acLinearUnknowns /. acLinearFinal["SolutionRules"]) -
      (acLinearUnknowns /. acLinearFinalBatch["SolutionRules"]), acZero]];
acLinearContradiction = ConstructiveDiagrams`Private`completionRefineLinear[
  acLinearFinal, {acLinearW - 8}];
check["an inconsistent extension of an exact incremental solution remains inconsistent",
  acLinearContradiction["Status"] === "INCONSISTENT"];
(* Exact row scaling must not change the affine family or hide a contradiction.
   Large common content mirrors the coherent-spin validation equations. *)
acScaledUnknowns = {acScaledU, acScaledV, acScaledW, acScaledX, acScaledY, acScaledZ};
acScaledInitial = {
  acScaledUnknowns[[1]] + 2 acScaledUnknowns[[2]] - acScaledUnknowns[[3]] - 3,
  acScaledUnknowns[[2]] - acScaledUnknowns[[4]] + Sqrt[2] acScaledUnknowns[[6]] - 1};
acScaledAdded = {
  2 acScaledUnknowns[[1]] - acScaledUnknowns[[2]] + acScaledUnknowns[[3]] +
    I acScaledUnknowns[[5]] - 2 - Sqrt[2],
  acScaledUnknowns[[4]] + 3 acScaledUnknowns[[5]] - 2 acScaledUnknowns[[6]] - Sqrt[3]};
acScaledRows[rows_List] := Flatten[Table[
  ((k + I)/(k + 1)) (10^90 + 39)^k rows, {k, 1, 3}]];
acScaledFirst = ConstructiveDiagrams`Private`completionSolveLinear[
  acScaledRows[acScaledInitial], acScaledUnknowns];
acScaledIncrement = ConstructiveDiagrams`Private`completionRefineLinear[
  acScaledFirst, acScaledRows[acScaledAdded]];
acScaledBatch = ConstructiveDiagrams`Private`completionSolveLinear[
  Join[acScaledRows[acScaledInitial], acScaledRows[acScaledAdded]], acScaledUnknowns];
check["large exact row contents retain the same batch and incremental affine family",
  acScaledIncrement["Status"] === "UNDERDETERMINED" &&
    acScaledIncrement["Rank"] === 4 && acScaledBatch["Rank"] === 4 &&
    acScaledIncrement["FreeParameters"] === acScaledBatch["FreeParameters"] &&
    AllTrue[(acScaledUnknowns /. acScaledIncrement["SolutionRules"]) -
      (acScaledUnknowns /. acScaledBatch["SolutionRules"]), RootReduce[Expand[#]] === 0 &]];
check["the scaled affine family satisfies every original algebraic and complex constraint",
  AllTrue[Join[acScaledInitial, acScaledAdded] /. acScaledIncrement["SolutionRules"],
    RootReduce[Expand[#]] === 0 &] && Length[acScaledIncrement["FreeParameters"]] === 2];
acScaledLateContradiction = ConstructiveDiagrams`Private`completionRefineLinear[
  acScaledIncrement, {First[acScaledInitial] + 1}];
check["large-row normalization cannot discard a late exact contradiction",
  acScaledLateContradiction["Status"] === "INCONSISTENT"];
acScaledZeroExtension = ConstructiveDiagrams`Private`completionRefineLinear[
  acScaledIncrement, {0, 0, 0}];
check["zero-row refinement preserves all remaining exact affine freedom",
  acScaledZeroExtension["Rank"] === 4 &&
    acScaledZeroExtension["FreeParameters"] === acScaledIncrement["FreeParameters"] &&
    AllTrue[(acScaledUnknowns /. acScaledZeroExtension["SolutionRules"]) -
      (acScaledUnknowns /. acScaledIncrement["SolutionRules"]), RootReduce[Expand[#]] === 0 &]];
check["row normalization still rejects nonlinear correction coefficients",
  ConstructiveDiagrams`Private`completionSolveLinear[
    {acScaledUnknowns[[1]]^2 - 1}, acScaledUnknowns]["Status"] === "UNRESOLVED"];
acRadicalRows = {acRadicalU + 2 acRadicalV - acRadicalW - 3 Sqrt[2],
  acRadicalV + acRadicalW - 2 Sqrt[2]};
acRadicalFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acRadicalRows, {acRadicalU, acRadicalV, acRadicalW}];
acRadicalContradiction = ConstructiveDiagrams`Private`completionRefineLinear[
  acRadicalFit, {First[acRadicalRows] - Sqrt[2]}];
check["a common radical right-hand side is restored without rescaling free coefficients",
  acRadicalFit["Status"] === "UNDERDETERMINED" && acRadicalFit["Rank"] === 2 &&
    acRadicalFit["FreeParameters"] === {acRadicalW} &&
    AllTrue[({acRadicalU, acRadicalV} /. acRadicalFit["SolutionRules"]) -
      {-Sqrt[2] + 3 acRadicalW, 2 Sqrt[2] - acRadicalW}, RootReduce[Expand[#]] === 0 &] &&
    AllTrue[acRadicalRows /. acRadicalFit["SolutionRules"], RootReduce[Expand[#]] === 0 &] &&
    acRadicalContradiction["Status"] === "INCONSISTENT"];
(* Distinct algebraic column units must be restored in the original variables,
   including a free variable whose column was scaled during row reduction. *)
acColumnUnknowns = {acColumnU, acColumnV, acColumnW};
acColumnRows = {
  Sqrt[2] acColumnU + 2 I acColumnV - Sqrt[3] acColumnW - 2 Sqrt[5],
  2 Sqrt[2] acColumnU - I acColumnV + Sqrt[3] acColumnW - 3 Sqrt[5],
  -Sqrt[2] acColumnU + 3 I acColumnV + 2 Sqrt[3] acColumnW - 11 Sqrt[5]};
acColumnFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acColumnRows, acColumnUnknowns];
check["distinct real and imaginary algebraic column scales preserve a full exact solution",
  acColumnFit["Status"] === "COMPLETE" && acColumnFit["Rank"] === 3 &&
    acColumnFit["FreeParameters"] === {} &&
    AllTrue[(acColumnUnknowns /. acColumnFit["SolutionRules"]) -
      {Sqrt[5]/Sqrt[2], -2 I Sqrt[5], Sqrt[15]}, RootReduce[Expand[#]] === 0 &] &&
    AllTrue[acColumnRows /. acColumnFit["SolutionRules"], RootReduce[Expand[#]] === 0 &]];
acColumnPartial = ConstructiveDiagrams`Private`completionSolveLinear[
  Take[acColumnRows, 2], acColumnUnknowns];
check["algebraic column scaling retains free coefficients in their original coordinates",
  acColumnPartial["Status"] === "UNDERDETERMINED" && acColumnPartial["Rank"] === 2 &&
    acColumnPartial["FreeParameters"] === {acColumnW} &&
    AllTrue[({acColumnU, acColumnV} /. acColumnPartial["SolutionRules"]) -
      {(8 Sqrt[5] - Sqrt[3] acColumnW)/(5 Sqrt[2]),
        (Sqrt[5] + 3 Sqrt[3] acColumnW)/(5 I)}, RootReduce[Expand[#]] === 0 &] &&
    AllTrue[Take[acColumnRows, 2] /. acColumnPartial["SolutionRules"],
      RootReduce[Expand[#]] === 0 &]];
acColumnContradiction = ConstructiveDiagrams`Private`completionSolveLinear[
  Append[acColumnRows, First[acColumnRows] - Sqrt[7]], acColumnUnknowns];
check["algebraic column scaling cannot hide an inconsistent radical equation",
  acColumnContradiction["Status"] === "INCONSISTENT"];
acColumnIncrement = ConstructiveDiagrams`Private`completionRefineLinear[
  acColumnPartial, {Last[acColumnRows]}];
check["refinement after algebraic column scaling agrees with a batch solve",
  acColumnIncrement["Status"] === "COMPLETE" && acColumnIncrement["Rank"] === 3 &&
    acColumnIncrement["FreeParameters"] === {} &&
    AllTrue[(acColumnUnknowns /. acColumnIncrement["SolutionRules"]) -
      (acColumnUnknowns /. acColumnFit["SolutionRules"]), RootReduce[Expand[#]] === 0 &] &&
    AllTrue[acColumnRows /. acColumnIncrement["SolutionRules"], RootReduce[Expand[#]] === 0 &]];
acUnfactoredColumnRows = {acUnfactoredU + Sqrt[3] acUnfactoredV - 1,
  Sqrt[2] acUnfactoredU + 2 Sqrt[3] acUnfactoredV - 3};
acUnfactoredColumnFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acUnfactoredColumnRows, {acUnfactoredU, acUnfactoredV}];
check["a column without one rationalizing algebraic unit retains the exact fallback solver",
  acUnfactoredColumnFit["Status"] === "COMPLETE" &&
    acUnfactoredColumnFit["Rank"] === 2 && acUnfactoredColumnFit["FreeParameters"] === {} &&
    AllTrue[({acUnfactoredU, acUnfactoredV} /. acUnfactoredColumnFit["SolutionRules"]) -
      {-(2 + Sqrt[2])/2, (4 + Sqrt[2])/(2 Sqrt[3])}, RootReduce[Expand[#]] === 0 &] &&
    AllTrue[acUnfactoredColumnRows /. acUnfactoredColumnFit["SolutionRules"],
      RootReduce[Expand[#]] === 0 &]];
acFourTargets = ConstructiveDiagrams`Private`residueSimpleInputs[
  0, acScalarFourChannels, acScalarModel]["Targets"];
acHalfChannel = ReplacePart[First[acScalarFourChannels],
  -1 -> Last[First[acScalarFourChannels]]/2];
acSplitChannel = acFactor[0, {acHalfChannel, acHalfChannel}, acScalarModel,
  "ParameterRules" -> acScalarRules, "Samples" -> 1, "ValidationSamples" -> 1];
check["degenerate exchange rows on one cut contribute their summed residue to fitting and validation",
  acSplitChannel["Status"] === "COMPLETE" &&
    acZero[acCanonical[acSplitChannel["Amplitude"] -
      First[acFourTargets]["StateSum"]/First[acFourTargets]["Propagator"], 4]]];
check["an empty or partial physical report cannot certify nonempty channel targets",
  !ConstructiveDiagrams`Private`completionPhysicalPassQ[<|"Channels" -> {}|>, acFourTargets] &&
    !ConstructiveDiagrams`Private`completionPhysicalPassQ[
      <|"Channels" -> {Join[First[acFourTargets], <|"Status" -> "PASS"|>]}|>, acFourTargets] &&
    ConstructiveDiagrams`Private`completionPhysicalPassQ[<|"Channels" -> {}|>, {}]];
acFeedbackContext = ConstructiveDiagrams`Private`completionNormalizeInput[
  acScalarFour, acScalarFourChannels, acScalarModel];
acEmptyFeedback = Catch[Catch[
  ConstructiveDiagrams`Private`completionValidationConstraints[
    0, {}, acFeedbackContext, {}, 1], _,
  Function[{value, tag}, Missing["EscapedValidationThrow", tag]]]];
check["missing held-out data returns an unresolved diagnostic without escaping the completion function",
  AssociationQ[acEmptyFeedback] && acEmptyFeedback["Status"] === "UNRESOLVED" &&
    acEmptyFeedback["Diagnostics"] =!= {}];
acAllowedChannels = Rest[acScalarFourChannels];
acAllowedChannelsSaved = acAllowedChannels;
acForbidden = acFactor[acScalarFour, acAllowedChannels, acScalarModel,
  "ParameterRules" -> acScalarRules];
acForbiddenValidationChannels = Prepend[acAllowedChannels,
  ReplacePart[First[acScalarFourChannels], -1 -> 0]];
acForbiddenHeldOut = acCheck[acForbidden["Amplitude"], acForbiddenValidationChannels,
  acScalarModel, {acScalarMass -> 2, acCubicCoupling -> 3}, 6029];
check["repair preserves zero residues in channels absent from the supplied data",
  acForbidden["Status"] === "COMPLETE" && acPhysicalPass[acForbiddenHeldOut] &&
    Length[acForbiddenHeldOut["Channels"]] === 3];
acZeroObligationRow = SelectFirst[acForbidden["ValidationReport"]["Channels"],
  #["Cut"] === First[acFourTargets]["Cut"] &, Missing["ZeroChannelNotValidated"]];
check["a removed forbidden pole remains an explicit zero obligation in held-out validation",
  acAllowedChannels === acAllowedChannelsSaved &&
    Length[acForbidden["ValidationReport"]["Channels"]] === 3 &&
    AssociationQ[acZeroObligationRow] && acZeroObligationRow["Status"] === "PASS" &&
    Total[Lookup[acZeroObligationRow["FactorizationChannels"], "StateSum"]] === 0];
acWithoutForbiddenPole = Cancel[acCanonical[acScalarFour -
  First[acFourTargets]["StateSum"]/First[acFourTargets]["Propagator"], 4]];
acBasisOnlyForbidden = acFactor[acWithoutForbiddenPole, acAllowedChannels, acScalarModel,
  "CorrectionBasis" -> {1/First[acFourTargets]["Propagator"]},
  "ParameterRules" -> acScalarRules];
check["a forbidden physical pole appearing only in an explicit correction basis is constrained to zero",
  FreeQ[acWithoutForbiddenPole, First[acFourTargets]["Propagator"]] &&
    acAllowedChannels === acAllowedChannelsSaved &&
    acBasisOnlyForbidden["Status"] === "COMPLETE" &&
    acBasisOnlyForbidden["FreeParameters"] === {} &&
    acBasisOnlyForbidden["RemainingBasis"] === {} &&
    Length[acBasisOnlyForbidden["ValidationReport"]["Channels"]] === 3 &&
    acZero[acBasisOnlyForbidden["Amplitude"] - acWithoutForbiddenPole]];

(* Known QED trees and one genuinely missing pole contribution. *)
Print["Checking existing QED amplitudes and a missing physical pole."];
acQEDFour = acFactor[prFourPointAmplitude, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}];
check["an already correct physical QED four-point amplitude is not changed",
  acQEDFour["Status"] === "COMPLETE" && acQEDFour["Correction"] === 0 &&
    acZero[acQEDFour["Amplitude"] - prFourPointAmplitude]];
acSavedCheckerOptions = Options[CheckPhysicalResidues]; acCustomMapUses = 0;
acHostileMap[___] := (acCustomMapUses++; Indeterminate);
SetOptions[CheckPhysicalResidues,
  "KinematicMap" -> acHostileMap, "KinematicKind" -> "Symbolic",
  "Tolerance" -> 1000000];
acIsolatedFactor = acFactor[prFourPointAmplitude, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "Samples" -> 1, "ValidationSamples" -> 1];
SetOptions[CheckPhysicalResidues, Sequence @@ acSavedCheckerOptions];
check["completion validation does not inherit custom checker maps or kinematic modes",
  acCustomMapUses === 0 && acIsolatedFactor["Status"] === "COMPLETE" &&
    acPhysicalPass[acIsolatedFactor["ValidationReport"]]];
acQEDFive = acFactor[prH, prChannels, prFixtureModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}];
check["an already correct physical QED five-point amplitude is not changed",
  acQEDFive["Status"] === "COMPLETE" && acQEDFive["Correction"] === 0 &&
    acZero[acQEDFive["Amplitude"] - prH]];
acQEDMissingPole = First[prFourPointTargets]["StateSum"]/
  First[prFourPointTargets]["Propagator"];
acQEDRepair = acFactor[prFourPointAmplitude - acQEDMissingPole,
  prFourPointChannels, prModel, "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}];
acQEDRepairHeldOut = acCheck[acQEDRepair["Amplitude"], prFourPointChannels, prModel,
  {prElectronMass -> 2, prElectricCharge -> 3}, 7919];
check["a missing QED pole is repaired using the supplied channels rather than a known-answer basis",
  acQEDRepair["Status"] === "COMPLETE" && acPhysicalPass[acQEDRepairHeldOut]];
check["QED fitting and held-out validation retain separate sample information",
  AssociationQ[acQEDRepair["ConstraintData"]] &&
    AssociationQ[acQEDRepair["ValidationReport"]]];
check["an exactly validated QED affine family is not rejected by unsimplified coefficient cancellations",
  acQEDRepair["Status"] === "COMPLETE" &&
    acQEDRepair["ConstraintData"]["LinearSolution"]["Rank"] === 2 &&
    Length[acQEDRepair["ConstraintData"]["LinearSolution"]["FreeParameters"]] === 3 &&
    acQEDRepair["FreeParameters"] =!= {} &&
    AllTrue[acQEDRepair["ValidationReports"], acPhysicalPass[#["Report"]] &]];
acRejectedHigherPoles = Select[acQEDRepair["ChannelContinuations"]["Variants"],
  !TrueQ[#["Accepted"]] &&
    Lookup[#["Verification"], "Reason", None] ===
      "UnsupportedHigherOrderPhysicalPoleContinuation" &];
check["reference choices introducing unsupported repeated physical poles are rejected explicitly",
  acRejectedHigherPoles =!= {} &&
    AllTrue[acRejectedHigherPoles,
      #["Verification"]["HigherOrderPropagators"] =!= {} &&
        #["Verification"]["Diagnostics"] =!= {} &]];
(* The caller explicitly chooses a shared generic reference through preparation. *)
acQEDCommonPairs = DiagramAmplitudes[CreateDiagrams[{"e", "E", "A.+", "A.+"}, prModel]];
acQEDPipelinePrepared = PrepareAmplitudes[acQEDCommonPairs, prModel,
  "PolePreference" -> "Xi", "ProgressReporting" -> False, "Output" -> "Details"];
acQEDPipelinePairs = PrepareAmplitudes[acQEDCommonPairs, prModel,
  "PolePreference" -> "Xi", "ProgressReporting" -> False];
acQEDPlainFactor = acFactor[acQEDPipelinePairs, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}];
check["ordinary prepared pairs feed factorization completion without extracting report fields",
  ListQ[acQEDPipelinePairs] && AllTrue[acQEDPipelinePairs, MatchQ[#, {_List, _}] &] &&
    acZero[Total[Last /@ acQEDPipelinePairs] - acQEDPipelinePrepared["Amplitude"]] &&
    acQEDPlainFactor["Status"] === "COMPLETE" &&
    acPhysicalPass[acQEDPlainFactor["ValidationReport"]]];
acQEDPipelineFactor = acFactor[acQEDPipelinePrepared, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}];
acQEDPipelineComplete = acEnergy[acQEDPipelineFactor, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}];
check["the full pipeline prepares actual QED DiagramAmplitudes output",
  acQEDPipelinePrepared["Status"] === "PREPARED" &&
    Length[acQEDPipelinePrepared["PreparedAmplitudes"]] === 2];
check["the prepared QED diagrams pass simultaneous factorization completion",
  acQEDPipelineFactor["Status"] === "COMPLETE"];
check["actual QED diagrams pass all final conditions through the staged pipeline",
  acQEDPipelineComplete["Status"] === "COMPLETE" &&
    acAllPass[acQEDPipelineComplete["AfterReport"]] &&
    acQEDPipelineComplete["AfterReport"]["Summary"] === <|"PASS" -> 6|>];

(* Reproduce the notebook's five-point AllSpurious construction without a supplied answer. *)
Print["Preparing the actual five-point AllSpurious diagrams."];
acQEDFivePairs = DiagramAmplitudes[CreateDiagrams[prParticles, prModel]];
acQEDFivePrepared = PrepareAmplitudes[acQEDFivePairs, prModel,
  "PolePreference" -> "AllSpurious", "ProgressReporting" -> False];
acQEDFiveSaved = acQEDFivePrepared;
acQEDOffCutValue[expression_, chart_] := Together[prMapOnChart[
  expression /. trace_SpinorTrace :>
    ConstructiveDiagrams`Private`residueChartTrace[trace, chart], chart]];
check["whole-expression cleanup retains or improves the compact primary complexity per actual QED diagram",
  AllTrue[acQEDFivePrepared, Function[pair,
    SpinorExpressionComplexity[Last[pair]] <= 13 &&
      (SpinorExpressionComplexity[Last[pair]] < 13 ||
        ConstructiveDiagrams`Private`expressionTermCounts[Last[pair]]["Terms"] <= 2)]]];
acQEDFiveOrdinaryReduced = (ReduceSpinorProducts[Last[#]] /.
    Cases[First[#], HoldPattern[Mass[_Integer] -> _]]) & /@ acQEDFivePrepared;
acQEDFiveOrdinaryDifferences = MapThread[Last[#1] - #2 &,
  {acQEDFivePrepared, acQEDFiveOrdinaryReduced}];
acQEDFiveOrdinaryOffCut = Table[TimeConstrained[
  acQEDOffCutValue[acOrdinaryDifference,
    prDoubleChart[acOffCutQ, acOffCutR, acOrdinarySpin1, acOrdinarySpin2]], 10, $TimedOut],
  {acOrdinaryDifference, acQEDFiveOrdinaryDifferences}, {acOrdinarySpin1, 2}, {acOrdinarySpin2, 2}];
check["prepared QED diagrams retain a compact representative equivalent to ordinary full-expression reduction",
  And @@ MapThread[SpinorExpressionComplexity[Last[#1]] <= SpinorExpressionComplexity[#2] &,
    {acQEDFivePrepared, acQEDFiveOrdinaryReduced}] &&
    Flatten[acQEDFiveOrdinaryOffCut] === ConstantArray[0, 4 Length[acQEDFivePrepared]]];
check["the five-point regression starts from six actual AllSpurious prepared diagrams",
  Length[acQEDFivePrepared] === 6 &&
    FreeQ[acQEDFivePrepared, Spinor["Xi", ___]]];
acQEDFiveCompleted = acFactor[acQEDFivePrepared, prChannels, prFixtureModel,
  "Samples" -> 1, "ValidationSamples" -> 1,
  "MaxCorrectionTerms" -> 128, "TimeConstraint" -> 180];
Print["Checking the automatically reconstructed five-point amplitude."];
check["automatic channel continuations complete the notebook's five-point AllSpurious input",
  acQEDFiveCompleted["Status"] === "COMPLETE" &&
    acPhysicalPass[acQEDFiveCompleted["ValidationReport"]] &&
    acQEDFivePrepared === acQEDFiveSaved];
check["the five-point completion removes auxiliary references without rewriting the prepared input",
  FreeQ[acQEDFiveCompleted["Amplitude"], Spinor["Xi", ___]] &&
    AssociationQ[acQEDFiveCompleted["ChannelContinuations"]]];
acAcceptedContinuations = Select[
  acQEDFiveCompleted["ChannelContinuations"]["Variants"], TrueQ[#["Accepted"]] &];
check["additional reference continuations are independently certified on their own selected cuts",
  acAcceptedContinuations =!= {} &&
    AnyTrue[acAcceptedContinuations, #["Mode"] === "AllPhysical" &] &&
    AllTrue[acAcceptedContinuations,
      #["Verification"]["Status"] === "PASS" &&
        Length[#["Verification"]["Samples"]] >= 2 &&
        AllTrue[#["Verification"]["Samples"], #["ResidueDifference"] === 0 &] &]];
acQEDFiveFinalCheck = CheckPhysicalResidues[acQEDFiveCompleted["Amplitude"],
  prChannels, prFixtureModel, "Samples" -> 3, "HighEnergySamples" -> 3,
  "RandomSeed" -> 11617, "ParameterRules" -> {prElectronMass -> 2, prElectricCharge -> 3},
  "Output" -> "Details", "TimeConstraint" -> 60];
check["the generated five-point result passes every independent final check at new parameters",
  acAllPass[acQEDFiveFinalCheck] &&
    acQEDFiveFinalCheck["PhysicalSummary"] === <|"PASS" -> 6|>];
(* q and r remain symbolic, so neither internal line is put on shell. *)
acQEDFiveOffCutDifferences = Table[TimeConstrained[
  acQEDOffCutValue[acQEDFiveCompleted["Amplitude"] - prH,
    prDoubleChart[acOffCutQ, acOffCutR, i, j]], 30, $TimedOut],
  {i, 2}, {j, 2}];
check["the reconstructed expression equals H on an external-shell chart away from both cuts",
  Flatten[acQEDFiveOffCutDifferences] === ConstantArray[0, 4]];

(* Exercise the notebook's completed result, not only a supplied known answer. *)
acQEDFeynmanModel = ReadModel[FileNameJoin[{root, "tests", "reference-models", "calchep"}], 2];
acQEDFeynmanPairs = DiagramAmplitudes[CreateDiagrams[prParticles, acQEDFeynmanModel]];
Do[
  acQEDFeynmanPrepared = PrepareAmplitudes[acQEDFeynmanPairs, acQEDFeynmanModel,
    "PolePreference" -> acReferenceMode, "ProgressReporting" -> False,
    "TimeConstraint" -> 60];
  acQEDFeynmanCheck = CheckAmplitudes[acQEDFiveCompleted["Amplitude"],
    prChannels, prFixtureModel, "FeynmanAmplitudes" -> acQEDFeynmanPrepared,
    "FeynmanModel" -> acQEDFeynmanModel, "Samples" -> 2,
    "TimeConstraint" -> 90, "Output" -> "Details"];
  check["automatic all-plus completion agrees with the full Feynman benchmark using " <> acReferenceMode,
    acAllPass[acQEDFeynmanCheck] &&
      acQEDFeynmanCheck["FeynmanCheck"]["Status"] === "PASS" &&
      acQEDFeynmanCheck["FeynmanCheck"]["CompletedSamples"] === 2],
  {acReferenceMode, {"IndependentXi", "AllPhysical"}}];

(* All correction components share one validated chart, but not regularity. *)
acBatchTarget = First[prFourPointTargets];
acBatchRules = ModelParameterRules[prModel, {"Me" -> 1, "EE" -> 1}];
acBatchChart = ConstructiveDiagrams`Private`completionCutChart[acBatchTarget, 1, 1729, acBatchRules];
acBatchPole = acBatchTarget["Propagator"];
acBatchResidue = ConstructiveDiagrams`Private`completionLinearResidue[
  {0, 1/acBatchPole, 3/acBatchPole}, {acBatchA, acBatchB},
  acBatchTarget, prFourPointTargets, acBatchChart, 10];
check["shared-chart correction evaluation retains every linear residue coefficient",
  acBatchResidue["Status"] === "PASS" &&
    acBatchResidue["PhysicalResidue"] === acBatchA + 3 acBatchB &&
    TrueQ[acBatchResidue["KinematicChecks"]["Valid"]]];
check["a later higher-order component cannot bypass the regularity check",
  ConstructiveDiagrams`Private`completionLinearResidue[{0, 1/acBatchPole^2},
    {acBatchA}, acBatchTarget, prFourPointTargets, acBatchChart, 10]["Status"] === "UNRESOLVED"];
check["an invalid shared chart cannot bypass kinematic validation",
  ConstructiveDiagrams`Private`completionLinearResidue[{0, 1/acBatchPole},
    {acBatchA}, acBatchTarget, prFourPointTargets,
    <|"Map" -> Function[{expression, channels, poles}, 0]|>, 10]["Status"] === "UNRESOLVED"];

(* Exact modular-block solver certificates. *)
acBlockZero[value_] := AllTrue[Flatten[{value}],
  RootReduce[Expand[Together[#]]] === 0 &];
acBlockCertificate[result_, matrix_, constant_] := Module[
  {rows, width = Length[First[matrix]], pivots, free, point, null},
  If[!AssociationQ[result] || !KeyExistsQ[result, "ReducedRows"], Return[False]];
  rows = Select[result["ReducedRows"], AnyTrue[Most[#], # =!= 0 &] &];
  If[!AllTrue[rows, Length[#] === width + 1 &], Return[False]];
  pivots = Map[Function[row, SelectFirst[Range[width], row[[#]] =!= 0 &, Missing[]]], rows];
  If[!FreeQ[pivots, _Missing] || !DuplicateFreeQ[pivots] ||
      Length[pivots] =!= result["Rank"], Return[False]];
  free = Complement[Range[width], pivots];
  point = ReplacePart[ConstantArray[0, width], Thread[pivots -> (Last /@ rows)]];
  null = If[free === {}, {}, Transpose[Map[Function[column,
    ReplacePart[UnitVector[width, column], Thread[pivots -> -rows[[All, column]]]]], free]]];
  acBlockZero[matrix.point + constant] &&
    If[free === {}, True, acBlockZero[matrix.null] &&
      null[[free, All]] === IdentityMatrix[Length[free]] &&
      point[[free]] === ConstantArray[0, Length[free]]]
];
acBlockBase = {{1, 0, 0, 2, 0, -3}, {0, 1, 0, -1, 0, 4},
  {0, 0, 1, 5, 0, 2}};
acBlockMatrix = Join[acBlockBase, {2 acBlockBase[[1]] - acBlockBase[[2]],
  acBlockBase[[2]] + acBlockBase[[3]], ConstantArray[0, 6],
  Total[acBlockBase], 3 acBlockBase[[1]] + 2 acBlockBase[[3]]}];
acBlockConstant = -acBlockMatrix.{2, -3, 5, 0, 0, 0};
acBlockResult = ConstructiveDiagrams`Private`completionExactBlockReduce[
  acBlockMatrix, acBlockConstant];
check["modular block reduction certifies every row of a rank-deficient rectangular system",
  AssociationQ[acBlockResult] && acBlockResult["Rank"] === 3 &&
    acBlockResult["CheckedRows"] === Length[acBlockMatrix] &&
    acBlockCertificate[acBlockResult, acBlockMatrix, acBlockConstant]];
check["block nullspaces preserve an unconstrained zero column in original free coordinates",
  AssociationQ[acBlockResult] &&
    acBlockZero[acBlockMatrix.UnitVector[6, 5]] &&
    acBlockCertificate[acBlockResult, acBlockMatrix, acBlockConstant]];
acBlockRationalMatrix = MapIndexed[#1/(2 + First[#2]) &, acBlockMatrix, {2}];
acBlockRationalConstant = -acBlockRationalMatrix.{2, -3, 5, 0, 0, 0};
acBlockRationalResult = ConstructiveDiagrams`Private`completionExactBlockReduce[
  acBlockRationalMatrix, acBlockRationalConstant];
check["rational denominator clearing preserves the particular solution and full nullspace",
  acBlockCertificate[acBlockRationalResult, acBlockRationalMatrix, acBlockRationalConstant]];
acBlockFullRankMatrix = {{1, 2}, {3, 5}, {4, 7}};
acBlockFullRankConstant = -acBlockFullRankMatrix.{2/3, -5/7};
acBlockFullRankResult = Check[ConstructiveDiagrams`Private`completionExactBlockReduce[
  acBlockFullRankMatrix, acBlockFullRankConstant], $Failed];
check["full-column-rank block certificates handle an empty free family without messages",
  AssociationQ[acBlockFullRankResult] && acBlockFullRankResult["Rank"] === 2 &&
    acBlockCertificate[acBlockFullRankResult, acBlockFullRankMatrix, acBlockFullRankConstant]];
acBlockFullRankContradiction = Check[ConstructiveDiagrams`Private`completionExactBlockReduce[
  Append[acBlockFullRankMatrix, First[acBlockFullRankMatrix]],
  Append[acBlockFullRankConstant, First[acBlockFullRankConstant] + 1]], $Failed];
check["full-column-rank block contradictions do not require a zero-dimensional identity matrix",
  AssociationQ[acBlockFullRankContradiction] && acBlockFullRankContradiction["Rank"] === 2 &&
    acBlockFullRankContradiction["ContradictionRow"] === 4 &&
    Last[acBlockFullRankContradiction["ReducedRows"]] === {0, 0, 1}];
acBlockInconsistentMatrix = Append[acBlockMatrix, First[acBlockMatrix]];
acBlockInconsistentConstant = Append[acBlockConstant, First[acBlockConstant] + 1];
acBlockInconsistentResult = ConstructiveDiagrams`Private`completionExactBlockReduce[
  acBlockInconsistentMatrix, acBlockInconsistentConstant];
check["an exact constant residual with zero free coefficients certifies an inconsistent extra row",
  AssociationQ[acBlockInconsistentResult] && acBlockInconsistentResult["Rank"] === 3 &&
    acBlockInconsistentResult["ContradictionRow"] === Length[acBlockInconsistentMatrix] &&
    Last[acBlockInconsistentResult["ReducedRows"]] === Join[ConstantArray[0, 6], {1}]];
acBlockInconsistentVariables = Table[Unique["acBlockInconsistentCoefficient"], {64}];
acBlockInconsistentFit = ConstructiveDiagrams`Private`completionSolveLinear[
  PadRight[acBlockInconsistentMatrix, {Length[acBlockInconsistentMatrix], 64}].
    acBlockInconsistentVariables + acBlockInconsistentConstant,
  acBlockInconsistentVariables];
check["the simultaneous solver reports a certified block contradiction as inconsistent",
  acBlockInconsistentFit["Status"] === "INCONSISTENT" &&
    MissingQ[acBlockInconsistentFit["Rank"]] && acBlockInconsistentFit["RankLowerBound"] === 3 &&
    acBlockInconsistentFit["SolutionRules"] === {}];
check["an unlucky prime with a rank drop falls back instead of certifying a false nullspace",
  MissingQ[ConstructiveDiagrams`Private`completionExactBlockReduce[
    {{5, 0}, {0, 1}, {5, 1}}, {-10, -3, -13}, 5]]];
check["a rank-dropping prime cannot underreport the coefficient rank of a certified contradiction",
  MissingQ[ConstructiveDiagrams`Private`completionExactBlockReduce[
    {{1, 0}, {0, 5}, {1, 0}}, {0, 0, 1}, 5]]];
acBlockRankDropVariables = Table[Unique["acBlockRankDropCoefficient"], {64}];
acBlockRankDropFit = ConstructiveDiagrams`Private`completionSolveLinear[
  PadRight[{{1, 0}, {0, 2147483647}, {1, 0}}, {3, 64}].acBlockRankDropVariables + {0, 0, 1},
  acBlockRankDropVariables];
check["a contradiction certificate does not misreport an unlucky modular rank as exact",
  acBlockRankDropFit["Status"] === "INCONSISTENT" && MissingQ[acBlockRankDropFit["Rank"]] &&
    acBlockRankDropFit["RankLowerBound"] === 1 &&
    acBlockRankDropFit["InconsistencyCertificate"]["ExactAllColumnCertificate"] === True &&
    acBlockRankDropFit["SolutionRules"] === {}];
check["a rank-preserving bad prime cannot return duplicate rational leading pivots",
  MissingQ[ConstructiveDiagrams`Private`completionExactBlockReduce[
    {{5, 1, 0}, {5, 0, 1}}, {0, 0}, 5]]];
check["an exact contradiction still uses fallback when the prime gives nonleading rational pivots",
  MissingQ[ConstructiveDiagrams`Private`completionExactBlockReduce[
    {{5, 1, 0}, {5, 0, 1}, {10, 1, 1}}, {0, 0, 1}, 5]]];
acBlockBadPrimeVariables = Table[Unique["acBlockBadPrimeCoefficient"], {64}];
acBlockBadPrimeMatrix = PadRight[{{2147483647, 1, 0}, {2147483647, 0, 1}}, {2, 64}];
acBlockBadPrimeConstant = -acBlockBadPrimeMatrix.Join[{2, -3, 5}, ConstantArray[0, 61]];
acBlockBadPrimeFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acBlockBadPrimeMatrix.acBlockBadPrimeVariables + acBlockBadPrimeConstant,
  acBlockBadPrimeVariables];
acBlockBadPrimeFamily = acBlockBadPrimeVariables /. acBlockBadPrimeFit["SolutionRules"];
acBlockBadPrimeFree = acBlockBadPrimeFit["FreeParameters"];
acBlockBadPrimeParticular = acBlockBadPrimeFamily /. Thread[acBlockBadPrimeFree -> 0];
acBlockBadPrimeNullspace = Transpose[Coefficient[acBlockBadPrimeFamily, #] & /@ acBlockBadPrimeFree];
check["a rank-preserving unlucky prime retains the exact solution and original free family",
  acBlockBadPrimeFit["Status"] === "UNDERDETERMINED" && acBlockBadPrimeFit["Rank"] === 2 &&
    Length[acBlockBadPrimeFree] === 62 &&
    acBlockZero[acBlockBadPrimeMatrix.acBlockBadPrimeParticular + acBlockBadPrimeConstant] &&
    acBlockZero[acBlockBadPrimeMatrix.acBlockBadPrimeNullspace] &&
    acBlockBadPrimeFamily[[Flatten[FirstPosition[acBlockBadPrimeVariables, #] & /@
      acBlockBadPrimeFree]]] === acBlockBadPrimeFree];
acBlockWideBase = MapThread[Join, {IdentityMatrix[4],
  Table[(3 i + 2 j)/(i + j + 1), {i, 4}, {j, 66}]}];
acBlockWideMatrix = Join[acBlockWideBase, {acBlockWideBase[[1]] + acBlockWideBase[[2]],
  3 acBlockWideBase[[3]] - acBlockWideBase[[4]], Total[acBlockWideBase]}];
acBlockWideConstant = -acBlockWideMatrix.Join[{2, -1, 3, -5}, ConstantArray[0, 66]];
acBlockWideResult = ConstructiveDiagrams`Private`completionExactBlockReduce[
  acBlockWideMatrix, acBlockWideConstant];
check["more than fifty right-hand columns retain exact particular and nullspace certificates",
  AssociationQ[acBlockWideResult] && acBlockWideResult["Rank"] === 4 &&
    Length[First[acBlockWideMatrix]] - acBlockWideResult["Rank"] + 1 > 50 &&
    acBlockCertificate[acBlockWideResult, acBlockWideMatrix, acBlockWideConstant]];
acBlockWideVariables = Table[Unique["acBlockCoefficient"], {70}];
acBlockColumnUnits = Sqrt[Prime /@ Range[70]];
acBlockScaledMatrix = (# acBlockColumnUnits &) /@ acBlockWideMatrix;
acBlockScaledConstant = Sqrt[2] acBlockWideConstant;
acBlockScaledFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acBlockScaledMatrix.acBlockWideVariables + acBlockScaledConstant, acBlockWideVariables];
acBlockScaledFamily = acBlockWideVariables /. acBlockScaledFit["SolutionRules"];
acBlockScaledFree = acBlockScaledFit["FreeParameters"];
acBlockScaledParticular = acBlockScaledFamily /. Thread[acBlockScaledFree -> 0];
acBlockScaledNullspace = Transpose[Coefficient[acBlockScaledFamily, #] & /@ acBlockScaledFree];
check["the public exact solver restores all original column and right-hand-side units",
  acBlockScaledFit["Status"] === "UNDERDETERMINED" && acBlockScaledFit["Rank"] === 4 &&
    Length[acBlockScaledFree] === 66 &&
    acBlockZero[acBlockScaledMatrix.acBlockScaledParticular + acBlockScaledConstant] &&
    acBlockZero[acBlockScaledMatrix.acBlockScaledNullspace]];
check["restored block solutions retain identity coordinates for the original free parameters",
  (acBlockScaledFamily[[Flatten[FirstPosition[acBlockWideVariables, #] & /@ acBlockScaledFree]]]) ===
    acBlockScaledFree];
acBlockAlgebraicMatrix = {{1, Sqrt[2], 3}, {Sqrt[3], 1, -1},
  {1 + Sqrt[3], 1 + Sqrt[2], 2}};
acBlockAlgebraicConstant = -acBlockAlgebraicMatrix.{2, -1, 0};
check["nonrational algebraic matrices decline the modular helper without an approximate fit",
  MissingQ[ConstructiveDiagrams`Private`completionExactBlockReduce[
    acBlockAlgebraicMatrix, acBlockAlgebraicConstant]]];
acBlockAlgebraicVariables = {acBlockX, acBlockY, acBlockZ};
acBlockAlgebraicFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acBlockAlgebraicMatrix.acBlockAlgebraicVariables + acBlockAlgebraicConstant,
  acBlockAlgebraicVariables];
acBlockAlgebraicFamily = acBlockAlgebraicVariables /. acBlockAlgebraicFit["SolutionRules"];
acBlockAlgebraicFree = acBlockAlgebraicFit["FreeParameters"];
acBlockAlgebraicParticular = acBlockAlgebraicFamily /. Thread[acBlockAlgebraicFree -> 0];
acBlockAlgebraicNullspace = Transpose[Coefficient[acBlockAlgebraicFamily, #] & /@ acBlockAlgebraicFree];
check["the native fallback still solves an exact nonrational algebraic system",
  acBlockAlgebraicFit["Status"] === "UNDERDETERMINED" && acBlockAlgebraicFit["Rank"] === 2 &&
    acBlockZero[acBlockAlgebraicMatrix.acBlockAlgebraicParticular + acBlockAlgebraicConstant] &&
    acBlockZero[acBlockAlgebraicMatrix.acBlockAlgebraicNullspace]];
check["inexact coefficients do not enter an exact modular certificate",
  MissingQ[ConstructiveDiagrams`Private`completionExactBlockReduce[{{1., 2.}}, {3.}]]];
(* End exact modular-block solver certificates. *)

(* Bounded CRT reconstruction must certify the original exact affine family. *)
acCRTResult = ConstructiveDiagrams`Private`completionCertifiedModularReduce[
  acBlockMatrix, acBlockConstant];
check["certified CRT preserves every original row and unconstrained zero column",
  AssociationQ[acCRTResult] && acCRTResult["Rank"] === 3 &&
    acCRTResult["CheckedRows"] === Length[acBlockMatrix] &&
    acBlockCertificate[acCRTResult, acBlockMatrix, acBlockConstant]];
check["nontrivial CRT certificates use two primes and a distinct unused check prime",
  AssociationQ[acCRTResult] && Length[acCRTResult["CRTPrimes"]] >= 2 &&
    !MemberQ[acCRTResult["CRTPrimes"], acCRTResult["HeldOutPrime"]]];
acCRTRational = ConstructiveDiagrams`Private`completionCertifiedModularReduce[
  acBlockRationalMatrix, acBlockRationalConstant];
check["CRT row denominator clearing preserves rational particular and null directions",
  acBlockCertificate[acCRTRational, acBlockRationalMatrix, acBlockRationalConstant]];
acCRTLargeDenominator = 10^12 + 39;
acCRTLargeMatrix = {{1, 1/acCRTLargeDenominator, 0},
  {7/5, 7/(5 acCRTLargeDenominator), 0}};
acCRTLargeConstant = {-1/(acCRTLargeDenominator + 2),
  -7/(5 (acCRTLargeDenominator + 2))};
acCRTLargeResult = ConstructiveDiagrams`Private`completionCertifiedModularReduce[
  acCRTLargeMatrix, acCRTLargeConstant];
check["CRT reconstructs exact fractions beyond a single-prime rational bound",
  AssociationQ[acCRTLargeResult] && Length[acCRTLargeResult["CRTPrimes"]] >= 3 &&
    acBlockCertificate[acCRTLargeResult, acCRTLargeMatrix, acCRTLargeConstant]];
acCRTDeepDenominator = 2^160 + 7;
acCRTDeepMatrix = {{1, 1/acCRTDeepDenominator}};
acCRTDeepResult = ConstructiveDiagrams`Private`completionCertifiedModularReduce[
  acCRTDeepMatrix, {0}, 10];
check["CRT uses its bounded prime inventory when an exact null relation needs more than eight primes",
  AssociationQ[acCRTDeepResult] && acCRTDeepResult["Rank"] === 1 &&
    Length[acCRTDeepResult["CRTPrimes"]] > 8 &&
    acBlockCertificate[acCRTDeepResult, acCRTDeepMatrix, {0}]];
check["an explicitly short CRT inventory does not accept an unreconstructed null family",
  MissingQ[ConstructiveDiagrams`Private`completionCertifiedModularReduce[
    acCRTDeepMatrix, {0}, 10, NestList[NextPrime[#, -1] &, 2147483647, 7]]]];
acCRTFullMatrix = {{2, 0, 0}, {0, -3, 0}, {0, 0, 5}, {2, -3, 5}};
acCRTFullConstant = -acCRTFullMatrix.{3/7, -2/11, 4/13};
acCRTFullResult = ConstructiveDiagrams`Private`completionCertifiedModularReduce[
  acCRTFullMatrix, acCRTFullConstant];
check["full-rank CRT rows use the production right-hand-side sign convention",
  AssociationQ[acCRTFullResult] && acCRTFullResult["Rank"] === 3 &&
    acCRTFullResult["ReducedRows"] === {{1, 0, 0, 3/7},
      {0, 1, 0, -2/11}, {0, 0, 1, 4/13}} &&
    acBlockCertificate[acCRTFullResult, acCRTFullMatrix, acCRTFullConstant]];
acCRTZeroMatrix = ConstantArray[0, {3, 5}];
acCRTZeroResult = ConstructiveDiagrams`Private`completionCertifiedModularReduce[
  acCRTZeroMatrix, {0, 0, 0}];
check["an exactly zero system retains the entire independent free family without sampling primes",
  AssociationQ[acCRTZeroResult] && acCRTZeroResult["Rank"] === 0 &&
    acCRTZeroResult["ReducedRows"] === {} &&
    acBlockCertificate[acCRTZeroResult, acCRTZeroMatrix, {0, 0, 0}]];
acCRTBadPivots = ConstructiveDiagrams`Private`completionCertifiedModularReduce[
  {{105, 1}}, {-2}, 10, {3, 5, 7, 11, 13, 17, 19, 23, 29}];
check["bad nonleading modular profiles cannot certify an incorrect rational pivot layout",
  AssociationQ[acCRTBadPivots] &&
    acCRTBadPivots["ReducedRows"] === {{1, 1/105, 2/105}} &&
    acBlockCertificate[acCRTBadPivots, {{105, 1}}, {-2}]];
acCRTRankDrop = ConstructiveDiagrams`Private`completionCertifiedModularReduce[
  {{5, 0}, {0, 1}, {5, 1}}, {-10, -3, -13}, 10, {5, 7, 11, 13, 17}];
check["a later full-rank prime supersedes an unlucky rank-dropping profile",
  AssociationQ[acCRTRankDrop] && acCRTRankDrop["Rank"] === 2 &&
    acBlockCertificate[acCRTRankDrop, {{5, 0}, {0, 1}, {5, 1}}, {-10, -3, -13}]];
acCRTFalseContradiction = ConstructiveDiagrams`Private`completionCertifiedModularReduce[
  {{3}}, {1}, 10, {3, 5, 7, 11}];
check["a contradiction at one bad prime is not interpreted as an exact inconsistency",
  AssociationQ[acCRTFalseContradiction] &&
    acCRTFalseContradiction["ReducedRows"] === {{1, -1/3}}];
acCRTContradictionMatrix = {{1/2, 2/3}, {3/5, -7/11}, {11/10, 1/33}};
acCRTContradictionConstant = -acCRTContradictionMatrix.{2/3, -5/7} + {0, 0, 1};
acCRTContradiction = ConstructiveDiagrams`Private`completionCertifiedModularReduce[
  acCRTContradictionMatrix, acCRTContradictionConstant];
check["full coefficient rank and a larger modular augmented rank certify an exact contradiction",
  AssociationQ[acCRTContradiction] && acCRTContradiction["Status"] === "INCONSISTENT" &&
    acCRTContradiction["Rank"] === 2 &&
    acCRTContradiction["CoefficientRankLowerBound"] === 2 &&
    acCRTContradiction["AugmentedRankLowerBound"] === 3 &&
    !KeyExistsQ[acCRTContradiction, "ReducedRows"] &&
    Last[acCRTContradictionMatrix] === Total[Most[acCRTContradictionMatrix]] &&
    Last[acCRTContradictionConstant] - Total[Most[acCRTContradictionConstant]] === 1];
acCRTContradictionVariables = Array[acCRTContradictionVariable, 64];
acCRTContradictionFit = ConstructiveDiagrams`Private`completionSolveLinear[
  Append[IdentityMatrix[64], UnitVector[64, 1]].acCRTContradictionVariables +
    Append[ConstantArray[0, 64], 1], acCRTContradictionVariables];
check["the production solver consumes a certified contradiction without requesting rational RREF rows",
  acCRTContradictionFit["Status"] === "INCONSISTENT" &&
    acCRTContradictionFit["Rank"] === 64 &&
    acCRTContradictionFit["InconsistencyCertificate"]["Backend"] ===
      "CertifiedFullColumnRankContradiction"];
acCRTRankDeficientContradiction = ConstructiveDiagrams`Private`completionCertifiedModularReduce[
  acBlockInconsistentMatrix, acBlockInconsistentConstant];
check["rank-deficient inconsistent rows use an exact all-column left-null certificate",
  acCRTRankDeficientContradiction["Status"] === "INCONSISTENT" &&
    MissingQ[acCRTRankDeficientContradiction["Rank"]] &&
    acCRTRankDeficientContradiction["RankLowerBound"] === 3 &&
    acCRTRankDeficientContradiction["LeftNullVector"].acBlockInconsistentMatrix ===
      ConstantArray[0, Length[First[acBlockInconsistentMatrix]]] &&
    acCRTRankDeficientContradiction["LeftNullVector"].acBlockInconsistentConstant =!= 0];
acCRTConstantContradiction = ConstructiveDiagrams`Private`completionCertifiedModularReduce[{{0, 0}}, {1}];
check["a constant-only contradiction is inconsistent with certified exact coefficient rank zero",
  acCRTConstantContradiction["Status"] === "INCONSISTENT" &&
    acCRTConstantContradiction["Rank"] === 0 &&
    !KeyExistsQ[acCRTConstantContradiction, "ReducedRows"]];
check["an exhausted bad-prime inventory does not certify a sampled or truncated family",
  MissingQ[ConstructiveDiagrams`Private`completionCertifiedModularReduce[
    {{105, 1}}, {-2}, 10, {3, 5, 7}]]];
check["invalid or exhausted CRT time budgets request the unchanged exact fallback",
  AllTrue[{0, -1, Infinity, 1 + I, "invalid"},
    MissingQ[ConstructiveDiagrams`Private`completionCertifiedModularReduce[
      {{1, 2}}, {3}, #]] &]];
check["an exhausted positive CRT clock does not enter a native solve or accept a partial family",
  MissingQ[ConstructiveDiagrams`Private`completionCertifiedModularReduce[
    PadRight[IdentityMatrix[96], {96, 128}], ConstantArray[1, 96], 10^-9]]];
check["CRT does not approximate algebraic, complex, or inexact matrix entries",
  AllTrue[{{{1, Sqrt[2]}}, {{1, I}}, {{1., 2.}}},
    MissingQ[ConstructiveDiagrams`Private`completionCertifiedModularReduce[#, {3}]] &]];
acCRTWideResult = ConstructiveDiagrams`Private`completionCertifiedModularReduce[
  acBlockWideMatrix, acBlockWideConstant];
check["a wide CRT family retains every exact particular and independent null direction",
  AssociationQ[acCRTWideResult] && acCRTWideResult["Rank"] === 4 &&
    acBlockCertificate[acCRTWideResult, acBlockWideMatrix, acBlockWideConstant]];
check["CRT defaults do not replace the existing direct block API and bad-prime contract",
  MissingQ[ConstructiveDiagrams`Private`completionExactBlockReduce[
    {{5, 1, 0}, {5, 0, 1}}, {0, 0}, 5]] &&
    acBlockCertificate[acBlockResult, acBlockMatrix, acBlockConstant]];

Print["Completing the four-fermion single-photon process from actual diagrams."];
acFourFermionParticles = {"e", "E", "E", "e", "A.+"};
acFourFermionPairs = DiagramAmplitudes[CreateDiagrams[acFourFermionParticles, prModel]];
acFourFermionPreparation = PrepareAmplitudes[acFourFermionPairs, prModel,
  "PolePreference" -> Automatic, "MaxSteps" -> 0,
  "ProgressReporting" -> False, "ReturnDetails" -> True];
acFourFermionChannels = FactorizationAmplitudeChannels[acFourFermionParticles, prFixtureModel];
check["single-photon preparation selects physical references for all eight diagrams",
  acFourFermionPreparation["Status"] === "PREPARED" &&
    Length[acFourFermionPreparation["PreparedAmplitudes"]] === 8 &&
    FreeQ[acFourFermionPreparation["Amplitude"], Spinor["Xi", ___]]];
acFourFermionFactorization = acFactor[acFourFermionPreparation, acFourFermionChannels,
  prFixtureModel, "Samples" -> 3, "ValidationSamples" -> 1,
  "MaxCorrectionTerms" -> 128, "TimeConstraint" -> 300];
check["recorded references do not hide the physical correction space for four fermions",
  acFourFermionFactorization["Status"] === "COMPLETE" &&
    MemberQ[{"ReducedChannels", "PeeledChannels", "PhysicalChannels"}, acFourFermionFactorization["CorrectionSpace"]] &&
    Length[acFourFermionFactorization["CorrectionBasis"]] <= 128 &&
    acPhysicalPass[acFourFermionFactorization["ValidationReport"]] &&
    ConstructiveDiagrams`Private`completionPhysicalDenominatorOnlyQ[
      acFourFermionFactorization["Amplitude"],
      ConstructiveDiagrams`Private`completionNormalizeInput[acFourFermionPreparation,
        acFourFermionChannels, prFixtureModel]]];
acFourFermionEnergy = acEnergy[acFourFermionFactorization["Amplitude"], acFourFermionChannels,
  prFixtureModel, "Samples" -> 1, "ValidationSamples" -> 1, "TimeConstraint" -> 180];
check["four-fermion completion satisfies high-energy and reference requirements",
  acFourFermionEnergy["Status"] === "COMPLETE" && acAllPass[acFourFermionEnergy["AfterReport"]]];
acFourFermionFeynman = PrepareAmplitudes[DiagramAmplitudes[
    CreateDiagrams[acFourFermionParticles, acQEDFeynmanModel]], acQEDFeynmanModel,
  "PolePreference" -> "AllPhysical", "MaxSteps" -> 0, "ProgressReporting" -> False];
acFourFermionFinal = CheckAmplitudes[acFourFermionEnergy["Amplitude"],
  acFourFermionChannels, prFixtureModel, "FeynmanAmplitudes" -> acFourFermionFeynman,
  "FeynmanModel" -> acQEDFeynmanModel, "Samples" -> 2,
  (* Keep the exact seed that exposed an unfinished third high-energy sample.
     This intentionally unprojected fixture needs more Laurent-expansion time
     than the public constructor's symmetry-reduced amplitude. *)
  "RandomSeed" -> 6157842894738730042, "HighEnergyTimeConstraint" -> 180,
  "TimeConstraint" -> 90, "Output" -> "Details"];
check["the constructed four-fermion amplitude passes all eleven final checks",
  acFourFermionFinal["Summary"] === <|"PASS" -> 11|> && acAllPass[acFourFermionFinal] &&
    acFourFermionFinal["HighEnergyCheck"]["CompletedSamples"] === 3 &&
    acFourFermionFinal["FeynmanCheck"]["CompletedSamples"] === 2];

(* Mixed reference optimization must remain compatible with off-cut completion. *)
Print["Checking optimized Mixed references through five-point completion."];
acQEDMixedPrepared = PrepareAmplitudes[acQEDFivePairs, prModel,
  "PolePreference" -> "Mixed", "MaxSteps" -> 0,
  "ProgressReporting" -> False, "ReturnDetails" -> True];
acQEDMixedSaved = acQEDMixedPrepared["PreparedAmplitudes"];
check["Mixed prepares all six real QED diagrams without changing their mass assumptions",
  acQEDMixedPrepared["Status"] === "PREPARED" &&
    Length[acQEDMixedSaved] === 6 &&
    First /@ acQEDMixedSaved === First /@ acQEDFivePairs &&
    FreeQ[acQEDMixedSaved, Spinor["Xi", ___]]];
acQEDMixedCompleted = acFactor[acQEDMixedPrepared, prChannels, prFixtureModel,
  "Samples" -> 1, "ValidationSamples" -> 1,
  "MaxCorrectionTerms" -> 128, "TimeConstraint" -> 180,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}];
acQEDMixedFinalCheck = CheckPhysicalResidues[acQEDMixedCompleted["Amplitude"],
  prChannels, prFixtureModel, "Samples" -> 3, "HighEnergySamples" -> 2,
  "RandomSeed" -> 11617, "ParameterRules" -> {prElectronMass -> 2, prElectricCharge -> 3},
  "Output" -> "Details", "TimeConstraint" -> 60];
check["the Mixed pipeline completes and passes all final checks at independent parameters",
  acQEDMixedCompleted["Status"] === "COMPLETE" &&
    acAllPass[acQEDMixedFinalCheck] &&
    acQEDMixedFinalCheck["PhysicalSummary"] === <|"PASS" -> 6|> &&
    Length[acQEDMixedFinalCheck["Checks"]] === 8 &&
    acQEDMixedPrepared["PreparedAmplitudes"] === acQEDMixedSaved];
acQEDMixedOffCutDifferences = Table[TimeConstrained[
  acQEDOffCutValue[acQEDMixedCompleted["Amplitude"] - prH,
    prDoubleChart[acOffCutQ, acOffCutR, i, j]], 30, $TimedOut],
  {i, 2}, {j, 2}];
check["the Mixed result equals H without setting either internal denominator on shell",
  Flatten[acQEDMixedOffCutDifferences] === ConstantArray[0, 4]];

(* Mixed photon helicities are different from Mixed reference selection. *)
Print["Checking mixed photon helicities from cyclic diagram preparation."];
acMixedHelicityParticles = {"e", "E", "A.+", "A.+", "A.-"};
acMixedHelicityPairs = DiagramAmplitudes[CreateDiagrams[acMixedHelicityParticles, prModel]];
acMixedHelicityChannels = FactorizationAmplitudeChannels[acMixedHelicityParticles, prFixtureModel];
acMixedHelicityOrdinaryPrepared = PrepareAmplitudes[acMixedHelicityPairs, prModel,
  "PolePreference" -> "Cyclic", "MaxSteps" -> 0,
  "ProgressReporting" -> False];
(* Preparation may remove any particular dot product. Exercise scalar squares
   with one that actually remains, using only the declared external masses. *)
acMixedHelicityDotPrepared = acMixedHelicityOrdinaryPrepared;
If[FreeQ[acMixedHelicityDotPrepared, _MomProd],
  (* Clifford reversal exposes a numerator dot if the compact result has
     removed them all. This introduces no inverse scalar momentum squares. *)
  acMixedHelicityNumeratorChains = Flatten[
    ConstructiveDiagrams`Private`chainsIn /@ Flatten[
      ConstructiveDiagrams`Private`monomialsOf /@ (Last /@ acMixedHelicityDotPrepared)]];
  acMixedHelicityOpenChain = FirstCase[acMixedHelicityNumeratorChains,
    chain : SpinorChain[left_Spinor, Mom[a_Integer], Mom[b_Integer], right_Spinor] /;
      left =!= right && a =!= b && ContainsAll[Range[5], {a, b}] :> chain,
    Missing["NoOpenMomentumChain"]];
  If[!MissingQ[acMixedHelicityOpenChain],
    acMixedHelicityDotPrepared = Map[Function[pair, {First[pair],
      ConstructiveDiagrams`Private`preparationNumerators[Last[pair],
        Function[num, num /. acMixedHelicityOpenChain ->
          (2 MomProd[acMixedHelicityOpenChain[[2, 1]], acMixedHelicityOpenChain[[3, 1]]] *
            SpinorChain[First[acMixedHelicityOpenChain], Last[acMixedHelicityOpenChain]] -
           SpinorChain[First[acMixedHelicityOpenChain], acMixedHelicityOpenChain[[3]],
             acMixedHelicityOpenChain[[2]], Last[acMixedHelicityOpenChain]])]]}],
      acMixedHelicityDotPrepared]]];
(* If only single-momentum chains survive, the external Clifford square
   supplies the same scalar-square coverage without an inverse momentum
   square. The charged external masses are nonzero in this QED fixture. *)
If[FreeQ[acMixedHelicityDotPrepared, _MomProd],
  acMixedHelicitySingleChain = FirstCase[acMixedHelicityNumeratorChains,
    chain : SpinorChain[_Spinor, Mom[p_Integer], _Spinor] /;
      MemberQ[Range[5], p] :> chain, Missing["NoSingleMomentumChain"]];
  If[!MissingQ[acMixedHelicitySingleChain],
    acMixedHelicityInsertedLeg = SelectFirst[{1, 2},
      # =!= acMixedHelicitySingleChain[[2, 1]] &];
    acMixedHelicityDotPrepared = Map[Function[pair, {First[pair],
      ConstructiveDiagrams`Private`preparationNumerators[Last[pair],
        Function[num, num /. acMixedHelicitySingleChain ->
          ((2 MomProd[acMixedHelicityInsertedLeg, acMixedHelicitySingleChain[[2, 1]]] *
              SpinorChain[First[acMixedHelicitySingleChain], Mom[acMixedHelicityInsertedLeg],
                Last[acMixedHelicitySingleChain]] -
            SpinorChain[First[acMixedHelicitySingleChain], Mom[acMixedHelicityInsertedLeg],
              acMixedHelicitySingleChain[[2]], Mom[acMixedHelicityInsertedLeg],
              Last[acMixedHelicitySingleChain]])/
           (Mass[acMixedHelicityInsertedLeg]^2 /.
             ConstructiveDiagrams`Private`preparationExternalRules[First[pair]]))]]}],
      acMixedHelicityDotPrepared]]];
acMixedHelicitySquareDot = SelectFirst[DeleteDuplicates[
  Cases[Last /@ acMixedHelicityDotPrepared, _MomProd, Infinity]],
  MatchQ[List @@ #, {_Integer, _Integer}] &&
    First[#] =!= Last[#] && ContainsAll[Range[5], List @@ #] &,
  Missing["NoDistinctExternalMomentumProduct"]];
acMixedHelicityPrepared = If[MissingQ[acMixedHelicitySquareDot],
  acMixedHelicityDotPrepared,
  Map[Function[pair, {First[pair], Last[pair] /. acMixedHelicitySquareDot ->
    ((Mom[Multiparticle @@ List @@ acMixedHelicitySquareDot]^2 -
        Mass[First[acMixedHelicitySquareDot]]^2 - Mass[Last[acMixedHelicitySquareDot]]^2)/2 /.
      ConstructiveDiagrams`Private`preparationExternalRules[First[pair]])}],
    acMixedHelicityDotPrepared]];
acMixedHelicityFixtureDifferences = Table[TimeConstrained[
  MapThread[acQEDOffCutValue[(Last[#1] - Last[#2]) /.
      Power[p_Mom, exponent_Integer?EvenQ] :>
        Det[prMomentum[p[[1]], prDoubleChart[acOffCutQ, acOffCutR, i, j]]]^(exponent/2),
      prDoubleChart[acOffCutQ, acOffCutR, i, j]] &,
    {acMixedHelicityPrepared, acMixedHelicityOrdinaryPrepared}],
  30, $TimedOut], {i, 2}, {j, 2}];
check["the cyclic mixed-helicity scalar-square fixture retains exact off-cut equality",
  !MissingQ[acMixedHelicitySquareDot] &&
    !FreeQ[acMixedHelicityPrepared,
      Mom[Multiparticle @@ List @@ acMixedHelicitySquareDot]^2] &&
    FreeQ[acMixedHelicityPrepared, Power[_Mom, _Integer?Negative]] &&
    Flatten[acMixedHelicityFixtureDifferences] ===
      ConstantArray[0, 4 Length[acMixedHelicityOrdinaryPrepared]]];
acMixedHelicitySaved = acMixedHelicityPrepared;
(* Isolate the established compact route; automatic preferred-source ordering
   has its own tests and must not mask this older path's invariant checks. *)
acMixedHelicityCompleted = acFactor[acMixedHelicityPrepared, acMixedHelicityChannels,
  prFixtureModel, "Samples" -> 1, "ValidationSamples" -> 1,
  "ShiftedChannelContinuations" -> False, "PolePreference" -> None,
  "MaxCorrectionTerms" -> 128, "TimeConstraint" -> 180,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}];
check["the established compact route still handles cyclic choices and scalar momentum squares when shifted proposals are disabled",
  acMixedHelicityCompleted["Status"] === "COMPLETE" &&
    MemberQ[{"ReducedChannels", "PeeledChannels"}, acMixedHelicityCompleted["CorrectionSpace"]] &&
    Length[acMixedHelicityCompleted["CorrectionBasis"]] <= 128 &&
    !FreeQ[acMixedHelicitySaved, Mom[Multiparticle @@ List @@ acMixedHelicitySquareDot]^2] &&
    acMixedHelicityPrepared === acMixedHelicitySaved];
check["whole-channel reductions are checked before their correction terms are admitted",
  With[{rows = If[acMixedHelicityCompleted["CorrectionSpace"] === "PeeledChannels",
      acMixedHelicityCompleted["ChannelCompanions"]["SourceChecks"],
      acMixedHelicityCompleted["ReducedChannelSpace"]["Verification"]]},
    rows =!= {} && AllTrue[rows, #["Verification"]["Status"] === "PASS" &]]];
acMixedHelicityFinalCheck = CheckPhysicalResidues[acMixedHelicityCompleted["Amplitude"],
  acMixedHelicityChannels, prFixtureModel, "ParameterRules" -> {prElectronMass -> 2, prElectricCharge -> 3},
  "Samples" -> 3, "HighEnergySamples" -> 2, "RandomSeed" -> 11617,
  "TimeConstraint" -> 90, "Output" -> "Details"];
check["mixed helicities pass every final check at independent masses, coupling and momenta",
  acAllPass[acMixedHelicityFinalCheck] &&
    acMixedHelicityFinalCheck["PhysicalSummary"] === <|"PASS" -> 6|>];
acMixedHelicityKnown = qedFivePointMixedRoute[acMixedHelicityPairs]["Final"];
acMixedHelicityOffCutDifferences = Table[TimeConstrained[
  acQEDOffCutValue[acMixedHelicityCompleted["Amplitude"] - acMixedHelicityKnown /.
    Power[p_Mom, exponent_Integer?EvenQ] :>
      Det[prMomentum[p[[1]], prDoubleChart[acOffCutQ, acOffCutR, i, j]]]^(exponent/2),
    prDoubleChart[acOffCutQ, acOffCutR, i, j]], 30, $TimedOut], {i, 2}, {j, 2}];
check["automatic mixed-helicity completion equals the independently worked result away from cuts",
  Flatten[acMixedHelicityOffCutDifferences] === ConstantArray[0, 4]];

(* Prepared compact rows are direct completion inputs, just as in the notebook. *)
Print["Checking completion with prepared factorization-channel inputs."];
acPreparedCompletionChannels = PrepareAmplitudes[prChannels, prFixtureModel,
  "PolePreference" -> "AllSpurious", "MaxSteps" -> 0,
  "ProgressReporting" -> False];
check["alternative channel representations are opt-in rather than inferred from the model",
  ("AlternativeChannels" /. Options[CompleteFactorization]) === {}];
acPreparedChannelsAlone = acFactor[acQEDFivePrepared,
  acPreparedCompletionChannels, prFixtureModel,
  "Samples" -> 1, "ValidationSamples" -> 1,
  "MaxCorrectionTerms" -> 128, "TimeConstraint" -> 180];
check["a reduced-only correction space reports its missing directions instead of claiming success",
  acPreparedChannelsAlone["Status"] === "UNRESOLVED" &&
    acPreparedChannelsAlone["ConstraintData"]["LinearSolution"]["Status"] === "INCONSISTENT"];
acPreparedChannelCompletion = acFactor[acQEDFivePrepared,
  acPreparedCompletionChannels, prFixtureModel,
  "AlternativeChannels" -> prChannels,
  "Samples" -> 1, "ValidationSamples" -> 1,
  "MaxCorrectionTerms" -> 128, "TimeConstraint" -> 180];
check["actual AllSpurious diagrams complete against prepared factorization channels",
  acPreparedChannelCompletion["Status"] === "COMPLETE" &&
    acPhysicalPass[acPreparedChannelCompletion["ValidationReport"]] &&
    acQEDFivePrepared === acQEDFiveSaved];
check["original channel alternatives are certified before expanding the reduced correction space",
  acPreparedChannelCompletion["CorrectionSpace"] === "AlternativeChannels" &&
    acPreparedChannelCompletion["AlternativeChannelFallback"]["Status"] === "COMPLETE" &&
    acPreparedChannelCompletion["AlternativeChannelFallback"]["Scope"] ===
      "ExactSampledSelectedCutEquivalenceWithUnchangedResidueTargets" &&
    Length[acPreparedChannelCompletion["AlternativeChannelFallback"]["Verification"]] === 6 &&
    AllTrue[acPreparedChannelCompletion["AlternativeChannelFallback"]["Verification"],
      #["Verification"]["Status"] === "PASS" &] &&
    Length[acPreparedChannelCompletion["CorrectionBasis"]] <= 128];
acPreparedChannelHeldOut = acCheck[acPreparedChannelCompletion["Amplitude"],
  prChannels, prFixtureModel, {prElectronMass -> 2, prElectricCharge -> 3}, 11617];
check["completion using prepared channels also passes the original channels at independent parameters",
  acPhysicalPass[acPreparedChannelHeldOut]];
acMixedPreparedChannels = PrepareAmplitudes[acMixedHelicityChannels, prFixtureModel,
  "PolePreference" -> "AllSpurious", "MaxSteps" -> 0,
  "ProgressReporting" -> False];
acMixedPreparedChannelCompletion = acFactor[acMixedHelicityCompleted["Amplitude"],
  acMixedPreparedChannels, prFixtureModel,
  "AlternativeChannels" -> acMixedHelicityChannels,
  "Samples" -> 1, "ValidationSamples" -> 1,
  "MaxCorrectionTerms" -> 128, "TimeConstraint" -> 60];
acMixedPreparedChannelDifferences = Table[TimeConstrained[
  acQEDOffCutValue[(acMixedPreparedChannelCompletion["Amplitude"] -
      acMixedHelicityCompleted["Amplitude"]) /.
    Power[p_Mom, exponent_Integer?EvenQ] :>
      Det[prMomentum[p[[1]], prDoubleChart[acOffCutQ, acOffCutR, i, j]]]^(exponent/2),
    prDoubleChart[acOffCutQ, acOffCutR, i, j]], 30, $TimedOut], {i, 2}, {j, 2}];
check["prepared mixed-helicity channels accept an independently completed amplitude unchanged",
  acMixedPreparedChannelCompletion["Status"] === "COMPLETE" &&
    acMixedPreparedChannelCompletion["Correction"] === 0 &&
    Flatten[acMixedPreparedChannelDifferences] === ConstantArray[0, 4]];
check["channel alternatives are not inspected when the prepared-only comparison already succeeds",
  !KeyExistsQ[acMixedPreparedChannelCompletion, "AlternativeChannelFallback"]];
acBadAlternativeChannels = ReplacePart[prChannels,
  {1, -1} -> 2 prChannels[[1, -1]]];
acBadAlternativeCompletion = acFactor[acQEDFivePrepared,
  acPreparedCompletionChannels, prFixtureModel,
  "AlternativeChannels" -> acBadAlternativeChannels,
  "Samples" -> 1, "ValidationSamples" -> 1,
  "MaxCorrectionTerms" -> 128, "TimeConstraint" -> 180];
check["an alternative with a different selected residue is rejected instead of changing the target",
  acBadAlternativeCompletion["Status"] === "UNRESOLVED" &&
    acBadAlternativeCompletion["CorrectionSpace"] =!= "AlternativeChannels" &&
    acBadAlternativeCompletion["AlternativeChannelFallback"]["Status"] === "UNRESOLVED" &&
    AnyTrue[acBadAlternativeCompletion["AlternativeChannelFallback"]["Verification"],
      #["Verification"]["Status"] === "FAIL" &]];
acExplicitAlternativeSpace = acFactor[acQEDFivePrepared,
  acPreparedCompletionChannels, prFixtureModel,
  "CorrectionBasis" -> {}, "AlternativeChannels" -> prChannels,
  "Samples" -> 1, "ValidationSamples" -> 1,
  "MaxCorrectionTerms" -> 128, "TimeConstraint" -> 30];
check["channel alternatives never broaden an explicitly supplied correction basis",
  acExplicitAlternativeSpace["Status"] === "UNRESOLVED" &&
    acExplicitAlternativeSpace["CorrectionSpace"] === "SuppliedTerms" &&
    !KeyExistsQ[acExplicitAlternativeSpace, "AlternativeChannelFallback"]];
Do[
  check["malformed alternative channels are rejected " <> ToString[bad, InputForm],
    acInvalid[Quiet[CompleteFactorization[prH, prChannels, prFixtureModel,
      "AlternativeChannels" -> bad, "ProgressReporting" -> False]]]],
  {bad, {True, "Original", {{}}, {{0, 0, 0, 0, Multiparticle[1, 2], Infinity, 1}}}}
];

acContactNormalized = ConstructiveDiagrams`Private`completionNormalizeInput[
  {{Select[First[First[acMixedHelicityPrepared]], MatchQ[First[#], Mass[_Integer]] &],
    acPreservedContact + Total[Last /@ acMixedHelicityPrepared]}},
  acMixedHelicityChannels, prFixtureModel];
acContactCompact = ConstructiveDiagrams`Private`completionReducedChannelBasis[
  acContactNormalized, acMixedHelicityCompleted["ChannelContinuations"], 128,
  {prElectronMass -> 1, prElectricCharge -> 1}, 1729];
check["compact channel construction does not include a known pole-free input as a cancellation direction",
  AssociationQ[acContactCompact] && FreeQ[acContactCompact["Basis"], acPreservedContact]];

(* Force the compact-to-literal fallback itself, keeping automatic pole-source
   selection from satisfying the fit before the deliberately empty space. *)
acCompactFallback = Block[
  {ConstructiveDiagrams`Private`completionReducedChannelBasis = Function[
    {normalized, references, limit, rules, seed}, <|"Basis" -> {}|>]},
  acFactor[prH/2, prChannels, prFixtureModel,
    "InputReweighting" -> None, "PolePreference" -> None,
    "ChannelCompanions" -> None,
    "Samples" -> 2, "ValidationSamples" -> 1,
    "MaxCorrectionTerms" -> 128, "TimeConstraint" -> 90,
    "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}]];
check["an insufficient compact strategy falls back to the retained literal channel terms",
  acCompactFallback["Status"] === "COMPLETE" &&
    acCompactFallback["InputFitAttempts"] === {} &&
    acCompactFallback["CorrectionSpace"] === "LiteralTerms" &&
    Length[acCompactFallback["CorrectionSpaceAttempts"]] === 2 &&
    acPhysicalPass[acCompactFallback["ValidationReport"]]];

acQEDFiveLegacy = acFactor[acQEDFivePrepared, prChannels, prFixtureModel,
  "ChannelReferences" -> None, "Samples" -> 4, "ValidationSamples" -> 1,
  "MaxCorrectionTerms" -> 128, "TimeConstraint" -> 90];
Print["Checking retained affine families, validation feedback, and bounded failures."];
check["the legacy literal channel-term space is honestly insufficient for the five-point example",
  acQEDFiveLegacy["Status"] === "UNRESOLVED" &&
    acQEDFiveLegacy["ConstraintData"]["LinearSolution"]["Status"] === "INCONSISTENT"];
check["compact completion uses verified channel structures rather than silently reusing the old space",
  acQEDFiveCompleted["CorrectionBasis"] =!= acQEDFiveLegacy["CorrectionBasis"] &&
    Or[
      MemberQ[{"ReducedChannels", "PhysicalChannels"}, acQEDFiveCompleted["CorrectionSpace"]] &&
        AnyTrue[acQEDFiveCompleted["ReducedChannelSpace"]["Sources"],
          MemberQ[Lookup[acAcceptedContinuations, "Expression"], #] &],
      acQEDFiveCompleted["CorrectionSpace"] === "PeeledChannels" &&
        acQEDFiveCompleted["ChannelCompanions"]["SourceChecks"] =!= {} &&
        AllTrue[acQEDFiveCompleted["ChannelCompanions"]["SourceChecks"],
          #["Verification"]["Status"] === "PASS" &] &&
        acQEDFiveCompleted["ChannelCompanions"]["Mappings"] =!= {} &&
        AllTrue[acQEDFiveCompleted["ChannelCompanions"]["Mappings"],
          !TrueQ[#["PeelingIsIdentity"]] &]]];

acQEDDistinct = prPreparedDiagramSum[DiagramAmplitudeRecords[
  CreateDiagrams[{"e", "E", "A.+", "A.+"}, prModel]]];
acQEDDistinctCompletion = acEnergy[acQEDDistinct, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "Samples" -> 1,
  "ValidationSamples" -> 1];
check["uniquely fixed zero corrections retain a raw diagram's failed reference report",
  acQEDDistinctCompletion["Status"] === "UNRESOLVED" &&
    acZero[acQEDDistinctCompletion["Amplitude"] - acQEDDistinct] &&
    acQEDDistinctCompletion["PhysicalLinearSystem"]["FreeParameters"] === {} &&
    acQEDDistinctCompletion["BeforeReport"]["ReferenceCheck"]["Status"] === "FAIL"];
acQEDNormalization = acEnergy[prFourPointAmplitude/2, prFourPointChannels, prModel,
  "CorrectionBasis" -> {prFourPointAmplitude}, "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}];
check["a uniquely fixed nonzero correction survives all remaining zero-unknown checks",
  acQEDNormalization["Status"] === "COMPLETE" &&
    acZero[acQEDNormalization["Amplitude"] - prFourPointAmplitude] &&
    acQEDNormalization["PhysicalLinearSystem"]["FreeParameters"] === {} &&
    acAllPass[acQEDNormalization["AfterReport"]]];
acCompletionEvents = {};
acLiveFactor = acFactor[prFourPointAmplitude, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "Samples" -> 1, "ValidationSamples" -> 1,
  "ProgressReporting" -> True, "ProgressFunction" -> (AppendTo[acCompletionEvents, #] &)];
acLiveEnergy = acEnergy[acLiveFactor, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "Samples" -> 1, "ValidationSamples" -> 1,
  "ProgressReporting" -> True, "ProgressFunction" -> (AppendTo[acCompletionEvents, #] &)];
check["both completion stages expose structured progress callbacks",
  acLiveFactor["Status"] === "COMPLETE" && acLiveEnergy["Status"] === "COMPLETE" &&
    AllTrue[acCompletionEvents, AssociationQ[#] && KeyExistsQ[#, "Stage"] &] &&
    AnyTrue[acCompletionEvents, StringContainsQ[#["Stage"], "factorization", IgnoreCase -> True] &] &&
    MemberQ[Lookup[acCompletionEvents, "Stage"], "HighEnergy"]];
acDefaultFactor = CompleteFactorization[prFourPointAmplitude, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "Samples" -> 1,
  "ValidationSamples" -> 1, "ProgressReporting" -> False];
acCompletedExternalRules = Thread[(Mass /@ Range[4]) ->
  {prElectronMass, prElectronMass, 0, 0}];
check["the default successful factorization output retains only external mass rules",
  MatchQ[acDefaultFactor, {_List, _}] &&
    First[acDefaultFactor] === acCompletedExternalRules &&
    FreeQ[First[acDefaultFactor], _Multiparticle] &&
    acZero[Last[acDefaultFactor] - prFourPointAmplitude]];
check["factorization diagnostics are disabled by default while the amplitude keeps its masses",
  ("ReturnDetails" /. Options[CompleteFactorization]) === False &&
    ("Output" /. Options[CompleteFactorization]) === "Amplitude"];
acFactorFalse = CompleteFactorization[prFourPointAmplitude, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "Samples" -> 1, "ValidationSamples" -> 1,
  "ProgressReporting" -> False, "ReturnDetails" -> False];
check["ReturnDetails False keeps a successfully validated amplitude pair plain",
  MatchQ[acFactorFalse, {_List, _}] &&
    First[acFactorFalse] === First[acDefaultFactor] &&
    acZero[Last[acFactorFalse] - Last[acDefaultFactor]]];
acExpressionFactor = CompleteFactorization[prFourPointAmplitude, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "Samples" -> 1,
  "ValidationSamples" -> 1, "ProgressReporting" -> False, "Output" -> "Expression"];
check["explicit factorization Expression output remains the bare symbolic expression",
  !ListQ[acExpressionFactor] && !AssociationQ[acExpressionFactor] &&
    acZero[acExpressionFactor - Last[acDefaultFactor]]];
acFactorDetails = CompleteFactorization[prFourPointAmplitude, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "Samples" -> 1, "ValidationSamples" -> 1,
  "ProgressReporting" -> False, "ReturnDetails" -> True];
check["ReturnDetails True exposes the factorization candidate, constraints and validation history",
  AssociationQ[acFactorDetails] && acFactorDetails["Status"] === "COMPLETE" &&
    acZero[acFactorDetails["Amplitude"] - Last[acDefaultFactor]] &&
    ContainsAll[Keys[acFactorDetails], {"InitialReport", "ValidationReport", "ConstraintData"}]];
acFactorDetailsOverride = CompleteFactorization[
  prFourPointAmplitude, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "Samples" -> 1, "ValidationSamples" -> 1,
  "ProgressReporting" -> False, "ReturnDetails" -> True, "Output" -> "Expression"];
check["ReturnDetails True overrides the legacy factorization Expression output choice",
  AssociationQ[acFactorDetailsOverride] && acFactorDetailsOverride["Status"] === "COMPLETE"];
check["legacy factorization Output Details remains supported",
  AssociationQ[acQEDFour] && acQEDFour["Status"] === "COMPLETE" &&
    acZero[acQEDFour["Amplitude"] - Last[acDefaultFactor]]];
acPlainFinal = CompleteHighEnergy[acDefaultFactor, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "Samples" -> 1,
  "ValidationSamples" -> 1, "ProgressReporting" -> False];
check["an amplitude pair feeds high-energy completion without extracting report fields",
  MatchQ[acPlainFinal, {_List, _}] &&
    First[acPlainFinal] === acCompletedExternalRules &&
    acZero[Last[acPlainFinal] - prFourPointAmplitude]];
acExpressionFinal = CompleteHighEnergy[acDefaultFactor, prFourPointChannels, prModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "Samples" -> 1,
  "ValidationSamples" -> 1, "ProgressReporting" -> False, "Output" -> "Expression"];
check["explicit high-energy Expression output remains available after amplitude-pair input",
  !ListQ[acExpressionFinal] && !AssociationQ[acExpressionFinal] &&
    acZero[acExpressionFinal - Last[acPlainFinal]]];
Do[
  check["invalid factorization ReturnDetails value is rejected " <> ToString[bad, InputForm],
    acInvalid[Quiet[CompleteFactorization[prFourPointAmplitude,
      prFourPointChannels, prModel, "ReturnDetails" -> bad, "ProgressReporting" -> False]]]],
  {bad, {"Yes", 1, Automatic}}
];
acFree = acFactor[acScalarFour, acScalarFourChannels, acScalarModel,
  "CorrectionBasis" -> {1}, "ParameterRules" -> acScalarRules];
check["residue-invisible local directions are retained rather than falsely fixed",
  acFree["Status"] === "COMPLETE" && acFree["FreeParameters"] =!= {} &&
    acFree["RemainingBasis"] === {1} &&
    !FreeQ[acFree["FamilyAmplitude"], Alternatives @@ acFree["FreeParameters"]]];
acComplementNull = 1/PropDen[Mom[Multiparticle[1, 2]], acScalarMass] -
  1/PropDen[Mom[Multiparticle[3, 4]], acScalarMass];
acCleanFamily = acFactor[acScalarFour, acScalarFourChannels, acScalarModel,
  "CorrectionBasis" -> {acComplementNull, 1}, "ParameterRules" -> acScalarRules];
check["an exactly zero complementary-propagator direction is removed but local contact freedom survives",
  acCleanFamily["Status"] === "COMPLETE" &&
    acCleanFamily["CorrectionBasis"] === {1} &&
    acCleanFamily["RemainingBasis"] === {1} &&
    Length[acCleanFamily["FreeParameters"]] === 1];

(* One cut sample cannot fix an arbitrary coefficient of a varying invariant. *)
acAdaptiveTarget = First[acFourTargets];
acAdaptiveDen = acAdaptiveTarget["Propagator"];
acAdaptivePair = {First[acAdaptiveTarget["Cut"]],
  First[Complement[Range[4], acAdaptiveTarget["Cut"]]]};
acAdaptiveBasis = {1/acAdaptiveDen,
  (MomProd @@ acAdaptivePair)/acAdaptiveDen};
acSparseNormalized = ConstructiveDiagrams`Private`completionNormalizeInput[
  0, Take[acScalarFourChannels, 1], acScalarModel];
acSparseRegular = (MomProd[1, 3] + MomProd[1, 4] + MomProd[2, 3])^8;
acSparseTrial = acSparseU acAdaptiveTarget["StateSum"]/acAdaptiveDen +
  acSparseV acSparseRegular;
acSparseSolution = <|"SolutionRules" -> {acSparseU -> 1, acSparseV -> 1},
  "FreeParameters" -> {}|>;
acSparseDenseCandidate = Expand[acSparseTrial /. acSparseSolution["SolutionRules"]];
DownValues[acSparseEvaluateDelegate] = DownValues[
  ConstructiveDiagrams`Private`residueEvaluateChart] /.
    HoldPattern[ConstructiveDiagrams`Private`residueEvaluateChart] -> acSparseEvaluateDelegate;
acSparseMappedSizes = {}; acSparseMappedUnknowns = False;
acSparseValidation = Block[
  {ConstructiveDiagrams`Private`residueEvaluateChart = Function[{expression, chart, rules},
    AppendTo[acSparseMappedSizes, LeafCount[expression]];
    If[!FreeQ[expression, acSparseU | acSparseV], acSparseMappedUnknowns = True];
    acSparseEvaluateDelegate[expression, chart, rules]]},
  ConstructiveDiagrams`Private`completionSparseValidation[
    acSparseTrial, {acSparseU, acSparseV}, acSparseSolution, {}, {},
    acSparseNormalized, 2, 57013, acScalarRules, 15, Automatic, False]];
check["held-out validation maps sparse components rather than the dense fitted candidate",
  acSparseValidation["Report"]["Summary"] === <|"PASS" -> 1|> &&
    acSparseValidation["FamilyPass"] && acSparseMappedSizes =!= {} &&
    !acSparseMappedUnknowns &&
    Max[acSparseMappedSizes] < LeafCount[acSparseDenseCandidate]];
check["sparse held-out reports preserve exact feedback and validated chart metadata",
  acSparseValidation["Feedback"]["Status"] === "COMPLETE" &&
    Length[acSparseValidation["Feedback"]["Samples"]] === 2 &&
    !FreeQ[acSparseValidation["Feedback"]["Equations"], acSparseU] &&
    AllTrue[First[acSparseValidation["Report"]["Channels"]]["Samples"],
      #["RandomSeed"] === 57013 && #["ParameterRules"] === acScalarRules &&
        AssociationQ[#["Kinematics"]] && TrueQ[#["KinematicChecks"]["Valid"]] &]];
acSparseFreeFailure = ConstructiveDiagrams`Private`completionSparseValidation[
  acAdaptiveTarget["StateSum"]/acAdaptiveDen + acSparseU Last[acAdaptiveBasis],
  {acSparseU}, <|"SolutionRules" -> {}, "FreeParameters" -> {acSparseU}|>,
  {acSparseU}, {}, acSparseNormalized, 1, 57013, acScalarRules, 15, Automatic, False];
check["a passing zero-free representative cannot hide a failing affine-family direction",
  acSparseFreeFailure["Report"]["Summary"] === <|"PASS" -> 1|> &&
    !acSparseFreeFailure["FamilyPass"] &&
    acSparseFreeFailure["Feedback"]["Status"] === "COMPLETE" &&
    !FreeQ[acSparseFreeFailure["Feedback"]["Equations"], acSparseU]];
acSparseSingular = ConstructiveDiagrams`Private`completionSparseValidation[
  acSparseU/acAdaptiveDen^2, {acSparseU},
  <|"SolutionRules" -> {acSparseU -> 0}, "FreeParameters" -> {}|>, {}, {},
  acSparseNormalized, 1, 57013, acScalarRules, 15, Automatic, False];
check["canceling an unused higher-pole direction cannot hide a required nonzero residue",
  acSparseSingular["Report"]["Summary"] === <|"FAIL" -> 1|> &&
    acSparseSingular["Feedback"]["Status"] === "COMPLETE" &&
    !acSparseSingular["FamilyPass"] &&
    AllTrue[First[acSparseSingular["Report"]["Channels"]]["Samples"],
      #["CalculatedResidue"] === 0 && !acZero[#["ExpectedResidue"]] &&
        acZero[#["Difference"] + #["ExpectedResidue"]] &&
        #["ConstraintMethod"] === "ExactRationalLaurent" &&
        TrueQ[#["PrincipalPartCancellationVerified"]] &&
        AllTrue[#["PrincipalPartCertificate"]["CandidatePrincipalEquations"], acZero] &]];
acSparseSurvivingHigherPole = ConstructiveDiagrams`Private`completionSparseValidation[
  acSparseU/acAdaptiveDen^2, {acSparseU},
  <|"SolutionRules" -> {acSparseU -> 1}, "FreeParameters" -> {}|>, {}, {},
  acSparseNormalized, 1, 57013, acScalarRules, 15, Automatic, False];
check["a surviving higher pole never receives a regular sparse-validation certificate",
  acSparseSurvivingHigherPole["Report"]["Summary"] === <|"UNRESOLVED" -> 1|> &&
    acSparseSurvivingHigherPole["Feedback"]["Status"] === "UNRESOLVED" &&
    !acSparseSurvivingHigherPole["FamilyPass"]];
acSparseSpinNormalized = ConstructiveDiagrams`Private`completionNormalizeInput[
  0, prFourPointChannels, prModel];
acSparseSpinValidation = ConstructiveDiagrams`Private`completionSparseValidation[
  acSparseU prFourPointAmplitude, {acSparseU},
  <|"SolutionRules" -> {acSparseU -> 1}, "FreeParameters" -> {}|>, {}, {},
  acSparseSpinNormalized, 1, 57013,
  ModelParameterRules[prModel, {"Me" -> 1, "EE" -> 1}], 15, Automatic, False];
check["sparse validation certifies every coherent massive-spin component on all supplied cuts",
  acSparseSpinValidation["Report"]["Summary"] === <|"PASS" -> 2|> &&
    acSparseSpinValidation["FamilyPass"] &&
    AllTrue[Flatten[Lookup[acSparseSpinValidation["Report"]["Channels"], "Samples"]],
      Length[#["SpinVariables"]] === 2 && TrueQ[#["KinematicChecks"]["Valid"]] &&
        And @@ #["KinematicChecks"]["UncutChannelsRemainGeneric"] &]];
acLargeSparseVariables = Table[Unique["heldOutCoefficient"], 128];
acLargeSparseFree = Take[acLargeSparseVariables, -64];
acLargeSparseSolution = <|"SolutionRules" -> Thread[
  Take[acLargeSparseVariables, 64] -> -acLargeSparseFree],
  "FreeParameters" -> acLargeSparseFree|>;
acLargeSparseValidation = ConstructiveDiagrams`Private`completionSparseValidation[
  (1 + Total[acLargeSparseVariables]) prFourPointAmplitude, acLargeSparseVariables,
  acLargeSparseSolution, acLargeSparseFree, {}, acSparseSpinNormalized, 1, 57013,
  ModelParameterRules[prModel, {"Me" -> 1, "EE" -> 1}], 15, Automatic, False];
check["large sparse held-out validation certifies the full affine family before mapping a dense candidate",
  acLargeSparseValidation["Report"]["Summary"] === <|"PASS" -> 2|> &&
    TrueQ[acLargeSparseValidation["FamilyPass"]] &&
    AllTrue[Flatten[Lookup[acLargeSparseValidation["Report"]["Channels"], "Samples"]],
      #["AffineFamilyValidationCertificate"]["Method"] === "ExactSparseAffineMatrixComposition" &&
        #["AffineFamilyValidationCertificate"]["AllOriginalEquationsRetained"] &&
        #["AffineFamilyValidationCertificate"]["FreeParameters"] === acLargeSparseFree &]];
acLargeSparseBadFamily = Join[acLargeSparseSolution, <|"SolutionRules" -> Thread[
  Take[acLargeSparseVariables, 64] -> acLargeSparseFree]|>];
acLargeSparseBadValidation = ConstructiveDiagrams`Private`completionSparseValidation[
  (1 + Total[acLargeSparseVariables]) prFourPointAmplitude, acLargeSparseVariables,
  acLargeSparseBadFamily, acLargeSparseFree, {}, acSparseSpinNormalized, 1, 57013,
  ModelParameterRules[prModel, {"Me" -> 1, "EE" -> 1}], 15, Automatic, False];
check["a large passing sparse representative still rejects a nonzero held-out affine-family direction",
  acLargeSparseBadValidation["Report"]["Summary"] === <|"PASS" -> 2|> &&
    !TrueQ[acLargeSparseBadValidation["FamilyPass"]] &&
    acLargeSparseBadValidation["Feedback"]["Status"] === "COMPLETE"];
(* Initial symmetry checks have no fitted variables, so their minimal solution
   needs only SolutionRules. An absent optional key must still yield a list of
   substitutions and evaluate every real QED cut, rather than leave jobs inert. *)
acSparseNoUnknownRun[amplitude_, solution_] := Block[
  {ConstructiveDiagrams`Private`$completionParallelSettings = <|"Parallelization" -> False|>},
  ConstructiveDiagrams`Private`completionSparseValidation[
    amplitude, {}, solution, {}, {}, acSparseSpinNormalized, 2, 57017,
    ModelParameterRules[prModel, {"Me" -> 1, "EE" -> 1}], 15, Automatic, False]];
acSparseMinimalSolution = acSparseNoUnknownRun[prFourPointAmplitude,
  <|"SolutionRules" -> {}|>];
acSparseExplicitEmptySolution = acSparseNoUnknownRun[prFourPointAmplitude,
  <|"SolutionRules" -> {}, "FreeParameters" -> {}|>];
acSparseDoubledNoUnknown = acSparseNoUnknownRun[2 prFourPointAmplitude,
  <|"SolutionRules" -> {}|>];
acSparseMinimalSamples = Flatten[Lookup[acSparseMinimalSolution["Report"]["Channels"], "Samples"]];
acSparseExplicitSamples = Flatten[Lookup[acSparseExplicitEmptySolution["Report"]["Channels"], "Samples"]];
check["minimal no-variable sparse solutions evaluate every QED cut and numerical spin coefficient",
  acSparseMinimalSolution["Report"]["Summary"] === <|"PASS" -> 2|> &&
    acSparseMinimalSolution["Feedback"]["Status"] === "COMPLETE" &&
    acSparseMinimalSolution["FamilyPass"] && Length[acSparseMinimalSamples] === 4 &&
    AllTrue[acSparseMinimalSamples, Function[sample,
      TrueQ[sample["KinematicChecks"]["Valid"]] &&
        AllTrue[Lookup[sample, {"CalculatedResidue", "ExpectedResidue"}], Function[value,
          PolynomialQ[value, sample["SpinVariables"]] &&
            AllTrue[Last /@ CoefficientRules[value, sample["SpinVariables"]], NumericQ]]]]]];
check["a doubled no-variable candidate remains a genuine sparse residue failure",
  acSparseDoubledNoUnknown["Report"]["Summary"] === <|"FAIL" -> 2|> &&
    acSparseDoubledNoUnknown["Feedback"]["Status"] === "COMPLETE" &&
    !acSparseDoubledNoUnknown["FamilyPass"] &&
    AllTrue[Flatten[Lookup[acSparseDoubledNoUnknown["Report"]["Channels"], "Samples"]],
      Together[#["CalculatedResidue"] - 2 #["ExpectedResidue"]] === 0 &]];
check["explicit and omitted empty FreeParameters give the same evaluated residues",
  acSparseExplicitEmptySolution["Report"]["Summary"] === <|"PASS" -> 2|> &&
    Length[acSparseMinimalSamples] === Length[acSparseExplicitSamples] &&
    And @@ MapThread[Function[{minimal, explicit},
      With[{common = Array[acSparseCompareSpin, Length[minimal["SpinVariables"]]]},
        And @@ Map[Function[key, Together[
          (minimal[key] /. Thread[minimal["SpinVariables"] -> common]) -
          (explicit[key] /. Thread[explicit["SpinVariables"] -> common])] === 0],
          {"CalculatedResidue", "ExpectedResidue", "Difference"}]]],
      {acSparseMinimalSamples, acSparseExplicitSamples}]];
acNoFeedback = acFactor[0, Take[acScalarFourChannels, 1], acScalarModel,
  "CorrectionBasis" -> acAdaptiveBasis, "ParameterRules" -> acScalarRules,
  "Samples" -> 1, "ValidationSamples" -> 1, "MaxRefinements" -> 0];
check["disabling feedback leaves an underfitted affine family unresolved",
  acNoFeedback["Status"] === "UNRESOLVED" &&
    Length[acNoFeedback["RefinementHistory"]] === 1];
acAdaptive = acFactor[0, Take[acScalarFourChannels, 1], acScalarModel,
  "CorrectionBasis" -> acAdaptiveBasis, "ParameterRules" -> acScalarRules,
  "Samples" -> 1, "ValidationSamples" -> 1];
check["held-out affine-family failures become simultaneous equations and repair an underfit",
  acAdaptive["Status"] === "COMPLETE" &&
    Length[acAdaptive["RefinementHistory"]] >= 2 &&
    acAdaptive["FreeParameters"] === {} &&
    acPhysicalPass[acAdaptive["ValidationReport"]]];
acAdaptiveHistory = acAdaptive["RefinementHistory"];
check["refinement records retain fresh independent validation seeds and expanding sample counts",
  ListQ[acAdaptiveHistory] &&
    DuplicateFreeQ[Lookup[acAdaptiveHistory, "ValidationSeed"]] &&
    AllTrue[acAdaptiveHistory,
      #["FitSeed"] =!= #["ValidationSeed"] &&
        ContainsAll[Keys[#], {"Round", "EquationCount", "Rank", "FreeParameters", "Status"}] &] &&
    OrderedQ[Lookup[acAdaptiveHistory, "ValidationSamples"]] &&
    Last[Lookup[acAdaptiveHistory, "ValidationSamples"]] >
      First[Lookup[acAdaptiveHistory, "ValidationSamples"]]];
check["validation feedback retains the exact additional constraints for inspection",
  AssociationQ[acAdaptive["ConstraintData"]["Validation"]] &&
    acAdaptive["ConstraintData"]["Validation"]["Status"] === "COMPLETE" &&
    Length[acAdaptive["ConstraintData"]["Fit"]["Equations"]] >
      First[acAdaptiveHistory]["EquationCount"] &&
    AnyTrue[acAdaptive["ConstraintData"]["Fit"]["Samples"],
      KeyExistsQ[#, "RandomSeed"] && AssociationQ[Lookup[#, "Chart", None]] &]];
acAdaptiveRedundant = acFactor[0, Take[acScalarFourChannels, 1], acScalarModel,
  "CorrectionBasis" -> Join[acCubicCoupling^2 acAdaptiveBasis,
    {acCubicCoupling^2 (1 + (MomProd @@ acAdaptivePair))/acAdaptiveDen, 1}],
  "ParameterRules" -> acScalarRules, "Samples" -> 1, "ValidationSamples" -> 1];
check["raw-equation refinement removes redundant freedom but retains a genuine local direction",
  acAdaptiveRedundant["Status"] === "COMPLETE" &&
    Length[acAdaptiveRedundant["RefinementHistory"]] >= 2 &&
    Last[acAdaptiveRedundant["RefinementHistory"]]["RemovedZeroDirections"] >= 1 &&
    acAdaptiveRedundant["RemainingBasis"] === {1} &&
    Length[acAdaptiveRedundant["FreeParameters"]] === 1 &&
    acZero[acAdaptiveRedundant["Amplitude"] -
      acAdaptiveTarget["StateSum"]/acAdaptiveDen] &&
    acPhysicalPass[acAdaptiveRedundant["ValidationReport"]]];

(* Deliberately slow cosmetic work must not revoke already validated success. *)
acCleanupDirections = Table[MomProd[1, 3]^power, {power, 0, 16}];
acCleanupCalls = 0;
acCleanupInterrupted = Block[
  {ConstructiveDiagrams`Private`completionExternalReduce = Function[{value, massRules},
    acCleanupCalls++; Pause[10]; value]},
  acFactor[acScalarFour, acScalarFourChannels, acScalarModel,
    "CorrectionBasis" -> acCleanupDirections, "ParameterRules" -> acScalarRules,
    "Samples" -> 1, "ValidationSamples" -> 1, "TimeConstraint" -> 30]];
check["interrupted optional cleanup preserves the validated candidate and complete affine family",
  acCleanupCalls >= 1 && acCleanupInterrupted["Status"] === "COMPLETE" &&
    acPhysicalPass[acCleanupInterrupted["ValidationReport"]] &&
    Length[acCleanupInterrupted["FreeParameters"]] === Length[acCleanupDirections] &&
    acCleanupInterrupted["RemainingBasis"] === acCleanupDirections &&
    acZero[acCanonical[acCleanupInterrupted["Amplitude"] - acScalarFour, 4]] &&
    acZero[acCleanupInterrupted["FamilyAmplitude"] - acCleanupInterrupted["Amplitude"] -
      acCleanupInterrupted["FreeParameters"].acCleanupInterrupted["RemainingBasis"]]];
acExplicitInsufficient = acFactor[0, Take[acScalarFourChannels, 1], acScalarModel,
  "CorrectionBasis" -> {(MomProd @@ acAdaptivePair)/acAdaptiveDen},
  "ParameterRules" -> acScalarRules, "Samples" -> 2, "ValidationSamples" -> 1];
check["adaptive validation never invents a correction outside an explicit insufficient basis",
  acExplicitInsufficient["Status"] === "UNRESOLVED" &&
    acExplicitInsufficient["ConstraintData"]["LinearSolution"]["Status"] === "INCONSISTENT" &&
    Length[acExplicitInsufficient["CorrectionBasis"]] === 1];
acLimited = acFactor[0, acScalarFiveChannels, acScalarKnownModel,
  "ParameterRules" -> acScalarRules, "MaxCorrectionTerms" -> 1];
check["an undersized correction space is unresolved rather than silently truncated",
  acLimited["Status"] === "UNRESOLVED" && acLimited["Amplitude"] === 0];
acNoDirections = CompleteFactorization[0, acScalarFourChannels, acScalarModel,
  "CorrectionBasis" -> {}, "ParameterRules" -> acScalarRules,
  "Samples" -> 1, "ValidationSamples" -> 1, "ProgressReporting" -> False];
check["default incomplete factorization returns a compact failure rather than an unvalidated candidate",
  FailureQ[acNoDirections] && acNoDirections[[1]] === "IncompleteAmplitude" &&
    !KeyExistsQ[acNoDirections[[2]], "Report"] &&
    !KeyExistsQ[acNoDirections[[2]], "Amplitude"]];
acNoDirectionsDetails = CompleteFactorization[0, acScalarFourChannels, acScalarModel,
  "CorrectionBasis" -> {}, "ParameterRules" -> acScalarRules,
  "Samples" -> 1, "ValidationSamples" -> 1, "ProgressReporting" -> False,
  "ReturnDetails" -> True];
check["opt-in incomplete factorization details retain the candidate and diagnostic reports",
  AssociationQ[acNoDirectionsDetails] && acNoDirectionsDetails["Status"] === "UNRESOLVED" &&
    acNoDirectionsDetails["Amplitude"] === 0 &&
    ContainsAll[Keys[acNoDirectionsDetails], {"InitialReport", "Correction", "Diagnostics"}]];
acFactorTimed = acFactor[0, acScalarFiveChannels, acScalarKnownModel,
  "ParameterRules" -> acScalarRules, "TimeConstraint" -> 0.000001];
check["factorization timeouts preserve the starting candidate",
  acFactorTimed["Status"] === "UNRESOLVED" && acFactorTimed["Amplitude"] === 0];
check["automatic channel continuations and bounded validation feedback are enabled by default",
  ("ChannelReferences" /. Options[CompleteFactorization]) === Automatic &&
    ("MaxRefinements" /. Options[CompleteFactorization]) === 3];
Do[
  check["invalid factorization continuation or refinement option is rejected " <>
      ToString[bad, InputForm],
    acInvalid[Quiet[CompleteFactorization[prH, prChannels, prFixtureModel,
      bad, "ProgressReporting" -> False]]]],
  {bad, {"ChannelReferences" -> "Random", "ChannelReferences" -> False,
    "MaxRefinements" -> -1, "MaxRefinements" -> 1/2,
    "MaxRefinements" -> Infinity}}
];

(* High-energy completion uses a bounded declared family, not arbitrary contacts. *)
Print["Checking high-energy completion and preserved physical residues."];
acScalarLocalRepair = CompleteHighEnergy[{acExternalZero, 7 + MomProd[1, 2]}, {},
  acMasslessScalarModel, "Samples" -> 2, "ValidationSamples" -> 2,
  "ProgressReporting" -> False, "Output" -> "Expression"];
check["automatic high-energy completion removes an existing inadmissible local term",
  acScalarLocalRepair === 7];
acReferenceArtifact = SpinorChain[Spinor["Xi", "Angle", 71],
  Spinor["Helicity", "Angle", 3]]/
    SpinorChain[Spinor["Xi", "Angle", 71], Spinor["Helicity", "Angle", 4]];
acReferenceRepair = acEnergy[{acExternalZero, 7 + acReferenceArtifact}, {},
  acMasslessScalarModel, "CorrectionBasis" -> {acReferenceArtifact}];
check["reference-dependent spurious artifacts can be removed despite acceptable energy scaling",
  acReferenceRepair["Status"] === "COMPLETE" && acReferenceRepair["Amplitude"] === 7 &&
    acAllPass[acReferenceRepair["AfterReport"]]];
check["the final stage jointly uses spurious-pole and reference-independence constraints",
  acReferenceRepair["ConstraintData"]["Spurious"]["Equations"] =!= {} &&
    (acReferenceRepair["ConstraintData"]["Reference"]["Equations"] =!= {} ||
      (* Earlier exact constraints can already remove every reference-dependent
         coefficient. The independent reference check remains mandatory. *)
      acReferenceRepair["SequentialConstraintReductions"]["Spurious"]["Status"] === "COMPLETE" &&
      acReferenceRepair["FreeParameters"] === {} &&
      acReferenceRepair["AfterReport"]["ReferenceCheck"]["Status"] === "PASS")];
acMassiveExternal = Thread[(Mass /@ Range[4]) -> ConstantArray[acScalarMass, 4]];
acWrongMassFit = acEnergy[{acMassiveExternal, 7 + acScalarMass^2 MomProd[1, 2]}, {},
  acScalarModel, "ParameterRules" -> {acScalarMass -> 1},
  "CorrectionBasis" -> {MomProd[1, 2]}];
check["held-out mass validation rejects a coefficient fitted only at one parameter point",
  acWrongMassFit["Status"] === "UNRESOLVED"];
acRightMassFit = acEnergy[{acMassiveExternal, 7 + acScalarMass^2 MomProd[1, 2]}, {},
  acScalarModel, "ParameterRules" -> {acScalarMass -> 1},
  "CorrectionBasis" -> {acScalarMass^2 MomProd[1, 2]}];
check["a basis with the correct analytic mass dependence survives independent validation",
  acRightMassFit["Status"] === "COMPLETE" && acRightMassFit["Amplitude"] === 7];
acQEDComplete = acEnergy[prH, prChannels, prFixtureModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}];
check["a complete QED amplitude passes the final stage unchanged",
  acQEDComplete["Status"] === "COMPLETE" &&
    acZero[acQEDComplete["Amplitude"] - prH] && acQEDComplete["Correction"] === 0];
check["final completion exposes every independent validation category",
  acAllPass[acQEDComplete["AfterReport"]] &&
    ContainsAll[Keys[acQEDComplete["AfterReport"]],
      {"PhysicalSummary", "SpuriousSummary", "HighEnergyCheck", "ReferenceCheck"}]];
acUnder = acEnergy[acFree, acScalarFourChannels, acScalarModel,
  "ParameterRules" -> acScalarRules];
check["acceptable-growth contact freedom is honestly underdetermined",
  acUnder["Status"] === "UNDERDETERMINED" && acUnder["FreeParameters"] =!= {} &&
    acAllPass[acUnder["AfterReport"]]];
Get[FileNameJoin[{root, "tests", "checks", "fixtures", "simplification-paths.wl"}]];
acSMModel = ReadModel[FileNameJoin[{root, "models"}], 1];
acSMReferenceParameters = {Mh -> ModelParameter[acSMModel, "Mh"],
  MZ -> ModelParameter[acSMModel, "MZ"], MW -> ModelParameter[acSMModel, "MW"],
  SW -> ModelParameter[acSMModel, "SW"], CW -> ModelParameter[acSMModel, "CW"],
  EE -> ModelParameter[acSMModel, "EE"]};
acSMRows = Select[simplificationReferences,
  StringStartsQ[#["Name"], "SM-4-point-test.nb / h h -> Z Z / "] &] /.
    acSMReferenceParameters;
acSMFull = Total[Lookup[acSMRows, "Amplitude"]];
acSMContact = SelectFirst[acSMRows, StringEndsQ[#["Name"], "contact"] &]["Amplitude"];
acSMChannels = FactorizationAmplitudeChannels[{"h", "h", "Z", "Z"}, acSMModel];
acSMRules = {"Mh" -> 3, "MZ" -> 1, "MW" -> 4/5,
  "SW" -> 3/5, "CW" -> 4/5, "EE" -> 1};
acSMRepair = acEnergy[acSMFull - acSMContact, acSMChannels, acSMModel,
  "CorrectionBasis" -> {acSMContact}, "ParameterRules" -> acSMRules];
check["the known SM contact is recovered by cancelling longitudinal high-energy growth",
  acSMRepair["Status"] === "COMPLETE" && acZero[acSMRepair["Amplitude"] - acSMFull] &&
    acZero[acSMRepair["Correction"] - acSMContact]];
check["the SM contact repair preserves all three independently known factorization channels",
  acAllPass[acSMRepair["AfterReport"]] &&
    acSMRepair["AfterReport"]["PhysicalSummary"] === <|"PASS" -> 3|>];
acSMHeldOut = CheckPhysicalResidues[acSMRepair["Amplitude"], acSMChannels, acSMModel,
  "ParameterRules" -> {"Mh" -> 5, "MZ" -> 2, "MW" -> 8/5,
    "SW" -> 3/5, "CW" -> 4/5, "EE" -> 2},
  "Samples" -> 3, "HighEnergySamples" -> 3, "RandomSeed" -> 8191,
  "Output" -> "Details", "TimeConstraint" -> 30];
check["the SM repair survives held-out masses, coupling, momenta and vector polarizations",
  acAllPass[acSMHeldOut]];
acSMNoBasis = acEnergy[acSMFull - acSMContact, acSMChannels, acSMModel,
  "CorrectionBasis" -> {}, "ParameterRules" -> acSMRules];
check["a failed amplitude is not repaired by inventing independent contact structures",
  acSMNoBasis["Status"] === "UNRESOLVED" &&
    acZero[acSMNoBasis["Amplitude"] - (acSMFull - acSMContact)]];
acEnergyFailure = CompleteHighEnergy[acSMFull - acSMContact, acSMChannels, acSMModel,
  "CorrectionBasis" -> {}, "ParameterRules" -> acSMRules,
  "Samples" -> 1, "ValidationSamples" -> 1, "ProgressReporting" -> False];
check["default incomplete high-energy completion returns an inspectable failure",
  FailureQ[acEnergyFailure] && acEnergyFailure[[1]] === "IncompleteAmplitude" &&
    KeyExistsQ[acEnergyFailure[[2]], "Report"]];
acOld = acEnergy[prOldPermutation, prChannels, prFixtureModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "Samples" -> 1,
  "ValidationSamples" -> 1, "TimeConstraint" -> 20];
check["the old permutation formula cannot be called complete while any check fails",
  If[acOld["Status"] === "COMPLETE", acAllPass[acOld["AfterReport"]],
    MemberQ[{"UNRESOLVED", "UNDERDETERMINED"}, acOld["Status"]]]];
acEnergyTimed = acEnergy[prH, prChannels, prFixtureModel,
  "ParameterRules" -> {prElectronMass -> 1, prElectricCharge -> 1}, "TimeConstraint" -> 0.000001];
check["high-energy timeouts retain the supplied amplitude and mandatory diagnostic fields",
  acEnergyTimed["Status"] === "UNRESOLVED" &&
    acZero[acEnergyTimed["Amplitude"] - prH] &&
    ContainsAll[Keys[acEnergyTimed],
      {"Amplitude", "Correction", "CorrectionBasis", "FamilyAmplitude", "FreeParameters"}]];
Do[
  check["invalid completion option is rejected " <> ToString[{function, bad}, InputForm],
    acInvalid[Quiet[function[prH, prChannels, prFixtureModel, bad]]]],
  {function, {CompleteFactorization, CompleteHighEnergy}},
  {bad, {"Samples" -> 0, "ValidationSamples" -> 0, "MaxCorrectionTerms" -> 0,
    "CorrectionBasis" -> "Everything", "TimeConstraint" -> 0, "Output" -> "Everything",
    "ParameterRules" -> 42, "ParameterRules" -> {acScalarMass},
    "ProgressFunction" -> 42, "UnknownCompletionOption" -> 1}}
];
Do[
  check["malformed completion calls are rejected " <> ToString[function, InputForm],
    acInvalid[Quiet[function[1]]]],
  {function, {CompleteFactorization, CompleteHighEnergy}}
];

(* Propagator-only support discovery equivalence. *)
acSupportModel = {{{"Scalar", "s", "s", 1, 0, acSupportMass, 0, 1, 1, "", ""}},
  {{"s", "s", "s", "", acSupportCoupling, 1}}, {}, {}};
acSupportRules = Table[Mass[i] -> acSupportMass, {i, 4}];
acSupportChannels = FactorizationAmplitudeChannels[ConstantArray["s", 4], acSupportModel];
acSupportOriginal[trial_, rows_List] := ConstructiveDiagrams`Private`residueSimpleInputs[
  {acSupportRules, trial}, rows, acSupportModel];
acSupportFast[trial_, rows_List] := ConstructiveDiagrams`Private`completionSupportInputs[
  trial, acSupportRules, rows, acSupportModel];
acSupportTargets[value_Association] := SortBy[value["Targets"],
  ConstructiveDiagrams`Private`residueChannelKey];
acSupportKeys[value_Association] := Sort[DeleteDuplicates[
  ConstructiveDiagrams`Private`residueChannelKey /@
    Flatten[Lookup[value["Records"], "PhysicalPropagators", {}], 1]]];
acSupportSameQ[left_, right_] := AssociationQ[left] && AssociationQ[right] &&
  acSupportTargets[left] === acSupportTargets[right] &&
  acSupportKeys[left] === acSupportKeys[right];
acSupportBaseTargets = acSupportOriginal[0, acSupportChannels]["Targets"];
acSupportPole = First[acSupportBaseTargets]["Propagator"];
acSupportOtherPole = Last[acSupportBaseTargets]["Propagator"];
acSupportTrial = acSupportA (1 + MomProd[1, 2]^2)/acSupportPole +
  acSupportB/acSupportOtherPole;
acSupportSavedTrial = acSupportTrial; acSupportSavedModel = acSupportModel;
acSupportStandard = acSupportFast[acSupportTrial, acSupportChannels];
check["propagator-only support discovery preserves all supplied targets and physical pole keys",
  acSupportSameQ[acSupportStandard, acSupportOriginal[acSupportTrial, acSupportChannels]]];
acSupportMissingRows = Rest[acSupportChannels];
acSupportMissing = acSupportFast[acSupportTrial, acSupportMissingRows];
acSupportMissingTarget = SelectFirst[acSupportMissing["Targets"],
  ConstructiveDiagrams`Private`residueChannelKey[#] ===
    ConstructiveDiagrams`Private`residueChannelKey[First[acSupportBaseTargets]] &];
check["propagator-only support discovery retains missing-channel zero-residue obligations",
  acSupportSameQ[acSupportMissing, acSupportOriginal[acSupportTrial, acSupportMissingRows]] &&
    acSupportMissingTarget["Complete"] === True && acSupportMissingTarget["StateSum"] === 0];
acSupportUnknownTrial = acSupportTrial + acSupportC/
  PropDen[Mom[Multiparticle[1, 3]], acSupportUnknownMass];
acSupportUnknown = acSupportFast[acSupportUnknownTrial, acSupportChannels];
acSupportUnknownTarget = SelectFirst[acSupportUnknown["Targets"],
  #["Mass"] === acSupportUnknownMass &];
check["an unknown exchange mass remains incomplete in propagator-only support discovery",
  acSupportSameQ[acSupportUnknown, acSupportOriginal[acSupportUnknownTrial, acSupportChannels]] &&
    acSupportUnknownTarget["Complete"] === False &&
    acSupportUnknownTarget["StateSum"] === Missing["UnknownExchangeMass"]];
acSupportComplementTrial = acSupportA/PropDen[Mom[Multiparticle[3, 4]], Mass[1]] +
  acSupportB/PropDen[Mom[Multiparticle[2, 4]], Mass[2]];
acSupportComplement = acSupportFast[acSupportComplementTrial, acSupportChannels];
check["support discovery canonicalizes complement cuts and applies external mass rules identically",
  acSupportSameQ[acSupportComplement,
    acSupportOriginal[acSupportComplementTrial, acSupportChannels]] &&
    acSupportKeys[acSupportComplement] ===
      {{{1, 2}, acSupportMass}, {{1, 3}, acSupportMass}} &&
    FreeQ[acSupportKeys[acSupportComplement], _Mass]];
check["a pole-free support inventory preserves the supplied channel targets without inventing a pole",
  acSupportSameQ[acSupportFast[acSupportA, acSupportChannels],
    acSupportOriginal[acSupportA, acSupportChannels]] &&
    acSupportKeys[acSupportFast[acSupportA, acSupportChannels]] === {}];
acSupportInvalidTrials = {Failure["SupportFixture", <||>], Missing["SupportFixture"],
  $Failed, $Aborted, $TimedOut, Indeterminate, ComplexInfinity, DirectedInfinity[1],
  ConditionalExpression[acSupportTrial, acSupportCondition]};
acSupportInvalidResults = ({acSupportFast[#, acSupportChannels],
    acSupportOriginal[#, acSupportChannels]} &) /@ acSupportInvalidTrials;
check["failed and missing trials retain the original failure instead of losing their markers",
  AllTrue[Take[acSupportInvalidResults, 5], FailureQ[First[#]] && First[#] === Last[#] &]];
check["nonfinite and conditional trials retain the original invalid result without stripping its expression",
  AllTrue[Drop[acSupportInvalidResults, 5], Function[pair,
    First[pair] === Last[pair] && (FailureQ[First[pair]] ||
      (AssociationQ[First[pair]] &&
        !ConstructiveDiagrams`Private`residueFiniteQ[First[pair]["Expression"]]))]]];
check["support inventory discovery leaves the full trial and supplied model unchanged",
  acSupportTrial === acSupportSavedTrial && acSupportModel === acSupportSavedModel];
acSupportProgressInput = ConstructiveDiagrams`Private`completionNormalizeInput[
  0, acSupportChannels, acSupportModel];
acSupportProgressEvents = {};
acSupportProgressConstraints = ConstructiveDiagrams`Private`completionResidueConstraints[
  acSupportA Total[1/Lookup[acSupportProgressInput["Targets"], "Propagator"]],
  {acSupportA}, acSupportProgressInput, 2, 9183,
  {acSupportMass -> 1, acSupportCoupling -> 2}, 10,
  (AppendTo[acSupportProgressEvents, #] &), True];
acSupportSampleEvents = Select[acSupportProgressEvents,
  Lookup[#, "Stage", ""] === "Factorization samples" &];
check["factorization sample progress counts every sample and names its cut",
  acSupportProgressConstraints["Status"] === "COMPLETE" &&
    Lookup[acSupportSampleEvents, "Completed"] === Range[6] &&
    Lookup[acSupportSampleEvents, "Total"] === ConstantArray[6, 6] &&
    AllTrue[Lookup[acSupportSampleEvents, "Cut"],
      MemberQ[Lookup[acSupportProgressInput["Targets"], "Cut"], #] &]];
(* End propagator-only support discovery equivalence. *)

(* Exact polynomial coefficient and linear-normalization shortcuts. *)
acPolynomialZero[value_] := TrueQ[RootReduce[Cancel[Together[value]]] === 0];
acPolynomialLegacyCoefficients[expression_, variables_List] := Module[{numerator},
  numerator = Numerator[Cancel[Together[expression]]];
  If[variables === {}, Return[{numerator}]];
  If[!PolynomialQ[numerator, variables],
    Return[Failure["NonPolynomialSpinDependence", <||>]]];
  Last /@ CoefficientRules[Expand[numerator], variables]
];
acPolynomialLegacyRows[rows_List] :=
  (Quiet[RootReduce[Numerator[Cancel[Together[#]]]]] &) /@ rows;
acPolynomialUnknowns = {acPolynomialU, acPolynomialV, acPolynomialW};
acPolynomialSpin = {acPolynomialS, acPolynomialT};
acPolynomialExpression = (1/3 + I/7) (2 acPolynomialU + acPolynomialV - 5) acPolynomialS +
  (2/5 - I/11) (acPolynomialV - acPolynomialW + 3) acPolynomialS acPolynomialT +
  (4 acPolynomialU + 2 acPolynomialV - 10) acPolynomialT^2/13 +
  3 (acPolynomialU - 4 + acPolynomialW/2)/17;
acPolynomialDirect = ConstructiveDiagrams`Private`completionCoefficientEquations[
  acPolynomialExpression, acPolynomialSpin];
acPolynomialLegacy = acPolynomialLegacyCoefficients[acPolynomialExpression, acPolynomialSpin];
acPolynomialScale = Denominator[Cancel[Together[acPolynomialExpression]]];
check["direct spin-polynomial coefficients impose the same exact rational-complex constraints",
  Length[acPolynomialDirect] === 4 && Length[acPolynomialLegacy] === 4 &&
    AllTrue[acPolynomialDirect, PolynomialQ[#, acPolynomialUnknowns] &] &&
    And @@ MapThread[acPolynomialZero[#1 acPolynomialScale - #2] &,
      {acPolynomialDirect, acPolynomialLegacy}]];
acPolynomialDirectFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acPolynomialDirect, acPolynomialUnknowns];
acPolynomialLegacyFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acPolynomialLegacyRows[acPolynomialLegacy], acPolynomialUnknowns];
acPolynomialDirectFamily = acPolynomialUnknowns /. acPolynomialDirectFit["SolutionRules"];
acPolynomialLegacyFamily = acPolynomialUnknowns /. acPolynomialLegacyFit["SolutionRules"];
check["polynomial row normalization preserves the full rational-complex affine solution",
  acPolynomialDirectFit["Status"] === "UNDERDETERMINED" &&
    acPolynomialLegacyFit["Status"] === "UNDERDETERMINED" &&
    acPolynomialDirectFit["Rank"] === 2 && acPolynomialLegacyFit["Rank"] === 2 &&
    acPolynomialDirectFit["FreeParameters"] === {acPolynomialW} &&
    acPolynomialLegacyFit["FreeParameters"] === {acPolynomialW} &&
    And @@ MapThread[acPolynomialZero[#1 - #2] &,
      {acPolynomialDirectFamily, acPolynomialLegacyFamily}] &&
    And @@ MapThread[acPolynomialZero[#1 - #2] &,
      {acPolynomialDirectFamily, {4 - acPolynomialW/2, acPolynomialW - 3, acPolynomialW}}] &&
    AllTrue[acPolynomialDirect /. acPolynomialDirectFit["SolutionRules"], acPolynomialZero]];
acPolynomialRationalSpin = (acPolynomialU + acPolynomialV)/(1 + acPolynomialS) -
  (acPolynomialU + acPolynomialV)/(1 + acPolynomialT);
check["rational spin dependence retains the legacy cleared-numerator fallback",
  ConstructiveDiagrams`Private`completionCoefficientEquations[
    acPolynomialRationalSpin, acPolynomialSpin] ===
      acPolynomialLegacyCoefficients[acPolynomialRationalSpin, acPolynomialSpin]];
check["unsupported nonpolynomial spin dependence remains an explicit failure",
  FailureQ[ConstructiveDiagrams`Private`completionCoefficientEquations[
    Sin[acPolynomialS], {acPolynomialS}]]];
check["an empty spin-variable list retains scalar numerator cancellation",
  ConstructiveDiagrams`Private`completionCoefficientEquations[
    (acPolynomialU^2 - 1)/(acPolynomialU - 1), {}] === {1 + acPolynomialU}];
acPolynomialRationalEquation = (acPolynomialU^2 - 1)/(acPolynomialU - 1) - 3;
acPolynomialRationalFit = ConstructiveDiagrams`Private`completionSolveLinear[
  {acPolynomialRationalEquation}, {acPolynomialU}];
check["nonpolynomial fitting rows still use exact cancellation before solving",
  acPolynomialRationalFit["Status"] === "COMPLETE" &&
    acPolynomialRationalFit["Rank"] === 1 &&
    acPolynomialRationalFit["SolutionRules"] === {acPolynomialU -> 2} &&
    acPolynomialZero[acPolynomialRationalEquation /. acPolynomialRationalFit["SolutionRules"]]];
acPolynomialCancelledSpin = (acPolynomialU + acPolynomialV) (acPolynomialS + acPolynomialT) -
  (acPolynomialU + acPolynomialV) acPolynomialS -
  (acPolynomialU + acPolynomialV) acPolynomialT;
acPolynomialCancelledRows = {(acPolynomialU + acPolynomialV) (1 + acPolynomialParameter) -
  acPolynomialU - acPolynomialV - acPolynomialU acPolynomialParameter -
  acPolynomialV acPolynomialParameter};
acPolynomialCancelledFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acPolynomialCancelledRows, acPolynomialUnknowns];
check["factored cancellation does not create a spin constraint or constrain a zero fitting row",
  ConstructiveDiagrams`Private`completionCoefficientEquations[
    acPolynomialCancelledSpin, acPolynomialSpin] === {} &&
    acPolynomialCancelledFit["Status"] === "UNDERDETERMINED" &&
    acPolynomialCancelledFit["Rank"] === 0 &&
    acPolynomialCancelledFit["SolutionRules"] === {} &&
    acPolynomialCancelledFit["FreeParameters"] === acPolynomialUnknowns];
acPolynomialUnresolvedFit = ConstructiveDiagrams`Private`completionSolveLinear[
  {acPolynomialParameter acPolynomialU + acPolynomialV - 1}, acPolynomialUnknowns];
check["polynomial rows with unresolved parameters remain unresolved instead of receiving a numeric fit",
  acPolynomialUnresolvedFit["Status"] === "UNRESOLVED" &&
    acPolynomialUnresolvedFit["SolutionRules"] === {}];
acPolynomialNonlinearFit = ConstructiveDiagrams`Private`completionSolveLinear[
  {acPolynomialU acPolynomialV - 1}, acPolynomialUnknowns];
check["already polynomial but nonlinear fitting rows are still rejected",
  acPolynomialNonlinearFit["Status"] === "UNRESOLVED" &&
    acPolynomialNonlinearFit["SolutionRules"] === {} &&
    AnyTrue[acPolynomialNonlinearFit["Diagnostics"], StringContainsQ[#, "linearly"] &]];
acPolynomialNonpolynomialFit = ConstructiveDiagrams`Private`completionSolveLinear[
  {Sin[acPolynomialU]}, acPolynomialUnknowns];
check["unsupported nonpolynomial fitting rows remain unresolved through the native normalization fallback",
  acPolynomialNonpolynomialFit["Status"] === "UNRESOLVED" &&
    acPolynomialNonpolynomialFit["SolutionRules"] === {}];
acPolynomialEmptyUnknownZero = ConstructiveDiagrams`Private`completionSolveLinear[
  {(acPolynomialU^2 - 1)/(acPolynomialU - 1) - acPolynomialU - 1}, {}];
acPolynomialEmptyUnknownNonzero = ConstructiveDiagrams`Private`completionSolveLinear[{1/7}, {}];
check["empty fitting-variable lists retain exact scalar cancellation and contradiction handling",
  acPolynomialEmptyUnknownZero["Status"] === "COMPLETE" &&
    acPolynomialEmptyUnknownZero["Rank"] === 0 &&
    acPolynomialEmptyUnknownNonzero["Status"] === "INCONSISTENT" &&
    acPolynomialEmptyUnknownNonzero["SolutionRules"] === {}];
acPolynomialInvalidFits = (ConstructiveDiagrams`Private`completionSolveLinear[
  {acPolynomialU/3 + #}, acPolynomialUnknowns] &) /@
    {Indeterminate, ComplexInfinity, Missing["PolynomialEntry"]};
check["nonfinite and missing polynomial coefficients remain unresolved without solution rules",
  AllTrue[acPolynomialInvalidFits, #["Status"] === "UNRESOLVED" &&
    #["SolutionRules"] === {} &]];
acPolynomialAlgebraicZero = Sqrt[5 + 2 Sqrt[6]] - Sqrt[2] - Sqrt[3];
acPolynomialAlgebraicRows = {
  acPolynomialAlgebraicZero acPolynomialU + (1 + I) (acPolynomialV - 3)/7,
  (Sqrt[2] + Sqrt[3]) (acPolynomialW + 1) + acPolynomialAlgebraicZero};
acPolynomialAlgebraicFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acPolynomialAlgebraicRows, acPolynomialUnknowns];
acPolynomialAlgebraicLegacyFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acPolynomialLegacyRows[acPolynomialAlgebraicRows], acPolynomialUnknowns];
check["entrywise algebraic reduction preserves an exactly zero affine column and the full solution",
  acPolynomialZero[acPolynomialAlgebraicZero] &&
    acPolynomialAlgebraicFit["Status"] === "UNDERDETERMINED" &&
    acPolynomialAlgebraicFit["Rank"] === 2 &&
    acPolynomialAlgebraicFit["FreeParameters"] === {acPolynomialU} &&
    And @@ MapThread[acPolynomialZero[#1 - #2] &,
      {acPolynomialUnknowns /. acPolynomialAlgebraicFit["SolutionRules"],
        acPolynomialUnknowns /. acPolynomialAlgebraicLegacyFit["SolutionRules"]}] &&
    AllTrue[acPolynomialAlgebraicRows /. acPolynomialAlgebraicFit["SolutionRules"], acPolynomialZero]];
acPolynomialAlgebraicCancelledFit = ConstructiveDiagrams`Private`completionSolveLinear[
  {acPolynomialAlgebraicZero (acPolynomialU + 1)}, acPolynomialUnknowns];
check["an exact algebraic zero row leaves every original fitting coefficient free",
  acPolynomialAlgebraicCancelledFit["Status"] === "UNDERDETERMINED" &&
    acPolynomialAlgebraicCancelledFit["Rank"] === 0 &&
    acPolynomialAlgebraicCancelledFit["SolutionRules"] === {} &&
    acPolynomialAlgebraicCancelledFit["FreeParameters"] === acPolynomialUnknowns];
acPolynomialAlgebraicDegreeRow = acPolynomialU - 2 +
  acPolynomialAlgebraicZero acPolynomialU acPolynomialV;
acPolynomialAlgebraicDegreeFit = ConstructiveDiagrams`Private`completionSolveLinear[
  {acPolynomialAlgebraicDegreeRow}, acPolynomialUnknowns];
acPolynomialAlgebraicDegreeLegacyFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acPolynomialLegacyRows[{acPolynomialAlgebraicDegreeRow}], acPolynomialUnknowns];
check["an apparent nonlinear algebraic degeneracy retains conservative legacy fallback handling",
  acPolynomialZero[acPolynomialAlgebraicZero] &&
    acPolynomialAlgebraicDegreeFit["Status"] === "UNRESOLVED" &&
    KeyTake[acPolynomialAlgebraicDegreeFit, {"Status", "Rank", "SolutionRules", "FreeParameters"}] ===
      KeyTake[acPolynomialAlgebraicDegreeLegacyFit,
        {"Status", "Rank", "SolutionRules", "FreeParameters"}]];
acPolynomialAffineRows = ConstructiveDiagrams`Private`completionCoefficientEquations[
  acPolynomialExpression, acPolynomialSpin, acPolynomialUnknowns];
acPolynomialAffineArrays = Normal /@ CoefficientArrays[
  acPolynomialAffineRows, acPolynomialUnknowns];
acPolynomialDirectArrays = Normal /@ CoefficientArrays[
  acPolynomialDirect, acPolynomialUnknowns];
acPolynomialLegacyArrays = Normal /@ CoefficientArrays[
  acPolynomialLegacy, acPolynomialUnknowns];
check["component-first spin extraction preserves exact affine matrices and legacy denominator-scaled constraints",
  RootReduce[acPolynomialAffineArrays] === RootReduce[acPolynomialDirectArrays] &&
    AllTrue[Flatten[acPolynomialLegacyArrays - acPolynomialScale acPolynomialAffineArrays],
      acPolynomialZero]];
acPolynomialAffineFit = ConstructiveDiagrams`Private`completionSolveLinear[
  acPolynomialAffineRows, acPolynomialUnknowns];
check["component-first spin extraction retains the same complete affine solution family",
  acPolynomialAffineFit["Status"] === "UNDERDETERMINED" &&
    acPolynomialAffineFit["Rank"] === 2 &&
    acPolynomialAffineFit["FreeParameters"] === {acPolynomialW} &&
    And @@ MapThread[acPolynomialZero[#1 - #2] &,
      {acPolynomialUnknowns /. acPolynomialAffineFit["SolutionRules"], acPolynomialDirectFamily}]];
acPolynomialFallbackExpressions = {
  (acPolynomialU acPolynomialV - 1) acPolynomialS,
  (acPolynomialU^2 - 1) acPolynomialT/(acPolynomialU - 1),
  acPolynomialRationalSpin, acPolynomialU Sin[acPolynomialS]};
check["component-first spin extraction preserves nonlinear and genuine rational-spin fallbacks",
  AllTrue[acPolynomialFallbackExpressions, Function[expression,
    ConstructiveDiagrams`Private`completionCoefficientEquations[
      expression, acPolynomialSpin, acPolynomialUnknowns] ===
      ConstructiveDiagrams`Private`completionCoefficientEquations[expression, acPolynomialSpin]]]];
check["component-first spin extraction handles empty arguments, cancellations and unknown-independent polynomials",
  ConstructiveDiagrams`Private`completionCoefficientEquations[
    acPolynomialExpression, {}, acPolynomialUnknowns] ===
      ConstructiveDiagrams`Private`completionCoefficientEquations[acPolynomialExpression, {}] &&
    ConstructiveDiagrams`Private`completionCoefficientEquations[
      acPolynomialExpression, acPolynomialSpin, {}] === acPolynomialDirect &&
    ConstructiveDiagrams`Private`completionCoefficientEquations[
      acPolynomialCancelledSpin, acPolynomialSpin, acPolynomialUnknowns] === {} &&
    ConstructiveDiagrams`Private`completionCoefficientEquations[
      5 acPolynomialS^2/7 + I acPolynomialT/11, acPolynomialSpin, acPolynomialUnknowns] ===
      ConstructiveDiagrams`Private`completionCoefficientEquations[
        5 acPolynomialS^2/7 + I acPolynomialT/11, acPolynomialSpin]];
(* End exact polynomial coefficient and linear-normalization shortcuts. *)

(* The public completion clock also bounds its certified modular backend. *)
acBudgetUnknowns = Array[Unique["acBudgetCoefficient"] &, 64];
acBudgetEquations = Take[acBudgetUnknowns, 63] - Range[63];
acBudgetSeen = {};
acBudgetDefault = Block[{ConstructiveDiagrams`Private`completionCertifiedModularReduce =
    Function[{matrix, constant, budget}, AppendTo[acBudgetSeen, budget]; Missing["TestNativeFallback"]]},
  ConstructiveDiagrams`Private`completionSolveLinear[acBudgetEquations, acBudgetUnknowns]];
check["two-argument linear solving retains the sixty-second modular default",
  acBudgetSeen === {60} && acBudgetDefault["Status"] === "UNDERDETERMINED" &&
    (Take[acBudgetUnknowns, 63] /. acBudgetDefault["SolutionRules"]) === Range[63] &&
    acBudgetDefault["FreeParameters"] === Take[acBudgetUnknowns, -1]];
acBudgetSeen = {};
acBudgetExplicit = Block[{ConstructiveDiagrams`Private`completionCertifiedModularReduce =
    Function[{matrix, constant, budget}, AppendTo[acBudgetSeen, budget]; Missing["TestNativeFallback"]]},
  ConstructiveDiagrams`Private`completionSolveLinear[acBudgetEquations, acBudgetUnknowns, 137]];
check["an explicit modular budget is forwarded without changing exact native fallback",
  acBudgetSeen === {137} && acBudgetExplicit === acBudgetDefault];
acBudgetRefined = Block[{ConstructiveDiagrams`Private`completionSolveLinear =
    Function[{equations, unknowns, budget}, AppendTo[acBudgetSeen, budget];
      <|"Status" -> "UNDERDETERMINED", "SolutionRules" -> {}, "FreeParameters" -> unknowns,
        "Rank" -> 0, "Diagnostics" -> {}|>]},
  ConstructiveDiagrams`Private`completionRefineLinear[
    <|"SolutionRules" -> {}, "FreeParameters" -> acBudgetUnknowns, "Rank" -> 0|>, {}, 211]];
check["linear refinement forwards its explicit backend budget",
  Last[acBudgetSeen] === 211 && acBudgetRefined["Status"] === "UNDERDETERMINED"];
acBudgetSeen = {};
acBudgetInvalid = Block[{ConstructiveDiagrams`Private`completionCertifiedModularReduce =
    Function[AppendTo[acBudgetSeen, "UnexpectedBackendCall"]; Missing["NotCalled"]]},
  ConstructiveDiagrams`Private`completionSolveLinear[acBudgetEquations, acBudgetUnknowns, #] & /@
    {0, -1, Infinity, "Invalid"}];
check["exhausted or invalid modular budgets remain unresolved without launching a backend",
  acBudgetSeen === {} && AllTrue[acBudgetInvalid, #["Status"] === "UNRESOLVED" &]];
check["public completion delegates to its core and forwards a finite remaining modular budget",
  !FreeQ[DownValues[CompleteFactorization],
    HoldPattern[ConstructiveDiagrams`Private`amplitudeAutomaticFactorization[___]]] &&
  !FreeQ[DownValues[ConstructiveDiagrams`Private`amplitudeAutomaticFactorization],
    HoldPattern[ConstructiveDiagrams`Private`completionFactorizationCore[___]]] &&
  !FreeQ[DownValues[ConstructiveDiagrams`Private`completionFactorizationCore],
    HoldPattern[ConstructiveDiagrams`Private`completionSolveLinear[_, _, _]]]];
acBudgetPublicExpression = First[Cases[DownValues[ConstructiveDiagrams`Private`completionFactorizationCore],
  HoldPattern[ConstructiveDiagrams`Private`completionSolveLinear[_, _, budget_]] :>
    HoldComplete[budget], Infinity]];
acBudgetSecondsSymbol = First[Cases[acBudgetPublicExpression,
  symbol_Symbol /; SymbolName[Unevaluated[symbol]] === "seconds" :> symbol, Infinity]];
acBudgetStartSymbol = First[Cases[acBudgetPublicExpression,
  symbol_Symbol /; SymbolName[Unevaluated[symbol]] === "start" :> symbol, Infinity]];
acBudgetPublicValue[outer_, elapsed_] := ReleaseHold[acBudgetPublicExpression /.
  {acBudgetSecondsSymbol -> outer, acBudgetStartSymbol -> 100 - elapsed,
    HoldPattern[AbsoluteTime[]] -> 100}];
check["public modular budget is bounded for infinite and long completion clocks",
  acBudgetPublicValue[Infinity, 0] === 900 && acBudgetPublicValue[14400, 1] === 900];
check["public modular budget cannot exceed the actual remaining completion clock",
  acBudgetPublicValue[60, 17] === 43 && acBudgetPublicValue[60, 61] === 0];
(* End modular backend budget forwarding. *)

(* A selected multiparticle shell fixes a pair sum, never an individual pair. *)
acCutDotRules = {Mass[1] -> acCutM1, Mass[2] -> acCutM2,
  Mass[3] -> acCutM3, Mass[4] -> acCutM4};
acCutDotProp = PropDen[Mom[Multiparticle[1, 2, 3]], acCutMass];
acCutDotOtherProp = PropDen[Mom[Multiparticle[1, 4]], acCutOtherMass];
acCutDotSum = MomProd[1, 2] + MomProd[1, 3] + MomProd[2, 3];
acCutDotConstant = (acCutMass^2 - acCutM1^2 - acCutM2^2 - acCutM3^2)/2;
acCutDotInverse = 1/(2 + MomProd[1, 2]);
acCutDotInput = acCutDotSum/(acCutDotProp acCutDotOtherProp) +
  MomProd[1, 4]/acCutDotOtherProp + acCutDotInverse;
acCutDotTrials = ConstructiveDiagrams`Private`completionCutInvariantTrials[
  acCutDotInput, {1, 2, 3}, acCutMass, acCutDotRules];
acCutDotExpected = acCutDotConstant/(acCutDotProp acCutDotOtherProp) +
  MomProd[1, 4]/acCutDotOtherProp + acCutDotInverse;
check["a general three-particle shell offers each applicable scalar-invariant pivot",
  Length[acCutDotTrials] === 3 &&
    AllTrue[acCutDotTrials, #["Expression"] === acCutDotExpected &]];
check["cut-invariant alternatives protect all inverse factors and both propagators",
  AllTrue[acCutDotTrials, !FreeQ[#["Expression"], acCutDotInverse] &&
    !FreeQ[#["Expression"], acCutDotProp] &&
    !FreeQ[#["Expression"], acCutDotOtherProp] &]];
check["cut-invariant alternatives do not impose an unselected channel shell",
  AllTrue[acCutDotTrials, !FreeQ[#["Expression"], MomProd[1, 4]] &]];
check["no invariant continuation is generated from an inverse-only occurrence",
  ConstructiveDiagrams`Private`completionCutInvariantTrials[
    acCutDotInverse, {1, 2, 3}, acCutMass, acCutDotRules] === {}];
check["two-particle cuts need no optional general-cut continuation",
  ConstructiveDiagrams`Private`completionCutInvariantTrials[
    acCutDotInput, {1, 2}, acCutMass, acCutDotRules] === {}];
check["unknown-sign powers remain protected in general cut-invariant trials",
  ConstructiveDiagrams`Private`completionCutInvariantTrials[
    MomProd[1, 2]^acCutUnknownPower, {1, 2, 3}, acCutMass, acCutDotRules] === {}];
check["missing external masses and duplicate cut labels do not justify a continuation",
  MissingQ[ConstructiveDiagrams`Private`completionCutInvariantTrials[
    acCutDotInput, {1, 2, 3}, acCutMass, Take[acCutDotRules, 2]]] &&
  MissingQ[ConstructiveDiagrams`Private`completionCutInvariantTrials[
    acCutDotInput, {1, 2, 2}, acCutMass, acCutDotRules]]];
acCutFourProp = PropDen[Mom[Multiparticle[1, 2, 3, 4]], acCutMass];
acCutFourSum = Total[MomProd @@@ Subsets[{1, 2, 3, 4}, {2}]];
acCutFourConstant = (acCutMass^2 - acCutM1^2 - acCutM2^2 - acCutM3^2 - acCutM4^2)/2;
acCutFourTrials = ConstructiveDiagrams`Private`completionCutInvariantTrials[
  acCutFourSum/acCutFourProp, {1, 2, 3, 4}, acCutMass, acCutDotRules];
check["general cut-invariant continuations also cover four-particle cuts with arbitrary masses",
  Length[acCutFourTrials] === 6 &&
    AllTrue[acCutFourTrials, #["Expression"] === acCutFourConstant/acCutFourProp &]];
check["the generated changes are selected-shell multiples rather than off-cut identities",
  AllTrue[acCutDotTrials, #["Expression"] =!= acCutDotInput &&
    Together[acCutDotInput - #["Expression"] -
      (acCutDotSum - acCutDotConstant)/(acCutDotProp acCutDotOtherProp)] === 0 &]];
acGeneralCutExternal = {Mass[1] -> 1, Mass[2] -> 1,
  Mass[3] -> 0, Mass[4] -> 0, Mass[5] -> 0, Mass[6] -> 0};
acGeneralCutProp = PropDen[Mom[Multiparticle[1, 3, 4]], 1];
acGeneralCutSource = (MomProd[1, 3] + MomProd[3, 4])/acGeneralCutProp;
acGeneralCutChannel = <|"Cut" -> {1, 3, 4}, "Mass" -> 1,
  "ExternalLegs" -> Range[6], "ExternalMassRules" -> acGeneralCutExternal,
  "Propagator" -> acGeneralCutProp, "Complete" -> True,
  "StateSum" -> MomProd[1, 3] + MomProd[3, 4]|>;
acGeneralCutNormalized = <|"Targets" -> {acGeneralCutChannel},
  "ExternalMassRules" -> acGeneralCutExternal|>;
acGeneralCutSaved = acGeneralCutNormalized;
acGeneralCutSpace = ConstructiveDiagrams`Private`completionSelectedChannelBasis[
  acGeneralCutNormalized, <|"Variants" -> {}|>, 64, {}, 1729, 20];
check["selected-channel construction retains the original source and adds a genuine three-leg direction",
  AssociationQ[acGeneralCutSpace] &&
    AnyTrue[acGeneralCutSpace["Sources"], Together[# - acGeneralCutSource] === 0 &] &&
    MemberQ[acGeneralCutSpace["Basis"], MomProd[1, 4]/acGeneralCutProp]];
acGeneralCutChecks = Select[acGeneralCutSpace["Verification"],
  #["Mode"] === "SelectedCutInvariantReduction" &];
check["each whole general-cut continuation passes its selected residue before term splitting",
  acGeneralCutChecks =!= {} && AllTrue[acGeneralCutChecks,
    #["Verification"]["Status"] === "PASS" &&
      Length[#["Verification"]["Samples"]] === 2 &] &&
    acGeneralCutNormalized === acGeneralCutSaved];
acGeneralCutLimited = ConstructiveDiagrams`Private`completionSelectedChannelBasis[
  acGeneralCutNormalized, <|"Variants" -> {}|>, 2, {}, 1729, 20];
check["the optional invariant term cap preserves the original space and records incomplete enumeration",
  AssociationQ[acGeneralCutLimited] && Length[acGeneralCutLimited["Basis"]] === 2 &&
    acGeneralCutLimited["ConstructionStatus"] === "PARTIAL" &&
    AnyTrue[acGeneralCutLimited["Sources"], Together[# - acGeneralCutSource] === 0 &] &&
    AnyTrue[acGeneralCutLimited["Diagnostics"],
      AssociationQ[#] && Lookup[#, "Reason", None] === "CutInvariantCorrectionSpaceLimit" &]];
acGeneralCutPartial = Block[
  {ConstructiveDiagrams`Private`completionCutInvariantTrials = Function[
    Pause[2]; {}]},
  ConstructiveDiagrams`Private`completionSelectedChannelBasis[
    acGeneralCutNormalized, <|"Variants" -> {}|>, 64, {}, 1729, 1]];
check["an optional continuation timeout retains certified original directions with an explicit partial marker",
  AssociationQ[acGeneralCutPartial] &&
    acGeneralCutPartial["ConstructionStatus"] === "PARTIAL" &&
    TrueQ[acGeneralCutPartial["OriginalSourcesComplete"]] &&
    !TrueQ[acGeneralCutPartial["InvariantContinuationsComplete"]] &&
    AnyTrue[acGeneralCutPartial["Sources"], Together[# - acGeneralCutSource] === 0 &] &&
    acGeneralCutPartial["Diagnostics"] =!= {}];
acGeneralCutOriginalLimit = ConstructiveDiagrams`Private`completionSelectedChannelBasis[
  acGeneralCutNormalized, <|"Variants" -> {}|>, 1, {}, 1729, 20];
check["original terms are cap-checked before any over-cap partial space can be retained",
  FailureQ[acGeneralCutOriginalLimit] &&
    First[acGeneralCutOriginalLimit] === "CorrectionSpaceLimit"];
acGeneralCutMissing = Block[
  {ConstructiveDiagrams`Private`completionCutInvariantTrials = Function[Missing["MissingExternalMass"]]},
  ConstructiveDiagrams`Private`completionSelectedChannelBasis[
    acGeneralCutNormalized, <|"Variants" -> {}|>, 64, {}, 1729, 20]];
check["missing invariant input is reported as incomplete optional enumeration",
  AssociationQ[acGeneralCutMissing] && acGeneralCutMissing["ConstructionStatus"] === "PARTIAL" &&
    !TrueQ[acGeneralCutMissing["InvariantContinuationsComplete"]] &&
    AnyTrue[acGeneralCutMissing["Diagnostics"],
      AssociationQ[#] && Lookup[#, "Reason", None] === "CutInvariantEnumerationUnavailable" &]];
acGeneralCutPoleCalls = 0;
acGeneralCutUnknownPoles = Block[
  {ConstructiveDiagrams`Private`completionHigherPhysicalPoles = Function[
    acGeneralCutPoleCalls++;
    If[acGeneralCutPoleCalls <= 2, {}, Failure["ClassificationUnavailable", <||>]]]},
  ConstructiveDiagrams`Private`completionSelectedChannelBasis[
    acGeneralCutNormalized, <|"Variants" -> {}|>, 64, {}, 1729, 20]];
check["unresolved physical-pole classification marks the optional enumeration partial",
  AssociationQ[acGeneralCutUnknownPoles] && acGeneralCutUnknownPoles["ConstructionStatus"] === "PARTIAL" &&
    AnyTrue[acGeneralCutUnknownPoles["Diagnostics"], AssociationQ[#] &&
      Lookup[#, "Reason", None] === "CutInvariantPoleClassificationUnavailable" &]];
acGeneralCutVerificationCalls = 0;
acGeneralCutUnknownVerification = Block[
  {ConstructiveDiagrams`Private`completionContinuationCheck = Function[
    acGeneralCutVerificationCalls++;
    <|"Status" -> If[acGeneralCutVerificationCalls === 1, "PASS", "UNRESOLVED"],
      "Samples" -> {}|>]},
  ConstructiveDiagrams`Private`completionSelectedChannelBasis[
    acGeneralCutNormalized, <|"Variants" -> {}|>, 64, {}, 1729, 20]];
check["unresolved selected-residue verification cannot claim complete optional enumeration",
  AssociationQ[acGeneralCutUnknownVerification] &&
    acGeneralCutUnknownVerification["ConstructionStatus"] === "PARTIAL" &&
    AnyTrue[acGeneralCutUnknownVerification["Diagnostics"], AssociationQ[#] &&
      Lookup[#, "Reason", None] === "CutInvariantVerificationUnresolved" &]];
acGeneralCutPoleCalls = 0;
acGeneralCutRejectedPoles = Block[
  {ConstructiveDiagrams`Private`completionHigherPhysicalPoles = Function[
    acGeneralCutPoleCalls++; If[acGeneralCutPoleCalls <= 2, {}, {acGeneralCutProp}]]},
  ConstructiveDiagrams`Private`completionSelectedChannelBasis[
    acGeneralCutNormalized, <|"Variants" -> {}|>, 64, {}, 1729, 20]];
check["known higher-order poles are explicitly rejected without pretending their classification was unresolved",
  AssociationQ[acGeneralCutRejectedPoles] &&
    acGeneralCutRejectedPoles["ConstructionStatus"] === "COMPLETE" &&
    AnyTrue[acGeneralCutRejectedPoles["Diagnostics"], AssociationQ[#] &&
      Lookup[#, "Status", None] === "REJECTED" &&
      Lookup[#, "Reason", None] === "CutInvariantHigherOrderPhysicalPoles" &]];
(* End general selected-cut invariant continuations. *)

(* Private completion-helper reload migration. *)
(* Reloading upgrades the changed private helper signatures without clearing
   unrelated private definitions in the user's running kernel. *)
ConstructiveDiagrams`Private`completionIndependentBasis[legacyBasis_List] :=
  "LegacyOneArgumentPruning";
ConstructiveDiagrams`Private`completionSolveLinear[legacyEquations_List, legacyUnknowns_List] :=
  "LegacyTwoArgumentLinearSolver";
ConstructiveDiagrams`Private`completionRefineLinear[legacyPrevious_Association, legacyEquations_List] :=
  "LegacyTwoArgumentLinearRefinement";
ConstructiveDiagrams`Private`completionSelectedChannelBasis[legacyInput_Association,
  legacyReferences_Association, legacyLimit_Integer, legacyRules_List,
  legacySeed_Integer, legacySeconds_ : 20] := "LegacySelectedChannelBudget";
ConstructiveDiagrams`Private`amplitudeCompletionReloadSentinel[value_] := value + 79;
acReloadUnrelatedDefinitions = DownValues[
  ConstructiveDiagrams`Private`amplitudeCompletionReloadSentinel];
check["the reload regression installs the more-specific legacy pruning signature",
  ConstructiveDiagrams`Private`completionIndependentBasis[acFormalBasis] ===
    "LegacyOneArgumentPruning"];
Get[FileNameJoin[{$HEPCATpath, "HEPCAT.wl"}]];
check["package reload removes stale two-argument linear solver and refinement definitions",
  Length[DownValues[ConstructiveDiagrams`Private`completionSolveLinear]] === 1 &&
    Length[DownValues[ConstructiveDiagrams`Private`completionRefineLinear]] === 1 &&
    ConstructiveDiagrams`Private`completionSolveLinear[{}, {acBudgetX}]["Status"] === "UNDERDETERMINED" &&
    ConstructiveDiagrams`Private`completionRefineLinear[
      <|"SolutionRules" -> {}, "FreeParameters" -> {acBudgetX}, "Rank" -> 0|>, {}]["Status"] ===
        "UNDERDETERMINED"];
check["package reload replaces the stale one-argument pruning signature",
  Length[DownValues[ConstructiveDiagrams`Private`completionIndependentBasis]] === 1 &&
    ConstructiveDiagrams`Private`completionIndependentBasis[acFormalBasis] ===
      Take[acFormalBasis, 2]];
check["package reload replaces the old optional selected-channel budget and implementation",
  Length[DownValues[ConstructiveDiagrams`Private`completionSelectedChannelBasis]] === 1 &&
    ConstructiveDiagrams`Private`completionSelectedChannelBasis[
      <|"Targets" -> {}, "ExternalMassRules" -> {}|>, <||>, 1, {}, 1] ===
      Missing["NoSelectedChannelSources"] &&
    ConstructiveDiagrams`Private`completionSelectedChannelBasis[
      <|"Targets" -> {}, "ExternalMassRules" -> {}|>, <||>, 1, {}, 1, 60, False] ===
      Missing["NoSelectedChannelSources"] &&
    Cases[DownValues[ConstructiveDiagrams`Private`completionSelectedChannelBasis],
      HoldPattern[Verbatim[Optional][_, default_]] :> default, Infinity] === {60, True}];
check["targeted completion-helper reload migration preserves unrelated private functions",
  DownValues[ConstructiveDiagrams`Private`amplitudeCompletionReloadSentinel] ===
    acReloadUnrelatedDefinitions &&
    ConstructiveDiagrams`Private`amplitudeCompletionReloadSentinel[3] === 82];
Remove[ConstructiveDiagrams`Private`amplitudeCompletionReloadSentinel];
(* End private completion-helper reload migration. *)

Print[checks, " amplitude-completion checks; ", Length[failures], " failures."];
If[failures =!= {}, Print[failures]; Quit[1]];
Print["HEPCAT_TEST_COMPLETED:amplitude-completion-tests.wl"];
Quit[0];
